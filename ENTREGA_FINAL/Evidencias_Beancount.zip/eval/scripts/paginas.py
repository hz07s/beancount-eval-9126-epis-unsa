# -*- coding: utf-8 -*-
"""Lee el PDF renderizado y devuelve la página de cada título del índice (2 pasadas)."""
import json, re, subprocess, sys
sys.path.insert(0, "/home/claude/eval/scripts")
from catalogo import METRICAS
pdf, out = sys.argv[1], sys.argv[2]
n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout).group(1))
pages = [subprocess.run(["pdftotext", "-f", str(i), "-l", str(i), "-layout", pdf, "-"], capture_output=True, text=True).stdout for i in range(1, n + 1)]
heads = ["PARTE II – EVALUACIÓN DE CALIDAD DE PRODUCTO", "1. Introducción", "2. Modelo de Calidad de Producto",
         "2.1 Priorización de atributos (técnica de Brosseau)", "2.2 Sub-características seleccionadas y pesos",
         "2.3 Justificación técnica de la selección", "2.4 Requerimientos no funcionales y métricas", "3. Catálogo de métricas"]
heads += [f"3.{int(m['n'])} Sub-característica: {m['sub'].upper()} / MÉTRICA: {m['n']} – {m['nombre']}" for m in METRICAS]
heads += ["3.26 Métricas de la norma descartadas", "4. Resultados de la evaluación", "4.1 Componentes evaluados",
          "4.2 Resultados por métrica y componente", "4.3 Resumen por sub-característica y puntaje global", "4.4 Hallazgos principales",
          "5. Conclusiones", "6. Recomendaciones", "ANEXO A – MATRIZ DE BROUSSEAU", "ANEXO B – EVIDENCIAS DE RESULTADOS DE EVALUACIÓN"]
norm = lambda s: re.sub(r"\s+", " ", s)
res, start = {}, 2
for h in heads:
    key = norm(h)[:45]
    for i in range(start, n):
        if key in norm(pages[i]):
            res[h] = i + 1; start = i; break
    else:
        print("NO ENCONTRADO", h)
json.dump(res, open(out, "w"), ensure_ascii=False)
print(len(res), "títulos;", n, "páginas")
