# -*- coding: utf-8 -*-
"""Genera hallazgos, conclusiones, recomendaciones y extractos de evidencia a partir de
out/resultados.json y de los registros crudos (ningún número se escribe a mano)."""
import json
import os
import re

OUT = "/home/claude/eval/out"
BASE = "/home/claude/eval"
R = json.load(open(f"{OUT}/resultados.json", encoding="utf-8"))
RM = {m["n"]: m for m in R["metricas"]}
S = R["subs"]
J = lambda m: json.load(open(f"{OUT}/{m}.json", encoding="utf-8"))
f4 = lambda x: f"{x:.4f}"
pct = lambda x: f"{100 * x:.2f} %"


def tot(n, k):
    return RM[n]["filas"]["Total"]["vals"][k]


def casos(m, flag=True, campo="cuenta_A"):
    return [c for c in J(m)["casos"] if bool(c.get(campo)) == flag]


def log(path, cola=None, cabeza=None, maxc=1400):
    t = open(os.path.join(BASE, path), encoding="utf-8", errors="replace").read()
    lines = t.splitlines()
    head = lines[:3]
    body = lines[3:]
    if cola:
        body = [l for l in body if l.strip()][-cola:]
    if cabeza:
        body = body[:cabeza]
    s = "\n".join(head + ["..."] + body)
    return s[:maxc]


t17 = J("017")["tiempos_s"]
t18 = J("018")["tiempos_s"]
mean = lambda v: sum(v) / len(v)
n_fail = {n: (not RM[n]["pasa"]) for n in RM}
fallan = [n for n in RM if not RM[n]["pasa"]]
sub_rojas = [s for s, v in S.items() if v["color"] == "rojo"]
sub_verdes = [s for s, v in S.items() if v["color"] == "verde"]
sec = [s for s, v in S.items() if v["color"] == "amarillo"]
c011 = casos("011")
c013n = casos("013", False)
c016 = casos("016")
d009 = J("009_010")["fuente"]["por_componente"]

hall = [
    f"**Exactitud contable sin errores (Precisión, 001–002).** Los {tot('002', 'N')} cálculos verificados contra un oráculo "
    f"independiente (saldos de 3 libros sintéticos de ~3 000 transacciones, costo de lotes FIFO, ganancias realizadas, "
    f"aserciones mensuales, 30 expresiones aritméticas y totales de bean-query) coinciden exactamente; también los "
    f"{tot('001', 'N')} casos de comportamiento documentado (interpolación, booking FIFO/LIFO/STRICT, pad, tolerancias, include, pushtag).",
    f"**Precisión de presentación (003 no pasa).** El núcleo guarda los números como Decimal exacto, pero la salida de texto de "
    f"bean-query redondea según el 'display context' inferido: un saldo de 3.12345678 BTC se muestra como '3 BTC' (también con -m). "
    f"La salida CSV sí es exacta. A = {tot('003', 'A')} de N = {tot('003', 'N')} resultados.",
    f"**Fallo de segmento del analizador en C (011).** Un monto escrito como '1/0 USD' termina el proceso con SIGSEGV (rc = −11) en "
    f"bean-check; Beancount 2.3.6 tiene el mismo comportamiento. Es la caída más grave encontrada.",
    f"**Errores no controlados en bean-query y otras CLI (011, 013, 015).** Una consulta con error de sintaxis, una columna inexistente, "
    f"un tipo incompatible o '-f beancount' con SELECT terminan con traza de Python en lugar de un mensaje; bean-format sobre un binario, "
    f"bean-check sobre un directorio y bean-example con fecha fin anterior a la de inicio también. Además bean-query sobre un archivo "
    f"inexistente informa el error pero termina con código 0. Prevención de caídas X = {f4(RM['011']['X'])} ({tot('011', 'A')} caídas en "
    f"{tot('011', 'B')} entradas defectuosas); prevención de operación incorrecta X = {f4(RM['013']['X'])}.",
    f"**Riesgo de pérdida de datos sin aviso (016 no pasa).** 'bean-query -o libro.beancount' y 'bean-example -o libro.beancount' "
    f"sobrescriben el libro del usuario sin advertir (el libro de 469 KB quedó en 96 bytes). Con la caché .picklecache vigente, un libro "
    f"editado que conserva tamaño y fecha de modificación al nanosegundo (p. ej. restaurado con cp -p o rsync -t) se valida con la "
    f"caché obsoleta: saldo antiguo y 0 errores, cuando sin caché bean-check reporta errores. X = {f4(RM['016']['X'])}.",
    f"**Integridad del libro (006 pasa, 007 no pasa).** Ninguna herramienta modificó el archivo fuente en {tot('006', 'N')} casos "
    f"(lectura, SIGKILL, caché corrupta, ejecuciones concurrentes, directorio de solo lectura, CRLF, complementos). El único evento "
    f"menor fue la caché obsoleta (Y = {f4(RM['007']['X'])} < 0,95).",
    f"**Reglas contables (005): 100 %.** Los 15 tipos de operación ilegal especificados (desbalance, cuenta no abierta o cerrada, moneda "
    f"no permitida, aserción falsa, lote inexistente, venta mayor a lo tenido, open duplicado, close sin open, dos montos omitidos, "
    f"pad sin uso, documento inexistente, nombre de cuenta, fecha y moneda inválidas) se detectan tanto por la API como por bean-check.",
    f"**Madurez alta.** 0 fallas en {tot('008', 'A2')} casos sobre libros válidos; la suite oficial del tag 3.2.3 ejecuta "
    f"{tot('009', 'A')} de {tot('009', 'B')} pruebas (21 omitidas por funciones deshabilitadas, como Booking.AVERAGE) y pasan "
    f"{tot('010', 'A')} de {tot('010', 'B')} (2 xfail conocidos). Ejecutada desde el paquete instalado, 2 pruebas fallan porque "
    f"buscan la raíz del repositorio (no es un defecto del producto).",
    f"**Rendimiento: bien en uso típico, insuficiente en el peor caso (secundario).** Libro de ejemplo (1 552 tx): tiempo medio "
    f"{mean(t17['C1']):.3f} s (parse), {mean(t17['C2']):.3f} s (bean-check), {mean(t17['C3']):.3f} s (bean-query); X = "
    f"{f4(RM['017']['X'])}. Libro de 100 000 tx sin caché: peor caso {max(t18['C2']):.1f} s en bean-check y "
    f"{max(t18['C3']):.1f} s en bean-query frente a 10 s requeridos (X = {f4(RM['018']['X'])}), mientras el análisis sintáctico "
    f"solo toma {max(t18['C1']):.1f} s. El desglose de bean-check -v atribuye 115 de 122 s a la etapa de booking: el libro sintético "
    f"tiene unas 10 000 compras de una misma acción con booking FIFO (miles de lotes abiertos), y el costo crece con el número de lotes. "
    f"Con caché válida la carga baja a ~3–5 s.",
    f"**Migración 2.x → 3.x.** Los datos migran sin pérdida (024: {tot('024', 'A')}/{tot('024', 'B')}), pero solo "
    f"{tot('025', 'A')} de {tot('025', 'B')} funciones de 2.3.6 siguen disponibles sin cambios (X = {f4(RM['025']['X'])}): "
    f"bean-report, bean-web, bean-bake, bean-price, bean-extract/identify/file y bean-sql se retiraron o movieron a otros paquetes, "
    f"y varios complementos (p. ej. unrealized, forecast, exclude_tag, tag_pending) ya no existen en beancount.plugins.",
    f"**Verificabilidad (Testeabilidad pasa).** {tot('020', 'A')} de {tot('020', 'B')} oportunidades de prueba se resuelven con funciones "
    f"incorporadas (bean-check, bean-doctor, --json, plugins de validación, pytest incluido); faltan conciliación con extractos y "
    f"comparación contable entre versiones del libro. La re-prueba tras corregir toma en promedio {RM['021']['X']:.3f} s. "
    f"La suite no detectó un cambio del booking_method por defecto (mutación excluida del cálculo).",
]

conc = [
    f"Se definieron **{len(RM)} métricas externas** de la NTP-ISO/IEC TR 9126-2 sobre 11 sub-características de la NTP-ISO/IEC 9126-1 "
    f"(6 principales y 5 secundarias), priorizadas con la técnica de Brosseau, y se midieron con valores reales en los tres componentes "
    f"de Beancount 3.2.3; no hubo métricas sin medir ni valores estimados.",
    f"El **puntaje global ponderado es {pct(R['global_'])}**, por lo que la calidad de producto de Beancount 3.2.3 se clasifica como "
    f"**{R['clasificacion']}** (MUY BUENO ≥ 95 %, ACEPTABLE ≥ 80 % y < 95 %, NO ACEPTABLE < 80 %).",
    "Sub-características principales que **pasan** (verde): " + ", ".join(f"{s} ({f4(S[s]['puntaje'])})" for s in sub_verdes) + ". "
    + ("Principales que **no pasan** (rojo): " + ", ".join(f"{s} ({f4(S[s]['puntaje'])})" for s in sub_rojas) + "." if sub_rojas else "Ninguna principal queda en rojo."),
    "Secundarias (amarillo): " + ", ".join(f"{s} ({f4(S[s]['puntaje'])})" for s in sec) + ". Su puntaje se pondera en el global, "
    "pero no define la aprobación según la regla del curso.",
    f"Métricas que no alcanzan su umbral ({len(fallan)} de {len(RM)}): " + "; ".join(f"{n} {RM[n]['nombre']} (X = {f4(RM[n]['X'])})" for n in fallan) + ".",
    "Vínculo con los RNF: se cumplen RNF-01 (exactitud, salvo la presentación de texto de bean-query), RNF-03 (reglas contables), RNF-04 "
    "(fiabilidad), RNF-08 (verificabilidad), RNF-09, RNF-10, RNF-11 en datos y RNF-12. No se cumplen plenamente RNF-02 (caché "
    "obsoleta), RNF-05 (caídas con traza y un fallo de segmento), RNF-06 (sobrescritura sin aviso y códigos de salida incoherentes) "
    "ni RNF-07 en el peor caso (100 000 transacciones). La parte funcional de RNF-11 (funciones de 2.3.6) solo se cumple parcialmente.",
    "El balance es el de un núcleo contable muy confiable (exactitud, reglas, integridad del fuente y madurez) rodeado de herramientas "
    "de línea de comandos menos pulidas en el manejo de errores y en la protección frente a operaciones de riesgo; ahí se concentra la "
    "Operabilidad en rojo.",
]

reco = [
    "**Analizador (C1):** capturar la división por cero en la evaluación de expresiones aritméticas del analizador en C y reportarla "
    "como error 'archivo:línea' en vez de terminar con SIGSEGV; agregar el caso a lexer/grammar tests.",
    "**bean-query (C3):** capturar ParseError y CompilationError en modo no interactivo y mostrar 'Error: …' con la posición, como ya "
    "hace la consola interactiva; validar que '-f beancount' solo se use con PRINT; devolver código ≠ 0 cuando el libro no existe o "
    "tiene errores, para alinearse con bean-check.",
    "**Protección contra sobrescritura (C3):** en bean-query -o y bean-example -o, negarse a sobrescribir un archivo existente (o "
    "pedir --force) y nunca escribir sobre un archivo que sea el libro de entrada.",
    "**Caché (C1):** incluir un hash del contenido (o al menos de las primeras/últimas páginas) en compute_input_hash, o validar con "
    "mtime + ctime, para que un libro restaurado con la misma fecha y tamaño no use resultados obsoletos.",
    "**Presentación de números (C3):** que la salida de texto de bean-query no redondee por debajo de la precisión real de un saldo, "
    "o que advierta cuando lo hace; documentar la opción display_precision como solución.",
    "**Rendimiento (C2):** optimizar el booking cuando un inventario acumula miles de lotes (la etapa 'booking' consume ~94 % del "
    "tiempo en el peor caso medido), por ejemplo indexando los lotes por moneda y costo; la caché ya mitiga las cargas repetidas, pero "
    "la primera validación tras cada edición de un libro de 100 000 transacciones supera los 100 s. A los usuarios con muchos lotes "
    "se les puede sugerir dividir el libro por años o consolidar lotes antiguos.",
    "**Manejo de entradas de la CLI (C3):** validar que FILENAME no sea un directorio en bean-check y que --date-end sea posterior a "
    "--date-begin en bean-example, con mensajes de Click en lugar de trazas.",
    "**Migración:** publicar una tabla de equivalencias 2.x → 3.x (herramientas y complementos retirados o movidos a beanquery, "
    "beangulp, beanprice, fava) y avisos de deprecación en el cargador cuando se importe un complemento retirado.",
    "**Pruebas:** agregar pruebas que fijen los valores por defecto de las opciones (p. ej. booking_method = STRICT) y hacer que "
    "test_utils encuentre los ejemplos también al ejecutar la suite desde el paquete instalado.",
    "**Para el grupo:** validar los juicios marcados (orden de importancia de Clarrus, criterio de mensajes autoexplicativos y umbrales) "
    "y, si se dispone de usuarios, complementar Operabilidad con las métricas de observación descartadas (TUO).",
]

ext = []


def addx(t, p, **kw):
    ext.append((t, log(p, **kw)))


addx("011 – Fallo de segmento con '1/0 USD' (bean-check)", "logs/raw/011/C1_division_por_cero.txt", cabeza=6)
addx("011 – bean-query con consulta mal escrita: traza no controlada", "logs/raw/011/C3_query_sintaxis.txt", cola=4)
addx("011 – bean-query -f beancount con SELECT", "logs/raw/011/C3_query_beancount_select.txt", cola=4)
addx("013 – bean-check sobre un directorio", "logs/raw/013/C3_check_directorio.txt", cola=3)
addx("013 – bean-query sobre archivo inexistente: error informado pero rc=0", "logs/raw/013/C3_query_inexistente.txt", cabeza=8)
addx("016 – bean-query -o sobre el propio libro (sin aviso)", "logs/raw/016/C3_query_o_sobre_libro.txt", cabeza=6)
for cid in ("C3_query_o_sobre_libro", "C3_example_o_existente"):
    c = [x for x in J("016")["casos"] if x["id"] == cid][0]
    ext.append((f"016 – resultado observado: {c['desc']}", c["observado"]))
c = [x for x in J("006_007")["casos"] if x["id"] == "C1_cache_obsoleta"][0]
ext.append(("007/016 – Caché obsoleta (libro editado con igual tamaño y mtime en ns)", c["observado"] + "\nEvidencia: " + c["evidencia"]))
addx("003 – Presentación de bean-query (texto) vs CSV", "logs/raw/003/C3_texto_sum_position.txt", cabeza=6)
addx("003 – misma consulta en CSV", "logs/raw/003/C3_csv_sum_number.txt", cabeza=5)
ext.append(("009/010 – Suite oficial (árbol del tag 3.2.3)", "\n".join(open(f"{BASE}/logs/raw/009_010/pytest_fuente.log").read().strip().splitlines()[-2:])
            + "\nDesde el paquete instalado: " + open(f"{BASE}/logs/raw/009_010/pytest_instalado.log").read().strip().splitlines()[-2]))
ext.append(("017/018 – Tiempos medidos (s)", "\n".join(
    [f"017 ejemplo {k}: " + ", ".join(f"{x:.3f}" for x in v) for k, v in t17.items()] +
    [f"018 100k   {k}: " + ", ".join(f"{x:.2f}" for x in v) for k, v in t18.items()])))
if os.path.exists(f"{BASE}/logs/raw/018/perfil_etapas_bean_check_v.txt"):
    ext.append(("018 – Desglose por etapas (bean-check -v -C, libro de 100 000 tx)",
                "\n".join(l for l in open(f"{BASE}/logs/raw/018/perfil_etapas_bean_check_v.txt").read().splitlines() if "INFO" in l or "time" in l.lower())[:1600]))
c = [x for x in J("012")["casos"] if x["id"] == "C2_desbalanceada"][0]
ext.append(("012 – Error insertado a mitad del libro: el resto sigue utilizable", c["observado"]))

for name, data in (("hallazgos", hall), ("conclusiones", conc), ("recomendaciones", reco), ("extractos", ext)):
    json.dump(data, open(f"{OUT}/{name}.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
print("textos ok;", len(hall), len(conc), len(reco), len(ext))
