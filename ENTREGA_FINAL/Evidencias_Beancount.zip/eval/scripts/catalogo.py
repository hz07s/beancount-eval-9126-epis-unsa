# -*- coding: utf-8 -*-
"""
Catálogo único (fuente de verdad) de la evaluación de calidad de Beancount.

Contiene: decisiones Clarrus (pasos 1 y 2), mapeo atributo -> sub-característica
ISO/IEC 9126-1, RNF, componentes y catálogo de métricas externas ISO/IEC TR 9126-2
con sus umbrales (valor esperado). Los umbrales se fijaron ANTES de ejecutar las
mediciones (ver logs/00_protocolo_registrado.txt) y no se modifican después.
"""
from fractions import Fraction

PRODUCTO = {
    "nombre": "Beancount",
    "repo": "https://github.com/beancount/beancount",
    "version": "3.2.3",
    "tag": "3.2.3",
    "commit": "eeda2aa2a3204ffb980dab11220b2abde5e80b38",
    "fecha_commit": "2026-05-05",
    "wheel": "beancount-3.2.3-cp313-cp313-manylinux2014_x86_64 (PyPI)",
    "beanquery": "0.2.0 (paquete separado que provee bean-query desde la v3)",
    "version_anterior": "2.3.6 (PyPI, sdist compilado con Python 3.11) para pruebas de reemplazabilidad",
}

# ---------------------------------------------------------------- Clarrus paso 1
# (atributo, vista, razonamiento, Include)
CLARRUS_ATRIBUTOS = [
    ("availability", "external",
     "Beancount es una herramienta de línea de comandos y una biblioteca que se ejecuta bajo demanda sobre archivos locales; "
     "no es un servicio con horario de disponibilidad (la interfaz web es Fava, un proyecto aparte). No hay tiempo de servicio que garantizar.",
     "No"),
    ("installability", "external",
     "El usuario instala Beancount por sí mismo con pip; la v3 incluye una extensión C (_parser) que se distribuye como wheel por plataforma. "
     "Si la instalación o reinstalación falla, el libro contable queda inaccesible.",
     "Yes"),
    ("integrity", "external",
     "El archivo .beancount es la única fuente de verdad financiera del usuario. Las herramientas no deben alterarlo ni dejar datos derivados "
     "(caché) inconsistentes, y las reglas contables (cuentas abiertas, monedas permitidas, aserciones) deben impedir operaciones ilegales.",
     "Yes"),
    ("interoperability", "external",
     "Beancount es la base de un ecosistema (Fava, beanquery, beangulp, complementos). El intercambio se da por el formato de texto, "
     "la salida CSV/texto de bean-query y la salida JSON de errores de bean-check.",
     "Yes"),
    ("performance", "external",
     "Cada consulta o validación recarga el libro completo desde el texto; los libros personales crecen durante años "
     "(decenas de miles de transacciones), por lo que el tiempo de carga y validación afecta el uso diario.",
     "Yes"),
    ("reliability", "external",
     "Es un sistema de contabilidad de partida doble: saldos, conversiones, costos y ganancias deben calcularse exactamente "
     "(aritmética decimal) y de forma repetible. Un resultado incorrecto invalida los estados financieros.",
     "Yes"),
    ("robustness", "external",
     "La entrada es texto escrito a mano por el usuario: son frecuentes errores de sintaxis, archivos truncados o mal codificados. "
     "La herramienta debe reportarlos sin caerse y seguir procesando lo válido.",
     "Yes"),
    ("safety", "external",
     "No controla dispositivos ni procesos físicos; no puede causar daño a personas o bienes materiales. "
     "El riesgo financiero de un error de cálculo ya se cubre con reliability e integrity.",
     "No"),
    ("security", "external",
     "Herramienta local sin usuarios, sin inicio de sesión ni red: el control de acceso lo da el sistema operativo (permisos de archivo). "
     "La protección de los datos contables frente a operaciones ilegales se trata como integrity.",
     "No"),
    ("usability", "external",
     "La interacción es por línea de comandos y mensajes de error; usuarios técnicos y no técnicos deben entender qué está mal "
     "(archivo:línea, causa) y cómo corregirlo.",
     "Yes"),
    ("efficiency", "internal",
     "Corre en el PC del usuario con recursos holgados; el consumo de CPU/memoria solo importa en cuanto se refleja en tiempos de respuesta, "
     "que ya se evalúan en performance.",
     "No"),
    ("modifiability", "internal",
     "El comportamiento se ajusta con directivas option y plugin (complementos en Python) sin tocar el código; "
     "los usuarios adaptan la herramienta a su contabilidad (moneda operativa, método de costeo, nombres de cuentas raíz).",
     "Yes"),
    ("portability", "internal",
     "Se usa en Linux, macOS y Windows y los libros duran décadas: deben seguir siendo utilizables al pasar de Beancount 2.x a 3.x "
     "(reemplazabilidad entre versiones mayores).",
     "Yes"),
    ("reusability", "internal",
     "La reutilización de componentes es un asunto de los desarrolladores; su manifestación externa (Fava y beanquery consumen la API de carga) "
     "se evalúa dentro de interoperability.",
     "No"),
    ("scalability", "internal",
     "El crecimiento del libro en volumen se evalúa como peor caso de tiempo de respuesta dentro de performance; "
     "no hay usuarios concurrentes ni despliegue distribuido que escalar.",
     "No"),
    ("verifiability", "internal",
     "Verificar es parte del uso: bean-check, aserciones balance y una suite de pruebas automatizada permiten validar el libro y el código "
     "después de cada cambio.",
     "Yes"),
]

INCLUIDOS = [a for a, _, _, inc in CLARRUS_ATRIBUTOS if inc == "Yes"]

# ---------------------------------------------------------------- Clarrus paso 2
# Orden base de importancia (juicio del evaluador, a validar por el grupo) y
# excepciones explícitas a la transitividad.
ORDEN_BASE = ["reliability", "integrity", "robustness", "verifiability", "usability",
              "performance", "portability", "installability", "modifiability",
              "interoperability"]
# (ganador, perdedor) que contradicen el orden base
EXCEPCIONES = {("interoperability", "installability"):
               "La instalación es un paso único; en cambio el ecosistema (Fava, beanquery, importadores) "
               "depende en el día a día de intercambiar el mismo libro."}

JUSTIF_ORDEN = {
    "reliability": "Primero: si un saldo o una ganancia de capital están mal calculados, el producto no cumple su propósito.",
    "integrity": "Segundo: el archivo del libro es irreemplazable; corromperlo o aceptar operaciones contables ilegales es casi tan grave como calcular mal.",
    "robustness": "Tercero: el libro se escribe a mano y siempre tendrá errores; la herramienta debe tolerarlos sin caerse.",
    "verifiability": "Cuarto: la propuesta de valor de Beancount es que el usuario pueda verificar sus cuentas (bean-check, aserciones).",
    "usability": "Quinto: la CLI es la interfaz; sus mensajes guían la corrección, pero un usuario técnico tolera cierta aspereza.",
    "performance": "Sexto: importa al crecer el libro, pero los libros personales típicos cargan en segundos.",
    "portability": "Séptimo: la migración 2.x a 3.x ocurre pocas veces, pero es crítica cuando ocurre.",
    "installability": "Se instala una vez; pierde frente a casi todo salvo modifiability.",
    "modifiability": "Las opciones y complementos son útiles, pero la mayoría de usuarios usa la configuración por defecto.",
    "interoperability": "El intercambio depende sobre todo del formato de texto, que ya es abierto.",
}


def gana(a, b):
    """True si el atributo a es más importante que b."""
    if (a, b) in EXCEPCIONES:
        return True
    if (b, a) in EXCEPCIONES:
        return False
    return ORDEN_BASE.index(a) < ORDEN_BASE.index(b)


def scores():
    s = {a: 0 for a in INCLUIDOS}
    for i, a in enumerate(INCLUIDOS):
        for b in INCLUIDOS[i + 1:]:
            if gana(a, b):
                s[a] += 1
            else:
                s[b] += 1
    return s


UMBRAL_PRINCIPAL = 5  # score >= 5 => atributo principal

# ---------------------------------------------------------------- Mapeo a ISO 9126
# atributo -> [(sub-característica, fracción)]
MAPEO = {
    "reliability": [("Precisión", Fraction(1, 2)), ("Madurez", Fraction(1, 2))],
    "integrity": [("Seguridad", Fraction(1))],
    "robustness": [("Tolerancia a fallos", Fraction(1))],
    "verifiability": [("Testeabilidad", Fraction(1))],
    "usability": [("Operabilidad", Fraction(1))],
    "performance": [("Comportamiento en el tiempo", Fraction(1))],
    "portability": [("Reemplazabilidad", Fraction(1))],
    "installability": [("Instalabilidad", Fraction(1))],
    "modifiability": [("Cambiabilidad", Fraction(1))],
    "interoperability": [("Interoperabilidad", Fraction(1))],
}
JUSTIF_MAPEO = {
    "reliability": "En Clarrus el criterio Accuracy pertenece a reliability; en ISO 9126 la exactitud de resultados es Precisión (6.1.2) y la ausencia de fallos por defectos es Madurez (6.2.1). Se reparte 50/50.",
    "integrity": "ISO 9126 (6.1.4) define Seguridad como proteger la información para que no sea modificada indebidamente; sus métricas de prevención de corrupción y de control de operaciones ilegales son las que expresan integridad de datos.",
    "robustness": "Mantener el funcionamiento ante entradas defectuosas o incumplimiento de la interfaz es la definición de Tolerancia a fallos (6.2.2).",
    "verifiability": "Permitir que las modificaciones se validen es Testeabilidad (6.5.4).",
    "usability": "En una CLI la usabilidad se concentra en operar y controlar la herramienta y entender sus mensajes: Operabilidad (6.3.3).",
    "performance": "Tiempos de respuesta y procesamiento = Comportamiento en el tiempo (6.4.1).",
    "portability": "El riesgo de portabilidad dominante es reemplazar Beancount 2.x por 3.x conservando los libros: Reemplazabilidad (6.6.4).",
    "installability": "Equivalencia directa con Instalabilidad (6.6.2).",
    "modifiability": "La adaptación por parámetros (option/plugin) se mide en ISO 9126-2 como Modificabilidad parametrizada, bajo Cambiabilidad (6.5.2).",
    "interoperability": "Equivalencia directa con Interoperabilidad (6.1.3).",
}

# Árbol ISO 9126-1 (26 sub-características en el orden de la plantilla)
ISO_ARBOL = [
    ("Funcionalidad", "FUNC", ["Aplicabilidad", "Precisión", "Interoperabilidad", "Seguridad", "Conformidad de funcionalidad"]),
    ("Fiabilidad", "FIAB", ["Madurez", "Tolerancia a fallos", "Recuperabilidad", "Conformidad de fiabilidad"]),
    ("Usabilidad", "USAB", ["Entendibilidad", "Facilidad de aprendizaje", "Operabilidad", "Atractividad", "Conformidad de usabilidad"]),
    ("Eficiencia", "EFIC", ["Comportamiento en el tiempo", "Utilización de recursos", "Conformidad de eficiencia"]),
    ("Mantenibilidad", "MANT", ["Analizabilidad", "Cambiabilidad", "Estabilidad", "Testeabilidad", "Conformidad de mantenibilidad"]),
    ("Portabilidad", "PORT", ["Adaptabilidad", "Instalabilidad", "Co-existencia", "Reemplazabilidad", "Conformidad de portabilidad"]),
]
ABREV_SUB = {
    "Precisión": "PREC", "Interoperabilidad": "INTE", "Seguridad": "SEGU", "Madurez": "MADU",
    "Tolerancia a fallos": "TOLE", "Operabilidad": "OPER", "Comportamiento en el tiempo": "TIEM",
    "Cambiabilidad": "CAMB", "Testeabilidad": "TEST", "Instalabilidad": "INST", "Reemplazabilidad": "REEM",
}

# Motivo de exclusión (N) para las sub-características no consideradas
MOTIVO_N = {
    "Aplicabilidad": "La adecuación del conjunto de funciones es una decisión de diseño del producto (lenguaje contable); no fue priorizada por Clarrus.",
    "Conformidad de funcionalidad": "No existe norma contable o regulación externa que Beancount declare cumplir.",
    "Recuperabilidad": "No mantiene estado ni sesiones: cada ejecución relee el archivo; no hay nada que restaurar tras una caída.",
    "Conformidad de fiabilidad": "Sin normas de fiabilidad declaradas.",
    "Entendibilidad": "La CLI se evalúa por Operabilidad; la comprensión de la documentación no fue priorizada.",
    "Facilidad de aprendizaje": "Requiere estudios con usuarios novatos; no priorizada.",
    "Atractividad": "Interfaz de texto sin elementos visuales.",
    "Conformidad de usabilidad": "Sin guía de estilo declarada.",
    "Utilización de recursos": "efficiency fue excluido en Clarrus (recursos holgados en PC).",
    "Conformidad de eficiencia": "Sin normas de eficiencia declaradas.",
    "Analizabilidad": "No priorizada; el diagnóstico del libro se cubre con Testeabilidad (bean-check, bean-doctor).",
    "Estabilidad": "Requiere historial de fallas tras mantenimiento (issues), no accesible en este entorno.",
    "Conformidad de mantenibilidad": "Sin normas declaradas.",
    "Adaptabilidad": "portability se concentró en Reemplazabilidad (migración 2.x a 3.x).",
    "Co-existencia": "Herramienta de archivos locales sin recursos compartidos en conflicto.",
    "Conformidad de portabilidad": "Sin normas declaradas.",
}

# ---------------------------------------------------------------- Componentes
COMPONENTES = {
    "C1": ("Analizador y cargador",
           "beancount.parser (lexer/gramática en C, _parser) y beancount.loader: lectura del texto, sintaxis, include, option, "
           "caché pickle. Se ejercita con bean-check, bean-doctor lex/parse/roundtrip y la API loader."),
    "C2": ("Núcleo contable",
           "beancount.core, beancount.ops y beancount.plugins: interpolación y booking de lotes, inventarios, validaciones "
           "(cuentas abiertas, monedas, aserciones balance, pad), precios y complementos."),
    "C3": ("Herramientas de línea de comandos",
           "bean-check, bean-format, bean-example, bean-doctor (beancount 3.2.3) y bean-query (beanquery 0.2.0): "
           "interfaz que usa el usuario final, códigos de salida, mensajes y formatos de salida."),
}

# ---------------------------------------------------------------- RNF
RNF = [
    ("RNF-01", "Exactitud de cálculo", "Todo saldo, total, conversión y costo calculado debe coincidir exactamente (aritmética decimal) con un cálculo independiente; tolerancia 0.", "Precisión", ["001", "002", "003"]),
    ("RNF-02", "Integridad del libro", "Ninguna herramienta debe modificar el archivo .beancount de entrada salvo petición explícita; la caché corrupta o desactualizada no debe producir resultados erróneos.", "Seguridad", ["006", "007"]),
    ("RNF-03", "Validación de reglas contables", "Toda operación contable ilegal especificada en la documentación (transacción desbalanceada, cuenta no abierta o cerrada, moneda no permitida, aserción fallida, lote inexistente, etc.) debe ser rechazada con error.", "Seguridad", ["005"]),
    ("RNF-04", "Fiabilidad en operación", "Sobre libros válidos, las herramientas no deben fallar; la suite de pruebas incluida debe pasar en la versión publicada.", "Madurez", ["008", "009", "010"]),
    ("RNF-05", "Robustez ante entradas defectuosas", "Ante entradas malformadas o mal uso, la herramienta no debe terminar con traza (traceback) no controlada; debe reportar el error con código de salida distinto de 0 y seguir procesando lo válido.", "Tolerancia a fallos", ["011", "012", "013"]),
    ("RNF-06", "Mensajes y convenciones de la CLI", "Los errores deben indicar archivo:línea y la causa en términos contables; las herramientas deben seguir convenciones homogéneas (--help, --version, códigos de salida, stdout/stderr) y advertir antes de operaciones con riesgo de pérdida de datos.", "Operabilidad", ["014", "015", "016"]),
    ("RNF-07", "Tiempo de respuesta", "Cargar y validar un libro personal típico (≈ 4 años, ≈ 1 500 transacciones) debe tomar en promedio ≤ 1 s; un libro grande (100 000 transacciones) ≤ 10 s en el peor caso.", "Comportamiento en el tiempo", ["017", "018"]),
    ("RNF-08", "Verificabilidad", "El usuario y el mantenedor deben poder verificar el libro y el código con funciones incorporadas (bean-check, balance, bean-doctor, suite de pruebas), en forma selectiva y en menos de 5 s por corrección.", "Testeabilidad", ["020", "021", "022"]),
    ("RNF-09", "Configurabilidad", "El comportamiento (moneda operativa, método de costeo, nombres de cuentas raíz, complementos) debe poder cambiarse por option/plugin sin modificar código.", "Cambiabilidad", ["019"]),
    ("RNF-10", "Instalación", "Debe instalarse y reinstalarse con pip en un entorno limpio sin compilar código (wheel) y quedar operativo.", "Instalabilidad", ["023"]),
    ("RNF-11", "Compatibilidad con libros de la v2", "Los libros válidos en Beancount 2.3.6 deben cargarse en 3.2.3 con los mismos saldos; las funciones usadas en v2 deben seguir disponibles o tener reemplazo documentado.", "Reemplazabilidad", ["024", "025"]),
    ("RNF-12", "Intercambio de datos", "La salida de consultas (CSV, texto, beancount) y de errores (JSON) debe poder leerse por otras herramientas.", "Interoperabilidad", ["004"]),
]

# ---------------------------------------------------------------- Métricas externas (9126-2)
# tipo: abs_alto (0..1, mayor mejor, S=X), tasa_cero (X=A/T, menor mejor, S=1-A/N),
#       densidad (X=A1/A2 menor mejor, S=1-X), ratio_tiempo (X=T/Tref, S=1 si X<=1 si no 1/X),
#       tiempo (X=segundos, menor mejor, S=min(1,U/X))
METRICAS = [
    dict(n="001", tabla="Tabla 8.1.2", sub="Precisión", nombre="Precisión esperada",
         proposito="¿Cuán frecuente no son aceptables las diferencias entre los resultados reales y los resultados razonablemente esperados?",
         metodo="Ejecutar casos de entrada/salida cuyo resultado esperado está documentado (interpolación de montos omitidos, booking FIFO, pad, tolerancias, include, pushtag, consultas) y contar los casos con diferencia inaceptable.",
         formula="X = A / T", vars={"A": "Número de casos con diferencia respecto al resultado razonablemente esperado más allá de lo aceptable", "T": "Tiempo de operación de la campaña (h)", "N": "Número de casos evaluados (solo para normalizar)"},
         rango="0 <= X", interp="Lo más cercano a 0,0 es lo mejor", tipo="tasa_cero", umbral=0.0, op="<=",
         just_umbral="En contabilidad de partida doble ninguna diferencia respecto al resultado esperado es aceptable: X debe ser 0 (A = 0)."),
    dict(n="002", tabla="Tabla 8.1.2", sub="Precisión", nombre="Exactitud de cálculo",
         proposito="¿Cuán frecuente los usuarios finales encuentran resultados inexactos?",
         metodo="Comparar cada saldo cuenta-moneda, cada expresión aritmética y cada total de consulta con un oráculo independiente (generador propio con Decimal) y contar los cálculos inexactos.",
         formula="X = A / T", vars={"A": "Número de cálculos inexactos encontrados", "T": "Tiempo de operación de la campaña (h)", "N": "Número de cálculos verificados (solo para normalizar)"},
         rango="0 <= X", interp="Lo más cercano a 0,0 es lo mejor", tipo="tasa_cero", umbral=0.0, op="<=",
         just_umbral="Un solo saldo inexacto invalida el estado financiero: X = 0."),
    dict(n="003", tabla="Tabla 8.1.2", sub="Precisión", nombre="Precisión",
         proposito="¿Cuán frecuente los usuarios finales encuentran resultados con precisión inadecuada?",
         metodo="Ingresar cantidades con muchos decimales, sumas que fallan en coma flotante (0.1+0.2), cantidades de 8 decimales y montos grandes, y verificar que la precisión de los resultados sea la requerida (decimal exacto).",
         formula="X = A / T", vars={"A": "Número de resultados con un nivel de precisión diferente al requerido", "T": "Tiempo de operación de la campaña (h)", "N": "Número de resultados verificados (solo para normalizar)"},
         rango="0 <= X", interp="Lo más cercano a 0,0 es lo mejor", tipo="tasa_cero", umbral=0.0, op="<=",
         just_umbral="Beancount promete aritmética decimal exacta; cualquier pérdida de precisión es un defecto: X = 0."),
    dict(n="004", tabla="Tabla 8.1.3", sub="Interoperabilidad", nombre="Intercambiabilidad de datos (basado en formato de datos)",
         proposito="¿Cuán correctamente han sido implementadas las funciones de interfaz de intercambio para la transferencia de datos especificados?",
         metodo="Producir cada formato de intercambio (texto beancount, CSV, texto, JSON) y leerlo con otro software (parser csv/json de Python, Beancount 2.3.6, el propio cargador) verificando el contenido.",
         formula="X = A / B", vars={"A": "Número de formatos de datos intercambiados exitosamente con otro software", "B": "Número total de formatos de datos a ser intercambiados"},
         rango="0 <= X <= 1", interp="Lo más cerca de 1,0 es lo mejor", tipo="abs_alto", umbral=0.90, op=">=",
         just_umbral="Atributo secundario: se acepta como máximo un formato con problemas de cada diez."),
    dict(n="005", tabla="Tabla 8.1.4", sub="Seguridad", nombre="Control de acceso (reinterpretado: control de operaciones contables ilegales)",
         proposito="¿Cuán controlable es el acceso al sistema? Reinterpretado: ¿cuán controlable es el acceso a las cuentas, es decir, se rechazan las operaciones contables ilegales?",
         metodo="Beancount no tiene usuarios ni login. Se reinterpreta 'operación ilegal' como operación contable prohibida por la especificación del lenguaje (usar una cuenta no abierta o cerrada, moneda no permitida, transacción desbalanceada, aserción falsa, reducir un lote inexistente, etc.). Se ejecuta un caso por tipo y se cuenta cuántos son detectados.",
         formula="X = A / B", vars={"A": "Número de tipos de operaciones ilegales detectadas", "B": "Número de tipos de operaciones ilegales especificadas"},
         rango="0 <= X <= 1", interp="Lo más cerca de 1,0 es lo mejor", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="Las reglas contables son el mecanismo de control del producto; se exige detectar al menos 95 % de los tipos especificados."),
    dict(n="006", tabla="Tabla 8.1.4", sub="Seguridad", nombre="Prevención de corrupción de datos (a) – eventos mayores",
         proposito="¿Cuál es la frecuencia de eventos de corrupción de datos?",
         metodo="Ejecutar casos que intentan corromper el libro o los datos (herramientas de solo lectura, ejecuciones concurrentes, interrupción con SIGKILL, caché corrupta, reformateo). Evento mayor: el archivo fuente cambia o se pierde de forma no reproducible.",
         formula="X = 1 - A / N", vars={"A": "Número de veces que ocurrió un evento de mayor corrupción de datos", "N": "Número de casos de prueba que trataron de causar corrupción"},
         rango="0 <= X <= 1", interp="Lo más cerca de 1,0 es lo mejor", tipo="abs_alto", umbral=1.00, op=">=",
         just_umbral="Perder o alterar el libro del usuario es inaceptable: no se admite ningún evento mayor (X = 1)."),
    dict(n="007", tabla="Tabla 8.1.4", sub="Seguridad", nombre="Prevención de corrupción de datos (b) – eventos menores",
         proposito="¿Cuál es la frecuencia de eventos de corrupción de datos?",
         metodo="Mismos casos que 006. Evento menor: datos derivados (caché, resultado en memoria, archivo de salida) inconsistentes pero recuperables (p. ej. con -C).",
         formula="Y = 1 - B / N", vars={"B": "Número de veces que ocurrió un evento de menor corrupción de datos", "N": "Número de casos de prueba que trataron de causar corrupción"},
         rango="0 <= Y <= 1", interp="Lo más cerca de 1,0 es lo mejor", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="Los eventos menores son recuperables, pero un resultado basado en caché obsoleta engaña al usuario; se tolera 5 %."),
    dict(n="008", tabla="Tabla 8.2.1", sub="Madurez", nombre="Densidad de fallas contra los casos de prueba",
         proposito="¿Cuántas fallas fueron detectadas durante el periodo de prueba definido?",
         metodo="Campaña propia de caja negra sobre libros VÁLIDOS (20 semillas de bean-example y 3 libros sintéticos): cada herramienta/función se ejecuta y se cuenta como falla todo código de salida inesperado, traza o error espurio.",
         formula="X = A1 / A2", vars={"A1": "Número de fallas detectadas", "A2": "Número de casos de prueba ejecutados"},
         rango="0 <= X", interp="Fase final (versión publicada): cuanto más pequeño, mejor", tipo="densidad", umbral=0.05, op="<=",
         just_umbral="Versión estable publicada: se acepta como máximo 5 % de casos con falla sobre entradas válidas. Normalización 0-1: S = 1 - X (A1 <= A2)."),
    dict(n="009", tabla="Tabla 8.2.1", sub="Madurez", nombre="Cobertura de prueba (especificación del escenario de operación)",
         proposito="¿Cuántos casos de prueba requeridos se han ejecutado durante la prueba?",
         metodo="Ejecutar la suite oficial (pytest) del tag 3.2.3 y comparar casos realmente ejecutados con casos definidos, por componente (ruta del módulo de prueba).",
         formula="X = A / B", vars={"A": "Número de casos de prueba realmente ejecutados", "B": "Número de casos de prueba a ser ejecutados (definidos)"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es la mejor cobertura", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="Se espera que como máximo 5 % de las pruebas quede omitido por dependencias opcionales."),
    dict(n="010", tabla="Tabla 8.2.1", sub="Madurez", nombre="Madurez de la prueba",
         proposito="¿Está el producto bien probado?",
         metodo="De la misma ejecución de la suite oficial, contar casos que pasan frente a casos ejecutados (los xfail cuentan como no pasados).",
         formula="X = A / B", vars={"A": "Número de casos de prueba pasados", "B": "Número de casos de prueba ejecutados para respaldar los requerimientos"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.98, op=">=",
         just_umbral="Una versión publicada debe pasar prácticamente toda su suite; se admiten solo fallos conocidos (xfail) hasta 2 %."),
    dict(n="011", tabla="Tabla 8.2.2", sub="Tolerancia a fallos", nombre="Prevención de caídas",
         proposito="¿Con qué frecuencia el producto software causa caídas en el ambiente total de producción?",
         metodo="Inyectar entradas defectuosas (archivos truncados, binarios, UTF-8 inválido, include cíclico, cantidades absurdas, consultas inválidas, etc.) y contar caídas: traza no controlada, señal o bloqueo > 60 s.",
         formula="X = 1 - A / B", vars={"A": "Número de caídas", "B": "Número de fallas (entradas defectuosas inyectadas)"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="RNF-05: ninguna entrada defectuosa debería tumbar la herramienta; se tolera 5 %."),
    dict(n="012", tabla="Tabla 8.2.2", sub="Tolerancia a fallos", nombre="Prevención de fallas",
         proposito="¿Cuántos tipos de errores fueron causados bajo el control para evitar fallas críticas y serias?",
         metodo="Insertar un error de cierto tipo en medio de un libro válido y verificar que la herramienta no se detenga por completo: reporta el error y sigue entregando el resto de resultados (falla evitada).",
         formula="X = A / B", vars={"A": "Número de casos de tipos de error en que se evitó la falla crítica o seria", "B": "Número de casos de tipos de error ejecutados"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.90, op=">=",
         just_umbral="Un error local no debe impedir trabajar con el resto del libro; se exige 90 %."),
    dict(n="013", tabla="Tabla 8.2.2", sub="Tolerancia a fallos", nombre="Prevención de operación incorrecta",
         proposito="¿Cuántas funciones son implementadas con capacidad de prevención de operación incorrecta?",
         metodo="Ejecutar operaciones incorrectas del usuario (archivo inexistente, directorio, sin permisos, vacío, opciones o argumentos inválidos, option/plugin inexistentes) y contar las que se previenen con mensaje claro y código de salida distinto de 0 sin traza.",
         formula="X = A / B", vars={"A": "Número de casos de operación incorrecta en que se previno la falla", "B": "Número de casos de prueba de operación incorrecta ejecutados"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.90, op=">=",
         just_umbral="RNF-05: el mal uso habitual debe manejarse con mensaje; se exige 90 %."),
    dict(n="014", tabla="Tabla 8.3.3 a)", sub="Operabilidad", nombre="Consistencia operacional en el uso",
         proposito="¿Cuán consistente es el componente de la interfaz de usuario?",
         metodo="Lista de verificación objetiva: los mensajes de error siguen el patrón 'archivo:línea: descripción'; las herramientas aceptan --help y --version, usan códigos de salida 0/≠0 coherentes y separan stdout/stderr; las salidas tabulares tienen encabezados legibles.",
         formula="X = 1 - A / B", vars={"A": "Número de mensajes o funciones con inconsistencias inaceptables", "B": "Número de mensajes o funciones examinados"},
         rango="0 <= X <= 1", interp="Lo más cercano de 1,0 es lo mejor", tipo="abs_alto", umbral=0.85, op=">=",
         just_umbral="Se acepta como máximo 15 % de elementos inconsistentes en una CLI compuesta por varias herramientas."),
    dict(n="015", tabla="Tabla 8.3.3 d)", sub="Operabilidad", nombre="Mensajes de error autoexplicativos",
         proposito="¿En qué proporción de las condiciones de error el usuario propone la acción correcta de recuperación?",
         metodo="Para cada condición de error, el evaluador lee SOLO el mensaje y decide si permite proponer la corrección. Criterio explícito: el mensaje indica ubicación (archivo:línea o elemento) y la causa con términos del dominio (palabras clave predefinidas). VALIDAR POR EL GRUPO.",
         formula="X = A / B", vars={"A": "Número de condiciones de error para las que se propone la acción correcta", "B": "Número de condiciones de error probadas"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.80, op=">=",
         just_umbral="Al menos 4 de cada 5 errores deben poder corregirse leyendo solo el mensaje."),
    dict(n="016", tabla="Tabla 8.3.3 e)", sub="Operabilidad", nombre="Recuperabilidad de error operacional en uso",
         proposito="¿Puede el usuario recuperarse fácilmente de la peor situación?",
         metodo="Ejecutar errores u operaciones de riesgo del usuario (sobrescribir el libro con -o de bean-format, bean-query y bean-example; formatear un archivo que no es un libro; Ctrl-C a mitad de la validación; editar el libro conservando su fecha con caché vigente; consultar un libro con errores) y contar las situaciones de recuperación insatisfactoria en las que el sistema no informó del riesgo.",
         formula="X = 1 - A / B", vars={"A": "Número de situaciones de recuperación insatisfactoria sin aviso del riesgo", "B": "Número de errores de usuario o cambios"},
         rango="0 <= X <= 1", interp="La norma dice 'más cercano a 0,0 es lo mejor', pero contradice la fórmula; se resuelve: más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.80, op=">=",
         just_umbral="Se tolera que 1 de cada 5 operaciones de riesgo no advierta, siempre que no destruya datos de forma irreversible."),
    dict(n="017", tabla="Tabla 8.4.1 a)", sub="Comportamiento en el tiempo", nombre="Tiempo medio de respuesta",
         proposito="¿Cuál es el tiempo promedio de espera que el usuario experimenta después de emitir una solicitud hasta que ésta se completa?",
         metodo="Ejecutar 10 veces cada tarea típica sobre el libro de ejemplo (≈ 4 años) sin caché: parseo (C1), carga+validación con bean-check (C2), consulta de saldos con bean-query (C3). Tmedio = promedio.",
         formula="X = Tmedio / TXmedio", vars={"Tmedio": "Tiempo medio de respuesta medido (s)", "TXmedio": "Tiempo medio de respuesta requerido (1,0 s)", "N": "Número de evaluaciones (10)"},
         rango="0 <= X", interp="El valor más cercano a 1,0 y menor que 1,0 es lo mejor", tipo="ratio_tiempo", umbral=1.0, op="<=",
         just_umbral="1 s es el límite clásico para que el usuario no pierda el hilo (Nielsen, 1993). Normalización: S = 1 si X <= 1, si no S = 1/X."),
    dict(n="018", tabla="Tabla 8.4.1 a)", sub="Comportamiento en el tiempo", nombre="Ratio de tiempo de respuesta en el peor caso",
         proposito="¿Cuál es el límite absoluto del tiempo requerido para completar una función en el peor caso?",
         metodo="Emular la carga máxima con un libro sintético de 100 000 transacciones; ejecutar 5 veces cada tarea sin caché y tomar el máximo.",
         formula="X = Tmax / Rmax", vars={"Tmax": "Máximo tiempo de respuesta medido (s)", "Rmax": "Tiempo de respuesta máximo requerido (10 s)", "N": "Número de evaluaciones (5)"},
         rango="0 < X", interp="El valor más cercano a 1,0 y menor que 1 es lo mejor", tipo="ratio_tiempo", umbral=1.0, op="<=",
         just_umbral="10 s es el límite de atención del usuario en una tarea interactiva (Nielsen, 1993). Normalización: S = 1 si X <= 1, si no S = 1/X."),
    dict(n="019", tabla="Tabla 8.5.2", sub="Cambiabilidad", nombre="Modificabilidad parametrizada",
         proposito="¿Puede el usuario o el responsable de mantenimiento cambiar fácilmente parámetros del software para resolver problemas?",
         metodo="Intentar cambiar el comportamiento con option, plugin y opciones de la CLI, y verificar que el efecto esperado aparece en la salida.",
         formula="X = 1 - A / B", vars={"A": "Número de casos en que falla el cambio mediante parámetros", "B": "Número de casos en que se intenta cambiar el software mediante parámetros"},
         rango="0 <= X <= 1", interp="El valor más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.90, op=">=",
         just_umbral="Las opciones documentadas deben funcionar; se tolera 10 %."),
    dict(n="020", tabla="Tabla 8.5.4", sub="Testeabilidad", nombre="Disponibilidad de la función de pruebas incorporada",
         proposito="¿Pueden el usuario y el responsable de mantenimiento realizar pruebas operacionales sin preparar mecanismos de prueba adicionales?",
         metodo="Para cada oportunidad de prueba (tras un cambio en el libro o en el código) usar solo funciones incorporadas: bean-check, balance, bean-doctor (lex, parse, roundtrip, missing-open, context, display-context), salida --json, suite pytest incluida.",
         formula="X = A / B", vars={"A": "Número de casos en que se puede usar adecuadamente la función de prueba incorporada", "B": "Número de casos de oportunidades de prueba"},
         rango="0 <= X <= 1", interp="Lo más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.80, op=">=",
         just_umbral="La verificabilidad es un atributo principal: al menos 80 % de las oportunidades deben resolverse sin herramientas externas."),
    dict(n="021", tabla="Tabla 8.5.4", sub="Testeabilidad", nombre="Eficiencia de pruebas después de la corrección",
         proposito="¿Pueden el usuario y el responsable de mantenimiento realizar fácilmente pruebas operacionales y determinar si el software está listo para operar?",
         metodo="Inyectar una falla, aplicar la corrección y cronometrar la re-prueba que confirma que quedó resuelta: C1/C2 = mutación de una línea del código fuente (printer, options, loader, amount, inventory, balance) y re-ejecución del módulo pytest correspondiente; C3 = error insertado en el libro y re-ejecución de bean-check. Se mide solo el tiempo de ejecución de la prueba; el tiempo humano de decisión se excluye. Solo cuentan las fallas que la prueba detectó y luego confirmó como resueltas.",
         formula="X = Sum(T) / N", vars={"T": "Tiempo que toma la prueba para confirmar la corrección (s)", "N": "Número de fallas resueltas"},
         rango="0 < X", interp="El más pequeño es lo mejor", tipo="tiempo", umbral=5.0, op="<=",
         just_umbral="RNF-08: un ciclo editar-verificar interactivo debe tomar ≤ 5 s. Normalización: S = min(1, 5/X)."),
    dict(n="022", tabla="Tabla 8.5.4", sub="Testeabilidad", nombre="Capacidad de reanudar la prueba",
         proposito="¿Pueden el usuario y el responsable de mantenimiento realizar pruebas con puntos de control y reanudarlas?",
         metodo="Intentar pausar/acotar la prueba en un punto deseado y reanudarla: verificar una región o una línea (bean-doctor region/context), un corte de fecha (balance, FROM ... CLOSE ON), un módulo o caso de pytest, reejecutar solo los fallidos (--lf), detenerse en la primera falla (-x).",
         formula="X = A / B", vars={"A": "Número de casos en que se puede pausar y reanudar la prueba en el punto deseado", "B": "Número de casos de pausa intentados"},
         rango="0 <= X <= 1", interp="Lo más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.80, op=">=",
         just_umbral="Al menos 80 % de los puntos de control deseados deben estar soportados."),
    dict(n="023", tabla="Tabla 8.6.2", sub="Instalabilidad", nombre="Facilidad de reinstalación",
         proposito="¿Puede el usuario o responsable de mantenimiento reinstalar fácilmente el software?",
         metodo="Reinstalar en distintos escenarios (entorno limpio en Python 3.11/3.12/3.13 con pip, entorno limpio con uv, --force-reinstall, desinstalar e instalar, bajar a 3.2.2 y volver a 3.2.3) y después ejecutar una prueba de humo por componente.",
         formula="X = 1 - A / B", vars={"A": "Número de casos en que falla la reinstalación", "B": "Número total de casos de reinstalación intentados"},
         rango="0 <= X <= 1", interp="El más cercano a 1,0 es lo mejor", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="Con wheels publicados la reinstalación debe funcionar prácticamente siempre."),
    dict(n="024", tabla="Tabla 8.6.4", sub="Reemplazabilidad", nombre="Uso continuo de los datos",
         proposito="¿Puede el usuario continuar usando los mismos datos después de reemplazar el software?",
         metodo="Tomar libros válidos en Beancount 2.3.6 (generados por su bean-example y libros sintéticos) y cargarlos en 3.2.3: misma ausencia de errores (C1), mismos saldos (C2) y misma respuesta de la CLI (C3).",
         formula="X = A / B", vars={"A": "Número de datos (libros) confirmados como utilizables tras el reemplazo", "B": "Número de datos planificados para reutilizarse"},
         rango="0 <= X <= 1", interp="El más grande es lo mejor", tipo="abs_alto", umbral=0.95, op=">=",
         just_umbral="Los libros son datos de largo plazo: casi todos deben seguir siendo utilizables tras la migración."),
    dict(n="025", tabla="Tabla 8.6.4", sub="Reemplazabilidad", nombre="Inclusividad de funciones",
         proposito="¿Puede el usuario continuar usando funciones similares después de reemplazar el software anterior?",
         metodo="Listar funciones de 2.3.6 (API de carga, complementos, herramientas CLI) y probar si en 3.2.3 existen y dan resultados similares sin cambios.",
         formula="X = A / B", vars={"A": "Número de funciones que producen resultados similares sin requerir cambios", "B": "Número de funciones probadas similares a las del software reemplazado"},
         rango="0 <= X <= 1", interp="El más grande es lo mejor", tipo="abs_alto", umbral=0.80, op=">=",
         just_umbral="En un cambio de versión mayor se admite que hasta 20 % de funciones se haya movido a otros paquetes."),
]

UMBRAL_SUB = 0.80  # sub-característica verde si puntaje ponderado >= 0.80


def pesos():
    """Devuelve (peso_atributo, peso_sub, peso_metrica) como Fraction."""
    s = scores()
    tot = sum(s.values())
    pa = {a: Fraction(s[a], tot) for a in INCLUIDOS}
    ps = {}
    for a in INCLUIDOS:
        for sub, f in MAPEO[a]:
            ps[sub] = ps.get(sub, 0) + pa[a] * f
    cnt = {}
    for m in METRICAS:
        cnt[m["sub"]] = cnt.get(m["sub"], 0) + 1
    pm = {m["n"]: ps[m["sub"]] / cnt[m["sub"]] for m in METRICAS}
    return pa, ps, pm


def subs_principales():
    s = scores()
    out = set()
    for a in INCLUIDOS:
        if s[a] >= UMBRAL_PRINCIPAL:
            for sub, _ in MAPEO[a]:
                out.add(sub)
    return out


def caracteristica_de(sub):
    for car, ab, subs in ISO_ARBOL:
        if sub in subs:
            return car, ab
    raise KeyError(sub)


if __name__ == "__main__":
    pa, ps, pm = pesos()
    print(scores())
    print({k: float(v) for k, v in ps.items()}, float(sum(ps.values())))
    print(float(sum(pm.values())), len(METRICAS))
    print(subs_principales())
