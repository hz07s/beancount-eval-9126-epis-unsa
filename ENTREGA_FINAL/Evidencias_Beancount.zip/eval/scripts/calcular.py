# -*- coding: utf-8 -*-
"""Fase 5: calcula, a partir de out/*.json, los valores de cada métrica por componente,
la normalización 0-1, el cumplimiento del umbral, el puntaje por sub-característica y el
puntaje global ponderado. Escribe out/resultados.json (fuente única para Excel e informe)."""
import json
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(__file__))
from catalogo import (METRICAS, MAPEO, ISO_ARBOL, ABREV_SUB, UMBRAL_SUB, caracteristica_de, pesos,
                      scores, subs_principales, INCLUIDOS)

OUT = "/home/claude/eval/out"
COMPS = ("C1", "C2", "C3")


def J(m):
    return json.load(open(f"{OUT}/{m}.json", encoding="utf-8"))


def r4(x):
    return None if x is None else round(float(x), 4)


def conteo(casos, comp=None, campo="cuenta_A"):
    cs = [c for c in casos if comp is None or c["comp"] == comp]
    return sum(1 for c in cs if c.get(campo)), len(cs)


def calcular():
    pa, ps, pm = pesos()
    res = []
    for m in METRICAS:
        n, tipo = m["n"], m["tipo"]
        filas = {}
        fuente = n
        if n in ("006", "007"):
            fuente = "006_007"
        if n in ("009", "010"):
            fuente = "009_010"
        d = J(fuente)
        nota = d.get("nota", "")
        if n in ("001", "002", "003"):
            T_h = round(d["duracion_campana_s"] / 3600, 6)
            for c in COMPS + (None,):
                A, N = conteo(d["casos"], c)
                if N == 0:
                    continue
                X = A / T_h
                filas[c or "Total"] = dict(vals={"A": A, "T (h)": round(T_h, 6), "N": N}, X=X, S=1 - A / N)
        elif n == "006" or n == "007":
            campo = "cuenta_A" if n == "006" else "menor"
            for c in COMPS + (None,):
                A, N = conteo(d["casos"], c, campo)
                if N == 0:
                    continue
                X = 1 - A / N
                filas[c or "Total"] = dict(vals={("A" if n == "006" else "B"): A, "N": N}, X=X, S=X)
        elif n == "008":
            for c in COMPS + (None,):
                A, N = conteo(d["casos"], c)
                X = A / N
                filas[c or "Total"] = dict(vals={"A1": A, "A2": N}, X=X, S=1 - X)
        elif n in ("009", "010"):
            pc = d["fuente"]["por_componente"]
            tot = {k: sum(pc[c][k] for c in COMPS) for k in pc["C1"]}
            for c, v in list(pc.items()) + [("Total", tot)]:
                if n == "009":
                    A, B = v["ejec"], v["def_"]
                else:
                    A, B = v["pas"], v["ejec"]
                filas[c] = dict(vals={"A": A, "B": B}, X=A / B, S=A / B)
        elif n == "017" or n == "018":
            t = d["tiempos_s"]
            ref = d["TXmedio_s"] if n == "017" else d["Rmax_s"]
            allv = [x for v in t.values() for x in v]
            for c in COMPS + ("Total",):
                v = allv if c == "Total" else t[c]
                if n == "017":
                    Tm = statistics.mean(v)
                    X = Tm / ref
                    vals = {"Tmedio (s)": round(Tm, 4), "TXmedio (s)": ref, "N": len(v)}
                else:
                    Tm = max(v)
                    X = Tm / ref
                    vals = {"Tmax (s)": round(Tm, 4), "Rmax (s)": ref, "N": len(v)}
                filas[c] = dict(vals=vals, X=X, S=1.0 if X <= 1 else 1 / X)
        elif n == "021":
            for c in COMPS + (None,):
                ts = [x["tiempo_s"] for x in d["casos"] if (c is None or x["comp"] == c) and x.get("tiempo_s") is not None]
                X = sum(ts) / len(ts)
                filas[c or "Total"] = dict(vals={"Sum(T) (s)": round(sum(ts), 4), "N": len(ts)}, X=X, S=min(1.0, 5.0 / X))
        else:
            uno_menos = m["formula"].replace(" ", "").startswith("X=1-")
            for c in COMPS + (None,):
                A, B = conteo(d["casos"], c)
                if B == 0:
                    continue
                X = 1 - A / B if uno_menos else A / B
                filas[c or "Total"] = dict(vals={"A": A, "B": B}, X=X, S=X)
        for f in filas.values():
            f["X"], f["S"] = r4(f["X"]), r4(f["S"])
        tot = filas["Total"]
        X = tot["X"]
        pasa = X <= m["umbral"] if m["op"] == "<=" else X >= m["umbral"]
        car, ab = caracteristica_de(m["sub"])
        res.append(dict(n=n, nombre=m["nombre"], tabla=m["tabla"], sub=m["sub"], car=car, abrev_car=ab,
                        abrev_sub=ABREV_SUB[m["sub"]], codigo=f"{n}-{ab}.{ABREV_SUB[m['sub']]}",
                        peso_abs=float(pm[n]), umbral=m["umbral"], op=m["op"], formula=m["formula"],
                        filas=filas, X=X, S=tot["S"], pasa=bool(pasa), nota_fuente=nota, estado="MEDIDO"))
    # sub-características
    principales = subs_principales()
    subs = {}
    for car, ab, lista in ISO_ARBOL:
        for s in lista:
            ms = [x for x in res if x["sub"] == s]
            if not ms:
                subs[s] = dict(car=car, considerar="N", peso=0.0, tipo="no considerada", puntaje=None, color="gris")
                continue
            punt = sum(x["S"] * x["peso_abs"] for x in ms) / sum(x["peso_abs"] for x in ms)
            principal = s in principales
            color = ("verde" if punt >= UMBRAL_SUB else "rojo") if principal else "amarillo"
            subs[s] = dict(car=car, considerar="S", peso=float(ps[s]), tipo="principal" if principal else "secundaria",
                           puntaje=r4(punt), color=color, pasa=punt >= UMBRAL_SUB,
                           metricas=[x["n"] for x in ms], metricas_pasan=sum(x["pasa"] for x in ms))
    glob = sum(x["S"] * x["peso_abs"] for x in res)
    clasif = "MUY BUENO" if glob >= 0.95 else ("ACEPTABLE" if glob >= 0.80 else "NO ACEPTABLE")
    out = dict(metricas=res, subs=subs, global_=r4(glob), clasificacion=clasif,
               pesos_atributo={a: float(pa[a]) for a in INCLUIDOS}, scores=scores(),
               suma_pesos=round(sum(x["peso_abs"] for x in res), 10))
    json.dump(out, open(f"{OUT}/resultados.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    return out


if __name__ == "__main__":
    o = calcular()
    for x in o["metricas"]:
        print(f'{x["n"]} {x["sub"][:14]:<14} {x["nombre"][:44]:<44} X={x["X"]:<8} S={x["S"]:<7} umbral {x["op"]}{x["umbral"]:<5} {"PASA" if x["pasa"] else "NO PASA"}')
    for s, v in o["subs"].items():
        if v["considerar"] == "S":
            print(f'{s:<28} peso={v["peso"]:.4f} puntaje={v["puntaje"]} {v["color"]}')
    print("GLOBAL", o["global_"], o["clasificacion"], "suma pesos", o["suma_pesos"])
