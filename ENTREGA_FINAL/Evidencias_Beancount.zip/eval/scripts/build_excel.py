# -*- coding: utf-8 -*-
"""Rellena la plantilla Clarrus (Quality-Attributes-2013) para Beancount y agrega las hojas
'5 Mapeo ISO 9126' y '6 Métricas y resultados' con fórmulas vivas."""
import json
import os
import sys
from copy import copy

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.datavalidation import DataValidation

sys.path.insert(0, os.path.dirname(__file__))
from catalogo import (CLARRUS_ATRIBUTOS, INCLUIDOS, gana, JUSTIF_ORDEN, EXCEPCIONES, MAPEO, JUSTIF_MAPEO,
                      METRICAS, RNF, UMBRAL_PRINCIPAL, UMBRAL_SUB, ISO_ARBOL, PRODUCTO)

TPL = "/home/claude/tpl/Quality-Attributes-2013.xlsx"
DST = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/entrega/Quality-Attributes-Beancount.xlsx"
R = json.load(open("/home/claude/eval/out/resultados.json", encoding="utf-8"))
RM = {m["n"]: m for m in R["metricas"]}

F = lambda **k: Font(name="Arial", size=k.pop("size", 10), **k)
HDR = PatternFill("solid", fgColor="1F3864")
SUB = PatternFill("solid", fgColor="D9E1F2")
INP = PatternFill("solid", fgColor="FFF2CC")
VERDE, ROJO, AMAR, GRIS = (PatternFill("solid", fgColor=c) for c in ("C6EFCE", "FFC7CE", "FFEB9C", "D9D9D9"))
th = Side(style="thin", color="999999")
BOX = Border(left=th, right=th, top=th, bottom=th)
WR = Alignment(wrap_text=True, vertical="top")
CEN = Alignment(horizontal="center", vertical="center", wrap_text=True)

wb = openpyxl.load_workbook(TPL)
ORDEN = [a for a, *_ in CLARRUS_ATRIBUTOS]           # filas 10..25 de la hoja 1
assert ORDEN == [wb["1 Attribute In or Out"].cell(10 + i, 1).value for i in range(16)]

# ------------------------------------------------------------- hoja 1
ws = wb["1 Attribute In or Out"]
ws["A1"] = "Quantifying Quality Attributes — Beancount 3.2.3 (evaluación EPIS-UNSA)"
for i, (a, vista, razon, inc) in enumerate(CLARRUS_ATRIBUTOS):
    r = 10 + i
    ws.cell(r, 3, razon).alignment = WR
    ws.cell(r, 3).font = F()
    ws.cell(r, 4, inc).font = F(bold=True)
    ws.cell(r, 4).alignment = CEN
    ws.row_dimensions[r].height = 54
ws.column_dimensions["C"].width = 95
dv = DataValidation(type="list", formula1="=Support!$A$4:$A$5", allow_blank=False)
ws.add_data_validation(dv)
dv.add("D10:D25")

# ------------------------------------------------------------- hoja 2
ws = wb["2 Attribute Prioritization"]
fila2 = {a: 11 + i for i, a in enumerate(ORDEN)}      # columna = fila - 11 + D
for i, a in enumerate(ORDEN):
    for j, b in enumerate(ORDEN):
        if j <= i:
            continue
        c = ws.cell(11 + i, 4 + j)
        if a in INCLUIDOS and b in INCLUIDOS:
            c.value = "<" if gana(a, b) else "^"
        else:
            c.value = None
        c.alignment = CEN
for r in range(11, 27):
    ws.cell(r, 20).value = f"='1 Attribute In or Out'!C{r - 1}"     # corrige T18 (#REF!)
dv2 = DataValidation(type="list", formula1="=Support!$A$8:$A$9", allow_blank=True)
ws.add_data_validation(dv2)
dv2.add("E11:S25")
for a in ORDEN:
    if a not in INCLUIDOS:
        ws.row_dimensions[fila2[a]].hidden = True
        ws.column_dimensions[L(4 + ORDEN.index(a))].hidden = True
ws["A28"] = ("Notas: '<' = el atributo de la fila (izquierda) es más importante; '^' = el de la columna (arriba). "
             "Excepción a la transitividad: interoperability > installability. Atributo principal si Score >= "
             f"{UMBRAL_PRINCIPAL}. Juicio del evaluador: VALIDAR POR EL GRUPO.")
ws["A28"].font = F(italic=True)

# ------------------------------------------------------------- hoja 3
ws = wb["3 Criteria"]
CRIT = {
    "Accuracy": ("001, 002, 003", "RNF-01"), "Access Control": ("005", "RNF-03"), "Security": ("006, 007", "RNF-02"),
    "Application Reliability": ("008, 009, 010", "RNF-04"), "Error handling": ("011, 013, 015", "RNF-05, RNF-06"),
    "Error tolerance": ("012", "RNF-05"), "Operability": ("014, 016", "RNF-06"), "Response times": ("017, 018", "RNF-07"),
    "User Testability": ("020, 022", "RNF-08"), "Failure Maintenance Testability": ("021", "RNF-08"),
    "Expandability": ("019", "RNF-09"), "System Compatibility": ("023", "RNF-10"),
    "Software system independence": ("024, 025", "RNF-11"), "Interface standards": ("004", "RNF-12"),
}
cols3 = {ws.cell(10, c).value: c for c in range(2, 17)}
visibles = [cols3[a] for a in cols3 if a in INCLUIDOS]
ws.cell(11, 19, "Métricas 9126-2").font = F(bold=True)
ws.cell(11, 20, "RNF").font = F(bold=True)
for r in range(12, 60):
    nom = ws.cell(r, 1).value
    if not nom:
        continue
    usa = nom in CRIT
    ws.cell(r, 17, "Yes" if usa else "No").alignment = CEN
    if usa:
        ws.cell(r, 19, CRIT[nom][0]); ws.cell(r, 20, CRIT[nom][1])
        for c in (1, 17, 19, 20):
            ws.cell(r, c).fill = INP
    elif not any(ws.cell(r, c).value == "x" for c in visibles):
        ws.row_dimensions[r].hidden = True
for a, c in cols3.items():
    if a not in INCLUIDOS:
        ws.column_dimensions[L(c)].hidden = True
ws.column_dimensions["S"].width = 16
ws.column_dimensions["T"].width = 16
dv3 = DataValidation(type="list", formula1="=Support!$A$4:$A$5", allow_blank=True)
ws.add_data_validation(dv3)
dv3.add("Q12:Q59")

# ------------------------------------------------------------- hoja 4
ws = wb["4 Measures"]
for r in range(8, 30):
    for c in range(1, 5):
        ws.cell(r, c).value = None
ws.cell(8, 1, "Criterion"); ws.cell(8, 2, "Measure (requisito no funcional medible de Beancount)"); ws.cell(8, 3, "RNF / Sub-característica"); ws.cell(8, 4, "Métricas")
for c in range(1, 5):
    ws.cell(8, c).font = F(bold=True)
crit_de_rnf = {}
for k, (m, rn) in CRIT.items():
    for x in rn.split(", "):
        crit_de_rnf.setdefault(x, []).append(k)
for i, (rid, nombre, texto, sub, mets) in enumerate(RNF):
    r = 9 + i
    ws.cell(r, 1, " / ".join(crit_de_rnf.get(rid, [])))
    ws.cell(r, 2, f"{rid} {nombre}: {texto}")
    ws.cell(r, 3, f"{rid} → {sub}")
    ws.cell(r, 4, ", ".join(mets))
    for c in range(1, 5):
        ws.cell(r, c).alignment = WR
        ws.cell(r, c).font = F()
    ws.row_dimensions[r].height = 58
ws.column_dimensions["B"].width = 90
ws.column_dimensions["C"].width = 30
ws.column_dimensions["D"].width = 16
ws.cell(23, 1, "Notes:").font = F(bold=True)
ws.cell(24, 1, "='1 Attribute In or Out'!A28"); ws.cell(25, 1, "='1 Attribute In or Out'!A29"); ws.cell(26, 1, "='1 Attribute In or Out'!A30")

# ------------------------------------------------------------- hoja 5
ws = wb.create_sheet("5 Mapeo ISO 9126", index=4)
ws["A1"] = "Paso 5 (agregado): mapeo atributo Clarrus → sub-característica ISO/IEC 9126-1 y cálculo de pesos"
ws["A1"].font = F(size=12, bold=True)
ws["A2"] = ("Regla: peso del atributo = Score / suma de Scores (hoja 2); peso de la sub-característica = Σ peso atributo × fracción; "
            "peso absoluto por métrica = peso de la sub-característica / n.º de métricas de esa sub-característica (hoja 6).")
ws["A2"].alignment = WR
ws.merge_cells("A2:H2")
ws.row_dimensions[2].height = 32
H = ["Atributo Clarrus", "Score (hoja 2)", "Principal (Score >= umbral)", "Peso atributo", "Sub-característica ISO 9126-1", "Fracción", "Peso aportado", "Justificación del mapeo"]
for c, h in enumerate(H, 1):
    x = ws.cell(4, c, h); x.font = F(bold=True, color="FFFFFF"); x.fill = HDR; x.alignment = CEN; x.border = BOX
ws["J4"] = "Umbral principal"; ws["K4"] = UMBRAL_PRINCIPAL
ws["K4"].fill = INP
ws["J4"].font = F(bold=True)
r = 5
filas_map = []
for a in sorted(INCLUIDOS, key=lambda a: -R["scores"][a]):
    for sub, fr in MAPEO[a]:
        ws.cell(r, 1, a)
        ws.cell(r, 2, f"=INDEX('2 Attribute Prioritization'!$C$11:$C$26,MATCH(A{r},'2 Attribute Prioritization'!$A$11:$A$26,0))")
        ws.cell(r, 3, f'=IF(B{r}>=$K$4,"Sí","No")')
        ws.cell(r, 4, f"=B{r}/SUMPRODUCT(('2 Attribute Prioritization'!$B$11:$B$26=\"Yes\")*'2 Attribute Prioritization'!$C$11:$C$26)")
        ws.cell(r, 5, sub)
        ws.cell(r, 6, float(fr)); ws.cell(r, 6).fill = INP
        ws.cell(r, 7, f"=D{r}*F{r}")
        ws.cell(r, 8, JUSTIF_MAPEO[a]).alignment = WR
        for c in (4, 7):
            ws.cell(r, c).number_format = "0.00%"
        ws.cell(r, 6).number_format = "0%"
        for c in range(1, 9):
            ws.cell(r, c).border = BOX
            ws.cell(r, c).font = F()
        ws.row_dimensions[r].height = 45
        filas_map.append(r)
        r += 1
ultima_map = r - 1
ws.cell(r, 1, "Total").font = F(bold=True)
ws.cell(r, 4, f"=SUMPRODUCT(D5:D{ultima_map}*F5:F{ultima_map})").number_format = "0.00%"
ws.cell(r, 7, f"=SUM(G5:G{ultima_map})").number_format = "0.00%"
r += 3
ws.cell(r, 1, "Peso por sub-característica (26 sub-características ISO/IEC 9126-1)").font = F(size=11, bold=True)
r += 1
H2 = ["Característica", "Sub-característica", "Considerar (S/N)", "Peso sub-característica", "Tipo"]
for c, h in enumerate(H2, 1):
    x = ws.cell(r, c, h); x.font = F(bold=True, color="FFFFFF"); x.fill = HDR; x.alignment = CEN; x.border = BOX
r += 1
SUBROW = {}
for car, ab, subs in ISO_ARBOL:
    for s in subs:
        ws.cell(r, 1, car); ws.cell(r, 2, s)
        ws.cell(r, 4, f"=SUMIF($E$5:$E${ultima_map},B{r},$G$5:$G${ultima_map})").number_format = "0.00%"
        ws.cell(r, 3, f'=IF(D{r}>0,"S","N")')
        ws.cell(r, 5, f'=IF(D{r}=0,"no considerada",IF(COUNTIFS($E$5:$E${ultima_map},B{r},$C$5:$C${ultima_map},"Sí")>0,"principal","secundaria"))')
        for c in range(1, 6):
            ws.cell(r, c).border = BOX; ws.cell(r, c).font = F()
        SUBROW[s] = r
        r += 1
ws.cell(r, 2, "Total").font = F(bold=True)
ws.cell(r, 4, f"=SUM(D{min(SUBROW.values())}:D{r - 1})").number_format = "0.00%"
sub_lo, sub_hi = min(SUBROW.values()), max(SUBROW.values())
ws.conditional_formatting.add(f"A{sub_lo}:E{sub_hi}", FormulaRule(formula=[f'$E{sub_lo}="no considerada"'], fill=GRIS))
ws.conditional_formatting.add(f"A{sub_lo}:E{sub_hi}", FormulaRule(formula=[f'$E{sub_lo}="secundaria"'], fill=AMAR))
for c, w in zip("ABCDEFGH", (18, 30, 16, 14, 28, 10, 13, 90)):
    ws.column_dimensions[c].width = w
ws.freeze_panes = "A5"

# ------------------------------------------------------------- hoja 6
ws = wb.create_sheet("6 Métricas y resultados", index=5)
ws["A1"] = f"Métricas externas ISO/IEC TR 9126-2 aplicadas a Beancount {PRODUCTO['version']} — valores medidos, umbral, normalización y puntaje"
ws["A1"].font = F(size=12, bold=True)
ws["A2"] = ("Celdas amarillas = valores medidos (provienen de out/*.json del arnés; ver Anexo B del informe). Todo lo demás son fórmulas. "
            "S = valor normalizado 0-1 usado para el puntaje: métricas 'más alto mejor' S = X; tasas A/T: S = 1 - A/N; densidad: S = 1 - X; "
            "tiempos con referencia: S = 1 si X <= 1, si no 1/X; tiempo absoluto (021): S = MIN(1, 5/X).")
ws["A2"].alignment = WR
ws.merge_cells("A2:T2")
ws.row_dimensions[2].height = 44
H = ["N.º", "Tabla 9126-2", "Característica", "Sub-característica", "Métrica", "Fórmula", "Var 1", "Valor 1", "Var 2", "Valor 2",
     "Var 3", "Valor 3", "X (resultado)", "Umbral", "Dirección", "¿Pasa?", "S (0-1)", "Peso absoluto", "Aporte S×peso", "Estado"]
for c, h in enumerate(H, 1):
    x = ws.cell(4, c, h); x.font = F(bold=True, color="FFFFFF"); x.fill = HDR; x.alignment = CEN; x.border = BOX
ROW = {}
r = 5
first = r
last = first + len(METRICAS) - 1
for m in METRICAS:
    rm = RM[m["n"]]
    tot = rm["filas"]["Total"]["vals"]
    ks = list(tot.keys())
    ws.cell(r, 1, m["n"]); ws.cell(r, 2, m["tabla"]); ws.cell(r, 3, rm["car"]); ws.cell(r, 4, m["sub"]); ws.cell(r, 5, m["nombre"]); ws.cell(r, 6, m["formula"])
    for i, k in enumerate(ks[:3]):
        ws.cell(r, 7 + 2 * i, k)
        v = ws.cell(r, 8 + 2 * i, tot[k]); v.fill = INP
    t = m["tipo"]
    if m["n"] in ("001", "002", "003"):
        X, S = f"=H{r}/J{r}", f"=1-H{r}/L{r}"
    elif m["n"] in ("006", "007"):
        X, S = f"=1-H{r}/J{r}", f"=M{r}"
    elif m["n"] == "008":
        X, S = f"=H{r}/J{r}", f"=1-M{r}"
    elif m["n"] in ("017", "018"):
        X, S = f"=H{r}/J{r}", f"=IF(M{r}<=1,1,1/M{r})"
    elif m["n"] == "021":
        X, S = f"=H{r}/J{r}", f"=MIN(1,{m['umbral']}/M{r})"
    elif m["formula"].replace(" ", "").startswith("X=1-"):
        X, S = f"=1-H{r}/J{r}", f"=M{r}"
    else:
        X, S = f"=H{r}/J{r}", f"=M{r}"
    ws.cell(r, 13, X); ws.cell(r, 14, m["umbral"]); ws.cell(r, 15, m["op"])
    ws.cell(r, 16, f'=IF(O{r}="<=",IF(M{r}<=N{r},"PASA","NO PASA"),IF(M{r}>=N{r},"PASA","NO PASA"))')
    ws.cell(r, 17, S)
    ws.cell(r, 18, f"=INDEX('5 Mapeo ISO 9126'!$D${sub_lo}:$D${sub_hi},MATCH(D{r},'5 Mapeo ISO 9126'!$B${sub_lo}:$B${sub_hi},0))/COUNTIF($D${first}:$D${last},D{r})")
    ws.cell(r, 19, f"=Q{r}*R{r}")
    ws.cell(r, 20, "MEDIDO")
    ws.cell(r, 14).comment = Comment(m["just_umbral"], "Evaluador")
    for c in range(1, 21):
        ws.cell(r, c).border = BOX; ws.cell(r, c).font = F(); ws.cell(r, c).alignment = Alignment(vertical="top", wrap_text=c in (5, 6))
    for c in (13, 17):
        ws.cell(r, c).number_format = "0.0000"
    for c in (18, 19):
        ws.cell(r, c).number_format = "0.00%"
    ROW[m["n"]] = r
    r += 1
ws.conditional_formatting.add(f"P{first}:P{last}", FormulaRule(formula=[f'P{first}="PASA"'], fill=VERDE))
ws.conditional_formatting.add(f"P{first}:P{last}", FormulaRule(formula=[f'P{first}="NO PASA"'], fill=ROJO))
ws.cell(r, 17, "Suma pesos").font = F(bold=True)
ws.cell(r, 18, f"=SUM(R{first}:R{last})").number_format = "0.00%"
ws.cell(r, 19, f"=SUM(S{first}:S{last})").number_format = "0.00%"
r += 2
ws.cell(r, 1, "Puntaje por sub-característica y puntaje global").font = F(size=11, bold=True)
r += 1
H3 = ["Sub-característica", "Tipo (hoja 5)", "Peso", "Puntaje (Σ S×peso / peso)", "Umbral", "Color / estado", "Métricas que pasan"]
for c, h in enumerate(H3, 1):
    x = ws.cell(r, c, h); x.font = F(bold=True, color="FFFFFF"); x.fill = HDR; x.alignment = CEN; x.border = BOX
r += 1
ws.cell(r - 1, 9, "Umbral sub-característica"); ws.cell(r - 1, 10, UMBRAL_SUB); ws.cell(r - 1, 10).fill = INP
ur = r - 1
s_first = r
for s, v in R["subs"].items():
    if v["considerar"] != "S":
        continue
    ws.cell(r, 1, s)
    ws.cell(r, 2, f"=INDEX('5 Mapeo ISO 9126'!$E${sub_lo}:$E${sub_hi},MATCH(A{r},'5 Mapeo ISO 9126'!$B${sub_lo}:$B${sub_hi},0))")
    ws.cell(r, 3, f"=SUMIF($D${first}:$D${last},A{r},$R${first}:$R${last})").number_format = "0.00%"
    ws.cell(r, 4, f"=SUMIF($D${first}:$D${last},A{r},$S${first}:$S${last})/C{r}").number_format = "0.0000"
    ws.cell(r, 5, f"=$J${ur}")
    ws.cell(r, 6, f'=IF(B{r}="principal",IF(D{r}>=E{r},"VERDE (pasa)","ROJO (no pasa)"),"AMARILLO (menor interés)")')
    ws.cell(r, 7, f'=COUNTIFS($D${first}:$D${last},A{r},$P${first}:$P${last},"PASA")&" de "&COUNTIF($D${first}:$D${last},A{r})')
    for c in range(1, 8):
        ws.cell(r, c).border = BOX; ws.cell(r, c).font = F()
    r += 1
s_last = r - 1
ws.conditional_formatting.add(f"F{s_first}:F{s_last}", FormulaRule(formula=[f'LEFT(F{s_first},5)="VERDE"'], fill=VERDE))
ws.conditional_formatting.add(f"F{s_first}:F{s_last}", FormulaRule(formula=[f'LEFT(F{s_first},4)="ROJO"'], fill=ROJO))
ws.conditional_formatting.add(f"F{s_first}:F{s_last}", FormulaRule(formula=[f'LEFT(F{s_first},8)="AMARILLO"'], fill=AMAR))
r += 1
ws.cell(r, 1, "PUNTAJE GLOBAL").font = F(size=12, bold=True)
ws.cell(r, 4, f"=SUM(S{first}:S{last})").number_format = "0.00%"
ws.cell(r, 4).font = F(size=12, bold=True)
ws.cell(r, 6, f'=IF(D{r}>=0.95,"MUY BUENO",IF(D{r}>=0.8,"ACEPTABLE","NO ACEPTABLE"))').font = F(size=12, bold=True)
ws.cell(r + 1, 1, "Escala: MUY BUENO (>= 95 %), ACEPTABLE (>= 80 % y < 95 %), NO ACEPTABLE (< 80 %).").font = F(italic=True)
GLOBAL_CELL = f"D{r}"
r += 4
# Detalle por componente
ws.cell(r, 1, "Detalle por componente (C1 = Analizador y cargador, C2 = Núcleo contable, C3 = Herramientas CLI)").font = F(size=11, bold=True)
r += 1
H4 = ["N.º", "Métrica", "Componente", "Var 1", "Valor 1", "Var 2", "Valor 2", "Var 3", "Valor 3", "X"]
for c, h in enumerate(H4, 1):
    x = ws.cell(r, c, h); x.font = F(bold=True, color="FFFFFF"); x.fill = HDR; x.alignment = CEN; x.border = BOX
r += 1
for m in METRICAS:
    rm = RM[m["n"]]
    for comp in ("C1", "C2", "C3"):
        if comp not in rm["filas"]:
            continue
        vals = rm["filas"][comp]["vals"]
        ks = list(vals.keys())
        ws.cell(r, 1, m["n"]); ws.cell(r, 2, m["nombre"]); ws.cell(r, 3, comp)
        for i, k in enumerate(ks[:3]):
            ws.cell(r, 4 + 2 * i, k); ws.cell(r, 5 + 2 * i, vals[k]).fill = INP
        if m["n"] in ("006", "007") or (m["formula"].replace(" ", "").startswith("X=1-") and m["n"] not in ("017", "018", "021")):
            ws.cell(r, 10, f"=1-E{r}/G{r}")
        else:
            ws.cell(r, 10, f"=E{r}/G{r}")
        ws.cell(r, 10).number_format = "0.0000"
        for c in range(1, 11):
            ws.cell(r, c).border = BOX; ws.cell(r, c).font = F()
        r += 1
for c, w in zip("ABCDEFGHIJKLMNOPQRST", (6, 12, 14, 24, 42, 18, 12, 10, 12, 10, 10, 9, 12, 8, 8, 10, 9, 10, 10, 10)):
    ws.column_dimensions[c].width = w
ws.freeze_panes = "A5"

# Hoja de ejemplo 2a: referencias rotas heredadas de la plantilla (fila de efficiency)
wb["2a"]["A17"] = "='1 Attribute In or Out'!A20"
wb["2a"]["R17"] = "=1a!C16"
# Hojas de ejemplo/apoyo se conservan; se marca la hoja de trabajo del autor original
wb["Stuff to do"].sheet_state = "hidden"
wb.active = wb.sheetnames.index("6 Métricas y resultados")
for w in wb.worksheets:
    w.sheet_view.tabSelected = (w.title == "6 Métricas y resultados")
os.makedirs(os.path.dirname(DST), exist_ok=True)
wb.save(DST)
print("guardado", DST, "global en", GLOBAL_CELL)
