# -*- coding: utf-8 -*-
"""Utilidades comunes del arnés de medición (ejecución, registro de evidencias).

Cada ejecución de una herramienta queda registrada en logs/raw/<métrica>/<caso>.txt con
comando, código de salida, duración, stdout y stderr. Cada métrica escribe
out/<métrica>.json con la lista de casos y si el caso cuenta en la variable A de la fórmula.
"""
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

BASE = "/home/claude/eval"
BC3 = "/home/claude/venv-bc3/bin"
BC2 = "/home/claude/venv-bc2/bin"
PY3 = BC3 + "/python"
PY2 = BC2 + "/python"
RAW = BASE + "/logs/raw"
OUT = BASE + "/out"
WORK = BASE + "/work"
LEDG = BASE + "/ledgers"
SCR = BASE + "/scripts"
EJEMPLO = LEDG + "/example.beancount"
GRANDE = LEDG + "/grande_100k.beancount"
COMP = {"C1": "Analizador y cargador", "C2": "Núcleo contable", "C3": "Herramientas CLI"}

for d in (RAW, OUT, WORK):
    os.makedirs(d, exist_ok=True)


class R:
    def __init__(self, rc, out, err, dt, timeout, log):
        self.rc, self.out, self.err, self.dt, self.timeout, self.log = rc, out, err, dt, timeout, log

    @property
    def traceback(self):
        """Traza NO controlada: el intérprete imprime 'Traceback' al inicio de línea y el
        proceso termina con la excepción (última línea no vacía 'XxxError: ...' en columna 0).
        Las trazas incluidas dentro de un mensaje de error del cargador (p. ej.
        '<load>:0: Error importing ...: Traceback ...', con la excepción indentada) son errores
        capturados y reportados, no caídas."""
        import re as _re
        for s in (self.err or "", self.out or ""):
            lines = [l for l in s.splitlines() if l.strip()]
            if _re.search(r"^Traceback \(most recent call last\):", s, _re.M) and lines and \
                    _re.match(r"^[A-Za-z_][\w.]*(Error|Exception|Interrupt|Exit)\b", lines[-1]):
                return True
        return False

    @property
    def caida(self):
        """Caída: traza no controlada, terminación por señal o bloqueo (> timeout)."""
        return self.timeout or (self.rc is not None and self.rc < 0) or self.traceback

    @property
    def todo(self):
        return (self.out or "") + "\n" + (self.err or "")


def _txt(x):
    if x is None:
        return ""
    if isinstance(x, bytes):
        return x.decode("utf-8", "replace")
    return x


def run(cmd, metric, case, cwd=None, timeout=60, env=None, stdin=None, max_log=20000):
    """Ejecuta cmd (lista) y registra la evidencia cruda."""
    d = os.path.join(RAW, metric)
    os.makedirs(d, exist_ok=True)
    t0 = time.perf_counter()
    to = False
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, timeout=timeout, env=env,
                           input=stdin.encode() if isinstance(stdin, str) else stdin)
        rc, out, err = p.returncode, _txt(p.stdout), _txt(p.stderr)
    except subprocess.TimeoutExpired as e:
        rc, out, err, to = None, _txt(e.stdout), _txt(e.stderr), True
    dt = time.perf_counter() - t0
    log = os.path.join(d, f"{case}.txt")
    with open(log, "w", encoding="utf-8") as f:
        f.write(f"$ {' '.join(shlex.quote(str(c)) for c in cmd)}\n")
        f.write(f"cwd={cwd or os.getcwd()}\nrc={rc} timeout={to} duracion_s={dt:.4f}\n")
        f.write("----- stdout -----\n" + out[:max_log] + ("\n[...truncado...]\n" if len(out) > max_log else "\n"))
        f.write("----- stderr -----\n" + err[:max_log] + ("\n[...truncado...]\n" if len(err) > max_log else "\n"))
    return R(rc, out, err, dt, to, os.path.relpath(log, BASE))


def py(code, metric, case, args=(), v2=False, timeout=120, cwd=None):
    """Ejecuta un fragmento Python en el entorno de Beancount 3.2.3 (o 2.3.6)."""
    d = os.path.join(WORK, "snippets")
    os.makedirs(d, exist_ok=True)
    f = os.path.join(d, f"{metric}_{case}.py")
    with open(f, "w", encoding="utf-8") as fh:
        fh.write(code)
    return run([PY2 if v2 else PY3, "-I", f, *map(str, args)], metric, case, timeout=timeout, cwd=cwd)


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def escribir(path, texto, enc="utf-8"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding=enc) as f:
        f.write(texto)
    return path


def wdir(metric):
    d = os.path.join(WORK, metric)
    os.makedirs(d, exist_ok=True)
    return d


class Registro:
    """Colección de casos de una métrica. cuenta_A=True significa que el caso suma en A."""

    def __init__(self, metric):
        self.metric = metric
        self.casos = []
        self.extra = {}
        self.t0 = time.time()

    def add(self, cid, comp, desc, esperado, observado, cuenta_A, evid, **kw):
        c = dict(id=cid, comp=comp, desc=desc, esperado=esperado, observado=str(observado)[:600],
                 cuenta_A=bool(cuenta_A), evidencia=evid)
        c.update(kw)
        self.casos.append(c)
        flag = "A" if cuenta_A else "."
        print(f"  [{self.metric}] {cid:<28} {comp} {flag}  {str(observado)[:90]}", flush=True)
        return c

    def guardar(self, **extra):
        self.extra.update(extra)
        self.extra.setdefault("duracion_campana_s", round(time.time() - self.t0, 3))
        with open(os.path.join(OUT, f"{self.metric}.json"), "w", encoding="utf-8") as f:
            json.dump({"metrica": self.metric, "casos": self.casos, **self.extra}, f,
                      indent=1, ensure_ascii=False)


# Script de API reutilizable: saldos por cuenta|moneda, costo de lotes y errores.
API_SALDOS = r'''
import sys, json
from collections import defaultdict
from decimal import Decimal
from beancount import loader
from beancount.core import data
f = sys.argv[1]
entries, errors, opts = loader.load_file(f)
bal = defaultdict(Decimal)
cost = defaultdict(Decimal)
ntx = 0
for e in entries:
    if isinstance(e, data.Transaction):
        ntx += 1
        for p in e.postings:
            bal[p.account + "|" + p.units.currency] += p.units.number
            if p.cost is not None and p.cost.number is not None:
                cost[p.account] += p.units.number * p.cost.number
def loc(err):
    s = getattr(err, "source", None) or {}
    return "%s:%s" % (s.get("filename"), s.get("lineno"))
print(json.dumps({"n_entries": len(entries), "n_tx": ntx,
                  "errores": [loc(e) + ": " + str(e.message).splitlines()[0] for e in errors],
                  "saldos": {k: str(v) for k, v in sorted(bal.items()) if v != 0},
                  "costo": {k: str(v) for k, v in cost.items()}}, ensure_ascii=False))
'''


def saldos(path, metric, case, v2=False):
    r = py(API_SALDOS, metric, case, args=[path], v2=v2, timeout=300)
    try:
        return json.loads(r.out.strip().splitlines()[-1]), r
    except Exception:
        return None, r
