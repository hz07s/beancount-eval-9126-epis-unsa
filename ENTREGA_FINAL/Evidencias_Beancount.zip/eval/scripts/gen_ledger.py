# -*- coding: utf-8 -*-
"""Generador de libros sintéticos con ORÁCULO independiente.

No usa ninguna función de Beancount: calcula los saldos esperados con
decimal.Decimal y un booking FIFO propio, y escribe un JSON con los saldos
finales esperados por cuenta y moneda, el costo total de los lotes y las
ganancias realizadas. Sirve de cálculo independiente para las métricas de
exactitud (002) y de libro grande para las métricas de tiempo (018).

Uso: python gen_ledger.py SEMILLA N_TRANSACCIONES salida.beancount oraculo.json
"""
import json
import random
import sys
from collections import defaultdict, deque
from datetime import date, timedelta
from decimal import Decimal

Q = Decimal("0.01")


def money(rng, lo=100, hi=50000):
    return (Decimal(rng.randint(lo, hi)) * Q).quantize(Q)


def main(seed, ntx, out, oracle_path):
    rng = random.Random(seed)
    start = date(2005, 1, 1)
    days = max(365, ntx // 8)
    usd = ["Assets:Bank:Checking", "Assets:Bank:Savings", "Liabilities:CreditCard",
           "Income:Salary", "Assets:Broker:Cash", "Income:Gains", "Equity:Opening-Balances"]
    exp = ["Expenses:Food", "Expenses:Rent", "Expenses:Transport", "Expenses:Health",
           "Expenses:Education", "Expenses:Fun", "Expenses:Taxes", "Expenses:Fees"]
    bal = defaultdict(Decimal)          # (account, currency) -> number
    lots = deque()                      # FIFO lots of ACME: [units, cost]
    gains_total = Decimal(0)
    lines = ['option "title" "Libro sintético con oráculo"',
             'option "operating_currency" "USD"',
             'option "booking_method" "FIFO"', ""]
    for a in usd:
        lines.append(f"2000-01-01 open {a} USD")
    for a in exp:
        lines.append(f"2000-01-01 open {a} USD,PEN")
    lines.append("2000-01-01 open Assets:Cash:PEN PEN")
    lines.append("2000-01-01 open Assets:Broker:ACME ACME")
    lines.append("2000-01-01 commodity ACME")
    lines.append("")
    entries = []  # (date, order, text, postings[(acc, cur, num)])

    def add(d, text, posts):
        entries.append((d, len(entries), text, posts))

    # saldo inicial
    add(start, '* "Saldo inicial"\n  Assets:Bank:Checking  10000.00 USD\n  Equity:Opening-Balances',
        [("Assets:Bank:Checking", "USD", Decimal("10000.00")), ("Equity:Opening-Balances", "USD", Decimal("-10000.00"))])
    for i in range(ntx):
        d = start + timedelta(days=rng.randint(1, days))
        k = rng.random()
        if k < 0.35:
            src = rng.choice(["Assets:Bank:Checking", "Liabilities:CreditCard"])
            e = rng.choice(exp[:6]); amt = money(rng, 100, 30000)
            elide = rng.random() < 0.5
            body = f'* "Comercio {i}" "Gasto {i}"\n  {e}  {amt} USD\n  {src}' + ("" if elide else f"  {-amt} USD")
            add(d, body, [(e, "USD", amt), (src, "USD", -amt)])
        elif k < 0.45:
            g = money(rng, 200000, 600000); net = (g * Decimal("0.8")).quantize(Q); tax = g - net
            body = f'* "Empleador" "Sueldo"\n  Income:Salary  {-g} USD\n  Assets:Bank:Checking  {net} USD\n  Expenses:Taxes  {tax} USD'
            add(d, body, [("Income:Salary", "USD", -g), ("Assets:Bank:Checking", "USD", net), ("Expenses:Taxes", "USD", tax)])
        elif k < 0.55:
            p = Decimal(rng.randint(10, 2000)); rate = Decimal(rng.randint(25, 30)) * Q
            cost = (p * rate).quantize(Q)
            body = f'* "Casa de cambio" "Compra PEN"\n  Assets:Cash:PEN  {p} PEN @ {rate} USD\n  Assets:Bank:Checking  {-cost} USD'
            add(d, body, [("Assets:Cash:PEN", "PEN", p), ("Assets:Bank:Checking", "USD", -cost)])
        elif k < 0.70:
            e = rng.choice(exp[:6]); amt = money(rng, 100, 5000)
            body = f'* "Bodega {i}" "Gasto en soles"\n  {e}  {amt} PEN\n  Assets:Cash:PEN  {-amt} PEN'
            add(d, body, [(e, "PEN", amt), ("Assets:Cash:PEN", "PEN", -amt)])
        elif k < 0.80:
            amt = money(rng, 1000, 100000)
            body = f'* "Transferencia"\n  Assets:Bank:Savings  {amt} USD\n  Assets:Bank:Checking  {-amt} USD'
            add(d, body, [("Assets:Bank:Savings", "USD", amt), ("Assets:Bank:Checking", "USD", -amt)])
        elif k < 0.90:
            amt = money(rng, 10000, 200000)
            body = f'* "Pago tarjeta"\n  Liabilities:CreditCard  {amt} USD\n  Assets:Bank:Checking  {-amt} USD'
            add(d, body, [("Liabilities:CreditCard", "USD", amt), ("Assets:Bank:Checking", "USD", -amt)])
        else:
            u = Decimal(rng.randint(1, 20)); c = money(rng, 1000, 30000)
            amt = (u * c).quantize(Q)
            body = f'* "Broker" "Compra ACME"\n  Assets:Broker:ACME  {u} ACME {{{c} USD}}\n  Assets:Broker:Cash  {-amt} USD'
            entries.append((d, len(entries), body, [("Assets:Broker:ACME", "ACME", u), ("Assets:Broker:Cash", "USD", -amt)], ("buy", u, c)))
    # ventas: se agregan al final (fechas posteriores) para controlar FIFO
    entries.sort(key=lambda e: (e[0], e[1]))
    last = entries[-1][0]
    nsell = max(1, ntx // 200)
    sells = []
    for j in range(nsell):
        d = last + timedelta(days=j + 1)
        sells.append(d)
    # aplicar en orden y generar texto
    out_tx = []
    for e in entries:
        d, _, body, posts = e[0], e[1], e[2], e[3]
        for acc, cur, num in posts:
            bal[(acc, cur)] += num
        if len(e) == 5:
            _, u, c = e[4]
            lots.append([u, c])
        out_tx.append((d, body))
    for d in sells:
        held = sum(l[0] for l in lots)
        if held <= 0:
            break
        u = Decimal(min(int(held), rng.randint(1, 10)))
        p = money(rng, 1000, 40000)
        rem = u; basis = Decimal(0)
        while rem > 0:
            lu, lc = lots[0]
            take = min(lu, rem)
            basis += take * lc
            rem -= take
            lots[0][0] -= take
            if lots[0][0] == 0:
                lots.popleft()
        proceeds = (u * p).quantize(Q)
        gain = proceeds - basis
        gains_total += gain
        body = (f'* "Broker" "Venta ACME"\n  Assets:Broker:ACME  {-u} ACME {{}} @ {p} USD\n'
                f'  Assets:Broker:Cash  {proceeds} USD\n  Income:Gains')
        bal[("Assets:Broker:ACME", "ACME")] -= u
        bal[("Assets:Broker:Cash", "USD")] += proceeds
        bal[("Income:Gains", "USD")] -= gain
        out_tx.append((d, body))
    # aserciones mensuales sobre Checking (calculadas por el oráculo)
    asserts = []
    run = Decimal(0)
    allposts = []
    for e in entries:
        for acc, cur, num in e[3]:
            if acc == "Assets:Bank:Checking":
                allposts.append((e[0], num))
    d0 = date(start.year, start.month, 1)
    m = d0
    while m <= last:
        s = sum(n for dd, n in allposts if dd < m)
        asserts.append((m, f"balance Assets:Bank:Checking  {s} USD"))
        m = date(m.year + (m.month // 12), m.month % 12 + 1, 1)
    if ntx > 5000:
        asserts = asserts[::12]  # en libros grandes, una aserción anual
    allout = [(d, b) for d, b in out_tx] + asserts
    allout.sort(key=lambda x: x[0])
    for d, b in allout:
        lines.append(f"{d.isoformat()} {b}")
        lines.append("")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    cost_total = sum(l[0] * l[1] for l in lots)
    oracle = {
        "semilla": seed, "n_transacciones": len(out_tx), "n_aserciones": len(asserts),
        "saldos": {f"{a}|{c}": str(n) for (a, c), n in sorted(bal.items()) if n != 0},
        "costo_lotes_ACME": str(cost_total), "ganancia_realizada": str(gains_total),
    }
    with open(oracle_path, "w", encoding="utf-8") as f:
        json.dump(oracle, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main(int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4])
