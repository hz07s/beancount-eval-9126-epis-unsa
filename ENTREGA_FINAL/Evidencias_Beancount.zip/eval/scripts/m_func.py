# -*- coding: utf-8 -*-
"""Mediciones de Funcionalidad: 001-003 (Precisión), 004 (Interoperabilidad), 005-007 (Seguridad)."""
import csv
import io
import json
import os
import random
import re
import shutil
import signal
import subprocess
import time
from collections import defaultdict
from decimal import Decimal, getcontext

from comun import *

CHK, QRY, FMT, DOC = BC3 + "/bean-check", BC3 + "/bean-query", BC3 + "/bean-format", BC3 + "/bean-doctor"

CAB = 'option "operating_currency" "USD"\n'


def ledger(metric, name, body):
    return escribir(os.path.join(wdir(metric), name), body)


# Fragmento genérico: carga y devuelve JSON con datos para comparar.
API_INFO = r'''
import sys, json
from beancount import loader
from beancount.core import data, realization
entries, errors, opts = loader.load_file(sys.argv[1])
txs = [e for e in entries if isinstance(e, data.Transaction)]
real = realization.realize(entries)
def bal(acc):
    r = realization.get(real, acc)
    return {} if r is None else {p.units.currency: str(p.units.number) for p in r.balance}
def lots(acc):
    r = realization.get(real, acc)
    return [] if r is None else sorted([[str(p.units.number), str(p.cost.number)] for p in r.balance if p.cost])
out = {"errores": [str(e.message).splitlines()[0] for e in errors], "n_tx": len(txs),
       "tags": [sorted(t.tags) for t in txs], "meta": [{k: str(v) for k, v in t.meta.items() if k not in ("filename","lineno","__tolerances__")} for t in txs],
       "nums": [[str(p.units.number) for p in t.postings] for t in txs],
       "title": opts.get("title"), "accounts": sorted({p.account for t in txs for p in t.postings})}
for a in sys.argv[2:]:
    out["bal:" + a] = bal(a)
    out["lots:" + a] = lots(a)
print(json.dumps(out, ensure_ascii=False))
'''


def eqn(a, b):
    """Igualdad numérica de dicts moneda->número (Decimal('-40.400') == Decimal('-40.40'))."""
    if not isinstance(a, dict) or not isinstance(b, dict) or set(a) != set(b):
        return False
    return all(Decimal(a[k]) == Decimal(b[k]) for k in a)


def info(path, metric, case, accounts=()):
    r = py(API_INFO, metric, case, args=[path, *accounts])
    try:
        return json.loads(r.out.strip().splitlines()[-1]), r
    except Exception:
        return {"_fallo": r.todo[-300:]}, r


# ------------------------------------------------------------------ 001
def m001():
    M = "001"
    reg = Registro(M)
    d = wdir(M)
    # ---- C1: analizador / cargador
    escribir(f"{d}/sub.beancount", '2020-02-01 * "Incluida"\n  Expenses:Food  5.00 USD\n  Assets:Cash\n')
    L = ledger(M, "inc.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\ninclude "sub.beancount"\n')
    j, r = info(L, M, "C1_include")
    reg.add("C1_include", "C1", "include incorpora las transacciones del archivo incluido",
            "1 transacción, 0 errores", f"{j.get('n_tx')} tx, errores={j.get('errores')}",
            not (j.get("n_tx") == 1 and not j.get("errores")), r.log)

    L = ledger(M, "tags.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\n'
               'pushtag #viaje\n2020-01-02 * "A"\n  Expenses:Food 1 USD\n  Assets:Cash\npoptag #viaje\n'
               '2020-01-03 * "B"\n  Expenses:Food 1 USD\n  Assets:Cash\n')
    j, r = info(L, M, "C1_pushtag")
    reg.add("C1_pushtag", "C1", "pushtag/poptag etiqueta solo las transacciones intermedias",
            "[['viaje'], []]", j.get("tags"), j.get("tags") != [["viaje"], []], r.log)

    L = ledger(M, "miles.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\n'
               '2020-01-02 * "M"\n  Expenses:Food  1,234,567.89 USD\n  Assets:Cash\n')
    j, r = info(L, M, "C1_miles")
    reg.add("C1_miles", "C1", "Separador de miles con coma se interpreta como 1234567.89",
            "['1234567.89','-1234567.89']", j.get("nums"), j.get("nums") != [["1234567.89", "-1234567.89"]], r.log)

    L = ledger(M, "expr.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\n'
               '2020-01-02 * "E"\n  Expenses:Food  (10 + 5) * 2 USD\n  Expenses:Food  10 / 4 USD\n  Assets:Cash\n')
    j, r = info(L, M, "C1_expresion")
    reg.add("C1_expresion", "C1", "Expresiones aritméticas en montos: (10+5)*2 = 30 y 10/4 = 2.5",
            "['30','2.5','-32.5']", j.get("nums"), j.get("nums") != [["30", "2.5", "-32.5"]], r.log)

    L = ledger(M, "opt.beancount", 'option "title" "Mi libro contable"\n')
    j, r = info(L, M, "C1_option_title")
    reg.add("C1_option_title", "C1", "option \"title\" se refleja en options_map",
            "Mi libro contable", j.get("title"), j.get("title") != "Mi libro contable", r.log)

    L = ledger(M, "meta.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\n'
               'pushmeta ciudad: "Lima"\n2020-01-02 * "Meta"\n  factura: "F-001"\n  Expenses:Food 1 USD\n  Assets:Cash\npopmeta ciudad:\n')
    j, r = info(L, M, "C1_metadatos")
    exp = [{"ciudad": "Lima", "factura": "F-001"}]
    reg.add("C1_metadatos", "C1", "Metadatos de transacción y pushmeta se adjuntan a la entrada",
            exp, j.get("meta"), j.get("meta") != exp, r.log)

    L = ledger(M, "coment.beancount", '* Encabezado org-mode\n; comentario\n' + CAB +
               '2020-01-01 open Assets:Cash USD ; comentario final\n2020-01-01 open Expenses:Food USD\n'
               '** Sección\n2020-01-02 * "C"\n  Expenses:Food 2 USD\n  Assets:Cash\n')
    j, r = info(L, M, "C1_comentarios", ["Assets:Cash"])
    reg.add("C1_comentarios", "C1", "Comentarios ';' y encabezados org-mode '*' se ignoran",
            "0 errores, saldo Assets:Cash -2", (j.get("errores"), j.get("bal:Assets:Cash")),
            not (not j.get("errores") and j.get("bal:Assets:Cash") == {"USD": "-2"}), r.log)

    # ---- C2: núcleo contable
    L = ledger(M, "interp.beancount", CAB + '2020-01-01 open Assets:Cash USD\n2020-01-01 open Expenses:Food USD\n'
               '2020-01-02 * "I"\n  Expenses:Food  10.10 USD\n  Expenses:Food  0.25 USD\n  Assets:Cash\n')
    j, r = info(L, M, "C2_interpolacion", ["Assets:Cash"])
    reg.add("C2_interpolacion", "C2", "Interpolación del monto omitido = -(10.10+0.25)",
            "{'USD': '-10.35'}", j.get("bal:Assets:Cash"), j.get("bal:Assets:Cash") != {"USD": "-10.35"}, r.log)

    L = ledger(M, "precio.beancount", CAB + '2020-01-01 open Assets:USD USD\n2020-01-01 open Assets:PEN PEN\n'
               '2020-01-02 * "Cambio @"\n  Assets:PEN  100 PEN @ 0.27 USD\n  Assets:USD  -27.00 USD\n'
               '2020-01-03 * "Cambio @@"\n  Assets:PEN  50 PEN @@ 13.40 USD\n  Assets:USD\n')
    j, r = info(L, M, "C2_precio", ["Assets:USD", "Assets:PEN"])
    ok = not j.get("errores") and eqn(j.get("bal:Assets:USD"), {"USD": "-40.40"}) and eqn(j.get("bal:Assets:PEN"), {"PEN": "150"})
    reg.add("C2_precio", "C2", "Conversión con precio unitario (@) y total (@@) balancea la transacción",
            "USD -40.40, PEN 150, 0 errores", (j.get("bal:Assets:USD"), j.get("bal:Assets:PEN"), j.get("errores")), not ok, r.log)

    base_lotes = ('2020-01-01 open Assets:Cash USD\n2020-01-01 open Income:Gains USD\n'
                  '2020-01-02 * "C1"\n  Assets:Acc  10 ACME {100 USD}\n  Assets:Cash\n'
                  '2020-01-03 * "C2"\n  Assets:Acc  10 ACME {120 USD}\n  Assets:Cash\n'
                  '2020-02-01 * "V"\n  Assets:Acc  -15 ACME {} @ 150 USD\n  Assets:Cash  2250 USD\n  Income:Gains\n')
    for metodo, lotes, gan in (("FIFO", [["5", "120"]], "-650"), ("LIFO", [["5", "100"]], "-550")):
        L = ledger(M, f"{metodo}.beancount", CAB + f'2020-01-01 open Assets:Acc ACME "{metodo}"\n' + base_lotes)
        j, r = info(L, M, f"C2_booking_{metodo}", ["Assets:Acc", "Income:Gains"])
        ok = j.get("lots:Assets:Acc") == lotes and j.get("bal:Income:Gains") == {"USD": gan}
        reg.add(f"C2_booking_{metodo}", "C2", f"Booking {metodo}: vender 15 de 10@100 y 10@120 a 150",
                f"lotes {lotes}, ganancia {gan}", (j.get("lots:Assets:Acc"), j.get("bal:Income:Gains")), not ok, r.log)

    L = ledger(M, "strict.beancount", CAB + '2020-01-01 open Assets:Acc ACME "STRICT"\n' + base_lotes.replace("-15 ACME {}", "-5 ACME {100 USD}").replace("2250 USD", "750 USD"))
    j, r = info(L, M, "C2_booking_STRICT", ["Assets:Acc", "Income:Gains"])
    ok = j.get("lots:Assets:Acc") == [["10", "120"], ["5", "100"]] and j.get("bal:Income:Gains") == {"USD": "-250"}
    reg.add("C2_booking_STRICT", "C2", "Booking STRICT con lote explícito {100 USD}",
            "lotes [[10,120],[5,100]], ganancia -250", (j.get("lots:Assets:Acc"), j.get("bal:Income:Gains")), not ok, r.log)

    L = ledger(M, "pad.beancount", CAB + '2020-01-01 open Assets:Bank USD\n2020-01-01 open Equity:Opening USD\n'
               '2020-01-01 pad Assets:Bank Equity:Opening\n2020-01-02 balance Assets:Bank 500.00 USD\n')
    j, r = info(L, M, "C2_pad", ["Assets:Bank", "Equity:Opening"])
    ok = not j.get("errores") and j.get("bal:Assets:Bank") == {"USD": "500.00"} and j.get("bal:Equity:Opening") == {"USD": "-500.00"}
    reg.add("C2_pad", "C2", "pad inserta la transacción de relleno que satisface el balance siguiente",
            "Bank 500.00, Equity -500.00", (j.get("bal:Assets:Bank"), j.get("bal:Equity:Opening"), j.get("errores")), not ok, r.log)

    # Tolerancia de balance documentada en beancount/ops/balance.py::get_balance_tolerance:
    # 2 x tolerance_multiplier (0.5) x último dígito = 0.01 para "100.00 USD".
    for nombre, real, debe_pasar in (("dentro", "100.009", True), ("fuera", "100.02", False)):
        L = ledger(M, f"tol_{nombre}.beancount", CAB + '2020-01-01 open Assets:Bank USD\n2020-01-01 open Equity:O USD\n'
                   f'2020-01-02 * "D"\n  Assets:Bank  {real} USD\n  Equity:O\n2020-01-03 balance Assets:Bank 100.00 USD\n')
        j, r = info(L, M, f"C2_tolerancia_{nombre}")
        paso = not j.get("errores")
        reg.add(f"C2_tolerancia_{nombre}", "C2", f"Aserción 100.00 con saldo real {real} (tolerancia documentada = 2 x 0.5 x 0.01 = 0.01)",
                "pasa" if debe_pasar else "falla con error", "pasa" if paso else f"falla: {j.get('errores')}", paso != debe_pasar, r.log)

    # ---- C3: herramientas CLI, contra cálculos independientes del texto
    S = LEDG + "/sint_101.beancount"
    txt = open(S, encoding="utf-8").read()
    n_exp = len(re.findall(r"^  Expenses:\S+\s+-?[\d.]+ (USD|PEN)$", txt, re.M))
    r = run([QRY, "-q", "-f", "csv", S, "SELECT count(*) AS n WHERE account ~ '^Expenses'"], M, "C3_query_count")
    obs = r.out.strip().splitlines()[-1].strip() if r.out.strip() else r.todo[-200:]
    reg.add("C3_query_count", "C3", "bean-query count(*) de postings Expenses = conteo independiente por regex sobre el texto",
            n_exp, obs, obs != str(n_exp), r.log)

    food21 = sum((Decimal(m.group(2)) for blk in re.split(r"\n\n", txt) if blk.startswith("2005-")
                  for m in re.finditer(r"^  (Expenses:Food)\s+(-?[\d.]+) USD$", blk, re.M)), Decimal(0))
    r = run([QRY, "-q", "-f", "csv", S, "SELECT sum(number) AS t FROM OPEN ON 2005-01-01 CLOSE ON 2006-01-01 "
             "WHERE account = 'Expenses:Food' AND currency = 'USD'"], M, "C3_query_periodo")
    obs = r.out.strip().splitlines()[-1].strip() if r.out.strip() else r.todo[-200:]
    reg.add("C3_query_periodo", "C3", "bean-query FROM OPEN/CLOSE ON: gasto Food USD de 2005 = suma independiente por regex",
            str(food21), obs, Decimal(obs) != food21 if re.match(r"^-?[\d.]+$", obs) else True, r.log)

    F = shutil.copy(EJEMPLO, f"{d}/fmt_in.beancount")
    r = run([FMT, "-o", f"{d}/fmt_out.beancount", F], M, "C3_format_numeros")
    num = lambda t: sorted(re.findall(r"(?<![\w.-])-?\d+\.\d+(?![\w.])", t))
    a, b = num(open(F).read()), num(open(f"{d}/fmt_out.beancount").read())
    reg.add("C3_format_numeros", "C3", "bean-format solo realinea: el multiconjunto de números del libro no cambia",
            f"{len(a)} números idénticos", f"{len(b)} números, iguales={a == b}", a != b, r.log)

    r1 = run([CHK, "-C", EJEMPLO], M, "C3_check_rc_valido")
    r2 = run([CHK, "-C", f"{d}/interp.beancount".replace("interp", "precio")], M, "C3_check_rc_valido2")
    inval = escribir(f"{d}/invalido.beancount", CAB + '2020-01-01 open Assets:A USD\n2020-01-02 * "u"\n  Assets:A 1 USD\n  Assets:B -2 USD\n')
    r2 = run([CHK, "-C", inval], M, "C3_check_rc_invalido")
    reg.add("C3_check_rc", "C3", "bean-check: código 0 para libro válido y 1 para libro con errores",
            "0 / 1", f"{r1.rc} / {r2.rc}", not (r1.rc == 0 and r2.rc == 1), r1.log + " ; " + r2.log)

    r = run([QRY, "-q", "-m", S, "SELECT account, sum(position) AS s WHERE account = 'Assets:Bank:Savings' GROUP BY account"], M, "C3_numberify")
    val = r.out.strip().splitlines()[-1].split()[-1] if r.out.strip() else ""
    reg.add("C3_numberify", "C3", "bean-query -m (numberify) deja la celda solo con el número (la moneda pasa a la cabecera)",
            "152921.46", val, val != "152921.46" or r.rc != 0, r.log)

    r = run([QRY, "-q", "-f", "csv", S, "SELECT date AS fecha, account AS cuenta, number AS monto LIMIT 3"], M, "C3_csv_cabecera")
    head = r.out.strip().splitlines()[0] if r.out.strip() else ""
    reg.add("C3_csv_cabecera", "C3", "bean-query -f csv usa como cabecera los alias pedidos",
            "fecha,cuenta,monto", head, head != "fecha,cuenta,monto", r.log)
    reg.guardar()


# ------------------------------------------------------------------ 002
def m002():
    M = "002"
    reg = Registro(M)
    d = wdir(M)
    # C1: expresiones aritméticas evaluadas por el analizador vs. Decimal de Python
    rng = random.Random(7)
    getcontext().prec = 28
    exprs = []
    for i in range(30):
        a, b, c = (Decimal(rng.randint(1, 99999)) / 100 for _ in range(3))
        op1, op2 = rng.choice("+-*/"), rng.choice("+-*/")
        e = f"({a} {op1} {b}) {op2} {c}"
        exprs.append((e, eval(f"(Decimal('{a}') {op1} Decimal('{b}')) {op2} Decimal('{c}')")))
    body = CAB + "2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n"
    for i, (e, _) in enumerate(exprs):
        body += f'2020-01-02 * "e{i}"\n  Assets:A  {e} USD\n  Equity:E\n'
    L = escribir(f"{d}/expresiones.beancount", body)
    j, r = info(L, M, "C1_expresiones")
    for i, (e, v) in enumerate(exprs):
        got = j["nums"][i][0] if "nums" in j else None
        reg.add(f"C1_expr_{i:02d}", "C1", f"Expresión {e}", str(v), got, got is None or Decimal(got) != v, r.log)
    # C2: saldos de 3 libros sintéticos vs oráculo independiente
    for s in (101, 202, 303):
        orac = json.load(open(f"{LEDG}/sint_{s}.oraculo.json"))
        j, r = saldos(f"{LEDG}/sint_{s}.beancount", M, f"C2_sint_{s}")
        for k, v in orac["saldos"].items():
            got = j["saldos"].get(k)
            reg.add(f"C2_s{s}_{k}", "C2", f"Saldo {k} (libro sint_{s})", v, got, got is None or Decimal(got) != Decimal(v), r.log)
        got = j["costo"].get("Assets:Broker:ACME")
        reg.add(f"C2_s{s}_costo_lotes", "C2", f"Costo de los lotes ACME restantes tras booking FIFO (sint_{s})",
                orac["costo_lotes_ACME"], got, got is None or Decimal(got) != Decimal(orac["costo_lotes_ACME"]), r.log)
        reg.add(f"C2_s{s}_errores", "C2", f"Aserciones balance mensuales calculadas por el oráculo pasan (sint_{s})",
                "0 errores", j["errores"][:3], bool(j["errores"]), r.log)
    # C3: bean-query sobre sint_202 vs oráculo
    orac = json.load(open(f"{LEDG}/sint_202.oraculo.json"))
    r = run([QRY, "-q", "-f", "csv", f"{LEDG}/sint_202.beancount",
             "SELECT account, currency, sum(number) AS total GROUP BY account, currency"], M, "C3_query_saldos")
    got = {}
    for row in csv.DictReader(io.StringIO(r.out)):
        got[row["account"].strip() + "|" + row["currency"].strip()] = row["total"].strip()
    for k, v in orac["saldos"].items():
        g = got.get(k)
        reg.add(f"C3_{k}", "C3", f"bean-query sum(number) {k} (sint_202)", v, g, g is None or Decimal(g) != Decimal(v), r.log)
    r = run([QRY, "-q", "-f", "csv", f"{LEDG}/sint_202.beancount",
             "SELECT sum(number * cost_number) AS c WHERE account = 'Assets:Broker:ACME'"], M, "C3_query_costo")
    g = r.out.strip().splitlines()[-1].strip() if r.out.strip() else None
    reg.add("C3_costo_lotes", "C3", "bean-query costo de lotes ACME (sint_202)", orac["costo_lotes_ACME"], g,
            g is None or not re.match(r"^-?[\d.]+$", g) or Decimal(g) != Decimal(orac["costo_lotes_ACME"]), r.log)
    reg.guardar()


# ------------------------------------------------------------------ 003
def m003():
    M = "003"
    reg = Registro(M)
    d = wdir(M)
    nums = ["0.1", "0.2", "0.12345678", "12345678901234567890.12", "0.000000000000000001", "99999999999999.99"]
    body = CAB + "2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n"
    for i, n in enumerate(nums):
        body += f'2020-01-02 * "n{i}"\n  Assets:A  {n} XYZ{i}\n  Equity:E\n'
    L = escribir(f"{d}/parse.beancount", body)
    j, r = info(L, M, "C1_parse")
    for i, n in enumerate(nums):
        got = j["nums"][i][0] if "nums" in j else None
        reg.add(f"C1_num_{i}", "C1", f"El número {n} se lee sin pérdida (Decimal exacto)", n, got, got is None or Decimal(got) != Decimal(n), r.log)
    # C2: sumas que fallan en coma flotante binaria
    casos = [("C2_0.1+0.2", ["0.1", "0.2"], "USD", "0.3"),
             ("C2_tres_decimos_BTC", ["0.10000001", "0.10000001", "0.10000001"], "BTC", "0.30000003"),
             ("C2_grande_mas_centavo", ["1000000000000000", "0.01"], "USD", "1000000000000000.01"),
             ("C2_diez_veces_0.1", ["0.1"] * 10, "USD", "1.0"),
             ("C2_negativos", ["1.10", "-2.20", "3.30"], "USD", "2.20")]
    for cid, ps, cur, exp in casos:
        body = CAB + f"2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n"
        for i, p in enumerate(ps):
            body += f'2020-01-0{1 + (i % 8) + 1} * "p{i}"\n  Assets:A  {p} {cur}\n  Equity:E\n'
        L = escribir(f"{d}/{cid}.beancount", body)
        j, r = info(L, M, cid, ["Assets:A"])
        got = j.get("bal:Assets:A", {}).get(cur)
        reg.add(cid, "C2", f"Saldo exacto de {'+'.join(ps)}", exp, got, got is None or Decimal(got) != Decimal(exp), r.log)
    L = escribir(f"{d}/peso.beancount", CAB + '2020-01-01 open Assets:PEN\n2020-01-01 open Assets:USD\n2020-01-01 open Assets:Acc\n'
                 '2020-01-02 * "w"\n  Assets:PEN  3 PEN @ 0.3333 USD\n  Assets:USD  -0.9999 USD\n'
                 '2020-01-03 * "c"\n  Assets:Acc  7 ACME {1.11 USD}\n  Assets:USD\n')
    j, r = info(L, M, "C2_peso_precio_costo", ["Assets:USD"])
    reg.add("C2_peso_precio_costo", "C2", "Peso de 3 PEN @ 0.3333 = 0.9999 y de 7 {1.11} = 7.77 sin redondeo",
            "USD -8.7699, 0 errores", (j.get("bal:Assets:USD"), j.get("errores")),
            not (j.get("bal:Assets:USD") == {"USD": "-8.7699"} and not j.get("errores")), r.log)
    # C3: lo que muestra bean-query (precisión de presentación)
    L = escribir(f"{d}/mixto.beancount", CAB + '2020-01-01 open Assets:Btc\n2020-01-01 open Equity:E\n'
                 '2020-01-02 * "a"\n  Assets:Btc  1 BTC\n  Equity:E\n2020-01-03 * "b"\n  Assets:Btc  2 BTC\n  Equity:E\n'
                 '2020-01-04 * "c"\n  Assets:Btc  0.12345678 BTC\n  Equity:E\n')
    for cid, args, exp in (("C3_texto_sum_position", ["SELECT sum(position) AS s WHERE account = 'Assets:Btc'"], "3.12345678 BTC"),
                           ("C3_csv_sum_number", ["-f", "csv", "SELECT sum(number) AS s WHERE account = 'Assets:Btc'"], "3.12345678"),
                           ("C3_numberify", ["-m", "SELECT sum(position) AS s WHERE account = 'Assets:Btc'"], "3.12345678")):
        r = run([QRY, "-q", *args[:-1], L, args[-1]], M, cid)
        lines = [x.strip() for x in r.out.strip().splitlines() if x.strip() and not set(x.strip()) <= set("-")]
        got = lines[-1] if lines else r.todo[-150:]
        reg.add(cid, "C3", f"bean-query muestra el saldo 1+2+0.12345678 BTC con la precisión requerida", exp, got, got != exp, r.log)
    r = run([QRY, "-q", "-f", "csv", f"{d}/C2_0.1+0.2.beancount", "SELECT sum(number) AS s"], M, "C3_csv_0.1+0.2")
    got = r.out.strip().splitlines()[-1].strip()
    reg.add("C3_csv_0.1+0.2", "C3", "bean-query suma 0.1+0.2 (+ contrapartida) y la cuenta A da 0.3", "0", got, Decimal(got) != 0, r.log)
    reg.guardar()


# ------------------------------------------------------------------ 004
def m004():
    M = "004"
    reg = Registro(M)
    d = wdir(M)
    S = LEDG + "/sint_303.beancount"
    ref, _ = saldos(S, M, "ref_sint303")
    # C1-a: el printer de Beancount produce texto que se recarga igual
    code = r'''
import sys
from beancount import loader
from beancount.parser import printer
e, err, o = loader.load_file(sys.argv[1])
with open(sys.argv[2], "w") as f:
    for op in ("operating_currency",):
        for c in o[op]: f.write('option "%s" "%s"\n' % (op, c))
    f.write('option "booking_method" "FIFO"\n')
    printer.print_entries(e, file=f)
'''
    out = f"{d}/impreso.beancount"
    r = py(code, M, "C1_printer", args=[S, out])
    j, r2 = saldos(out, M, "C1_printer_recarga")
    ok = j and j["saldos"] == ref["saldos"] and not j["errores"]
    reg.add("C1_printer", "C1", "Texto beancount generado por beancount.parser.printer se recarga con los mismos saldos",
            "saldos idénticos, 0 errores", f"iguales={j and j['saldos'] == ref['saldos']}, errores={j and j['errores'][:2]}", ok, r.log + " ; " + r2.log)
    # C1-b: el mismo archivo leído por otro software: Beancount 2.3.6
    j2, r = saldos(S, M, "C1_leido_por_v2", v2=True)
    ok = j2 and j2["saldos"] == ref["saldos"] and not j2["errores"]
    reg.add("C1_leido_por_v2", "C1", "El libro de texto se intercambia con Beancount 2.3.6 (otro software) con los mismos saldos",
            "saldos idénticos, 0 errores", f"iguales={j2 and j2['saldos'] == ref['saldos']}, errores={j2 and j2['errores'][:2]}", ok, r.log)
    # C3-c: CSV de bean-query leído con csv de Python
    r = run([QRY, "-q", "-f", "csv", S, "SELECT account, currency, sum(number) AS total GROUP BY account, currency"], M, "C3_csv")
    try:
        rows = list(csv.DictReader(io.StringIO(r.out)))
        got = {x["account"].strip() + "|" + x["currency"].strip(): str(Decimal(x["total"].strip())) for x in rows}
        ok = {k: Decimal(v) for k, v in got.items() if Decimal(v) != 0} == {k: Decimal(v) for k, v in ref["saldos"].items()}
    except Exception as e:
        ok, got = False, repr(e)
    reg.add("C3_csv", "C3", "Salida CSV de bean-query leída por el módulo csv de Python con los mismos valores",
            "valores idénticos", f"filas={len(rows) if ok else '-'} coincide={ok}", ok, r.log)
    # C3-d: -f beancount con PRINT recargado por el cargador
    out2 = f"{d}/print.beancount"
    r = run([QRY, "-q", "-f", "beancount", "-o", out2, S, "PRINT"], M, "C3_beancount_print")
    hdr = 'option "operating_currency" "USD"\noption "booking_method" "FIFO"\n'
    escribir(f"{d}/print_con_opciones.beancount", hdr + open(out2).read())
    j, r2 = saldos(f"{d}/print_con_opciones.beancount", M, "C3_beancount_print_recarga")
    ok = j and j["saldos"] == ref["saldos"] and not j["errores"]
    reg.add("C3_beancount_print", "C3", "Salida -f beancount (PRINT) de bean-query recargada por el cargador",
            "saldos idénticos, 0 errores", f"iguales={j and j['saldos'] == ref['saldos']} errores={j and j['errores'][:2]}", ok, r.log + " ; " + r2.log)
    # C3-e: JSON de errores de bean-check leído con json
    E = escribir(f"{d}/errores.beancount", CAB + '2020-01-01 open Assets:A USD\n2020-01-02 * "u"\n  Assets:A 1 USD\n  Assets:B -2 USD\n')
    r = run([CHK, "--json", E], M, "C3_json_errores")
    try:
        js = json.loads(r.out)
        ok = all({"message", "filename", "lineno"} <= set(x) for x in js["errors"]) and len(js["errors"]) == 2
    except Exception as e:
        ok, js = False, repr(e)
    reg.add("C3_json_errores", "C3", "bean-check --json produce JSON válido con filename, lineno y message por error",
            "2 errores con 3 campos", str(js)[:160], ok, r.log)
    # C3-f: salida de bean-format recargada (texto beancount reformateado)
    r = run([FMT, "-o", f"{d}/fmt.beancount", S], M, "C3_bean_format")
    j, r2 = saldos(f"{d}/fmt.beancount", M, "C3_bean_format_recarga")
    ok = j and j["saldos"] == ref["saldos"] and not j["errores"]
    reg.add("C3_bean_format", "C3", "Salida de bean-format recargada por Beancount 3.2.3 y 2.3.6",
            "saldos idénticos", f"iguales={ok}", ok, r.log + " ; " + r2.log)
    # Nota: aquí cuenta_A = formato intercambiado con éxito (A de la fórmula X = A/B)
    reg.guardar(nota="cuenta_A=True significa formato intercambiado exitosamente")


# ------------------------------------------------------------------ 005
ILEGALES = [
    ("desbalanceada", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Expenses:B USD\n2020-01-02 * "x"\n  Assets:A 10 USD\n  Expenses:B -9 USD\n', ["does not balance"]),
    ("cuenta_no_abierta", "C2", '2020-01-01 open Assets:A USD\n2020-01-02 * "x"\n  Assets:A 10 USD\n  Expenses:Nunca -10 USD\n', ["unknown account", "Expenses:Nunca"]),
    ("cuenta_cerrada", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Expenses:B USD\n2020-01-05 close Expenses:B\n2020-02-01 * "x"\n  Assets:A 10 USD\n  Expenses:B -10 USD\n', ["inactive", "Expenses:B"]),
    ("moneda_no_permitida", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Expenses:B USD\n2020-01-02 * "x"\n  Assets:A 10 EUR\n  Expenses:B -10 EUR\n', ["currency", "EUR"]),
    ("asercion_falsa", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n2020-01-02 * "x"\n  Assets:A 10 USD\n  Equity:E\n2020-01-03 balance Assets:A 11 USD\n', ["Balance failed", "Assets:A"]),
    ("reducir_lote_inexistente", "C2", '2020-01-01 open Assets:Acc ACME "STRICT"\n2020-01-01 open Assets:C USD\n2020-01-02 * "x"\n  Assets:Acc 5 ACME {10 USD}\n  Assets:C\n2020-01-03 * "y"\n  Assets:Acc -2 ACME {99 USD}\n  Assets:C 198 USD\n', ["No position matches", "ACME"]),
    ("vender_mas_de_lo_tenido", "C2", '2020-01-01 open Assets:Acc ACME "FIFO"\n2020-01-01 open Assets:C USD\n2020-01-02 * "x"\n  Assets:Acc 5 ACME {10 USD}\n  Assets:C\n2020-01-03 * "y"\n  Assets:Acc -8 ACME {}\n  Assets:C 80 USD\n', ["Not enough", "ACME"]),
    ("doble_open", "C2", '2020-01-01 open Assets:A USD\n2020-01-05 open Assets:A USD\n', ["Duplicate open", "Assets:A"]),
    ("close_sin_open", "C2", '2020-01-05 close Assets:Fantasma\n', ["Unopened account", "Assets:Fantasma"]),
    ("dos_montos_omitidos", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Expenses:B USD\n2020-01-01 open Expenses:C USD\n2020-01-02 * "x"\n  Assets:A 10 USD\n  Expenses:B\n  Expenses:C\n', ["auto-posting", "missing"]),
    ("pad_sin_uso", "C2", '2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n2020-01-02 pad Assets:A Equity:E\n', ["Unused Pad", "pad"]),
    ("documento_inexistente", "C2", '2020-01-01 open Assets:A USD\n2020-01-02 document Assets:A "/no/existe/recibo.pdf"\n', ["does not exist", "recibo.pdf"]),
    ("cuenta_raiz_invalida", "C1", '2020-01-01 open Activos:Caja USD\n', ["Activos:Caja", "nvalid"]),
    ("fecha_invalida", "C1", '2020-01-01 open Assets:A USD\n2023-02-30 open Assets:B USD\n', ["2023-02-30", "date", "day"]),
    ("moneda_con_sintaxis_invalida", "C1", '2020-01-01 open Assets:A usd\n', ["syntax", "usd", "nexpected"]),
]


def m005():
    M = "005"
    reg = Registro(M)
    d = wdir(M)
    msgs = {}
    for name, comp, body, kws in ILEGALES:
        L = escribir(f"{d}/{name}.beancount", CAB + body)
        j, r = info(L, M, f"API_{name}")
        errs = j.get("errores", [])
        txt = " ".join(errs).lower()
        det = bool(errs) and any(k.lower() in txt for k in kws)
        reg.add(f"{comp}_{name}", comp, f"Operación ilegal: {name.replace('_', ' ')} (API loader)",
                f"error que mencione {kws}", errs[:2], det, r.log)
        r = run([CHK, "-C", L], M, f"CLI_{name}")
        det = r.rc == 1 and not r.traceback and any(k.lower() in r.err.lower() for k in kws)
        msgs[name] = r.err
        reg.add(f"C3_{name}", "C3", f"Operación ilegal: {name.replace('_', ' ')} (bean-check)",
                f"rc=1 y mensaje con {kws}", f"rc={r.rc} {r.err.strip().splitlines()[0][:150] if r.err.strip() else ''}", det, r.log)
    json.dump(msgs, open(f"{d}/mensajes_bean_check.json", "w"), indent=1, ensure_ascii=False)
    reg.guardar(nota="cuenta_A=True significa tipo de operación ilegal detectado")


# ------------------------------------------------------------------ 006 / 007
def m006_007():
    M = "006_007"
    reg = Registro(M)   # cada caso guarda mayor (A de 006) y menor (B de 007)
    d = wdir(M)

    def caso(cid, comp, desc, mayor, menor, obs, evid):
        c = reg.add(cid, comp, desc, "sin corrupción", obs, mayor, evid)
        c["menor"] = bool(menor)

    # C3-1..3: herramientas de solo lectura no alteran el libro
    L = shutil.copy(EJEMPLO, f"{d}/libro.beancount")
    h0 = sha(L)
    for cid, cmd in (("C3_check_no_modifica", [CHK, L]),
                     ("C3_query_no_modifica", [QRY, "-q", L, "SELECT account, sum(position) GROUP BY account"]),
                     ("C3_doctor_no_modifica", [DOC, "roundtrip", L]),
                     ("C3_format_stdout_no_modifica", [FMT, L])):
        r = run(cmd, M, cid, timeout=120)
        caso(cid, "C3", f"{os.path.basename(cmd[0])} {cmd[1] if len(cmd) > 2 else ''} no modifica el archivo fuente",
             sha(L) != h0, r.caida, f"hash igual={sha(L) == h0}, rc={r.rc}", r.log)
    # C3-5: bean-format -o sobre el mismo archivo: cambia el texto pero no el contenido contable
    ref, _ = saldos(L, M, "ref_saldos")
    L2 = shutil.copy(EJEMPLO, f"{d}/libro_fmt.beancount")
    r = run([FMT, "-o", L2, L2], M, "C3_format_in_place")
    j, r2 = saldos(L2, M, "C3_format_in_place_saldos")
    caso("C3_format_in_place", "C3", "bean-format -o sobre el mismo libro conserva todas las entradas y saldos",
         not (j and j["saldos"] == ref["saldos"] and j["n_entries"] == ref["n_entries"]), False,
         f"saldos iguales={j and j['saldos'] == ref['saldos']}, entradas {j and j['n_entries']} vs {ref['n_entries']}", r.log)
    # C3-6: Unicode preservado por bean-format
    U = escribir(f"{d}/unicode.beancount", CAB + '2020-01-01 open Assets:Caja USD\n2020-01-01 open Expenses:Café USD\n'
                 '2020-01-02 * "Panadería Ñandú" "Pan 🍞 y café"\n  Expenses:Café 3.50 USD\n  Assets:Caja\n')
    r = run([FMT, "-o", f"{d}/unicode_fmt.beancount", U], M, "C3_format_unicode")
    t = open(f"{d}/unicode_fmt.beancount", encoding="utf-8").read()
    caso("C3_format_unicode", "C3", "bean-format conserva acentos, ñ y emoji", not ("Ñandú" in t and "🍞" in t and "Café" in t), False,
         f"conservado={'Ñandú' in t and '🍞' in t}", r.log)
    # C1: caché (grande, > 1 s de carga => se escribe .picklecache)
    G = shutil.copy(GRANDE, f"{d}/grande.beancount")
    cache = f"{d}/.grande.beancount.picklecache"
    hg = sha(G)
    refG, _ = saldos(G, M, "ref_grande")      # crea la caché
    # C1-1: SIGKILL a mitad de la escritura de la caché
    for f in (cache,):
        if os.path.exists(f):
            os.remove(f)
    p = subprocess.Popen([CHK, G], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(3.0)
    p.send_signal(signal.SIGKILL)
    p.wait()
    r = run([CHK, G], M, "C1_sigkill_luego_check", timeout=300)
    j, _ = saldos(G, M, "C1_sigkill_saldos")
    caso("C1_sigkill", "C1", "SIGKILL durante bean-check (3 s); luego la siguiente ejecución da el resultado correcto",
         sha(G) != hg, not (r.rc == 0 and j["saldos"] == refG["saldos"]), f"fuente intacta={sha(G) == hg}, rc={r.rc}, saldos ok={j['saldos'] == refG['saldos']}", r.log)
    # C1-2: caché corrupta (bytes basura)
    with open(cache, "wb") as f:
        f.write(os.urandom(4096))
    j, r = saldos(G, M, "C1_cache_corrupta")
    caso("C1_cache_corrupta", "C1", "Caché .picklecache con bytes basura: se descarta y se recalcula",
         sha(G) != hg, not (j and j["saldos"] == refG["saldos"]), f"saldos ok={j and j['saldos'] == refG['saldos']}; stderr={r.err.strip()[:120]}", r.log)
    # C1-3: caché obsoleta: se edita el libro conservando su mtime antiguo (p. ej. rsync -t / cp -p)
    st = os.stat(G)
    run([CHK, G], M, "C1_cache_obsoleta_previo", timeout=300)          # asegura caché vigente
    txt = open(G, encoding="utf-8").read()
    marca = "2005-01-01 * \"Saldo inicial\"\n  Assets:Bank:Checking  10000.00 USD"
    assert marca in txt
    G2 = txt.replace(marca, marca.replace("10000.00", "90000.00"), 1)
    with open(G, "w", encoding="utf-8") as f:
        f.write(G2)
    os.utime(G, ns=(st.st_atime_ns, st.st_mtime_ns))   # misma fecha al nanosegundo y mismo tamaño
    j, r = saldos(G, M, "C1_cache_obsoleta")
    esperado = str(Decimal(refG["saldos"]["Assets:Bank:Checking|USD"]) + 80000)
    obtenido = j["saldos"].get("Assets:Bank:Checking|USD")
    caso("C1_cache_obsoleta", "C1", "Libro editado conservando su fecha de modificación: ¿se usa la caché obsoleta?",
         False, obtenido != esperado, f"esperado {esperado}, obtenido {obtenido} (errores={len(j['errores'])})", r.log)
    shutil.copy(GRANDE, G)
    if os.path.exists(cache):
        os.remove(cache)
    # C1-4: ejecuciones concurrentes escribiendo la misma caché
    procs = [subprocess.Popen([PY3, "-I", f"{WORK}/snippets/{M}_ref_grande.py", G], stdout=subprocess.PIPE, stderr=subprocess.PIPE) for _ in range(5)]
    res = [p.communicate() for p in procs]
    oks = 0
    for o, e in res:
        try:
            oks += json.loads(o.decode().strip().splitlines()[-1])["saldos"] == refG["saldos"]
        except Exception:
            pass
    escribir(f"{RAW}/{M}/C1_concurrente.txt", "5 procesos load_file simultáneos sobre grande.beancount\n" +
             "\n".join(f"proc{i}: ok={json.loads(o.decode().strip().splitlines()[-1])['saldos'] == refG['saldos'] if o else False} stderr={e.decode()[:200]}" for i, (o, e) in enumerate(res)))
    j, r = saldos(G, M, "C1_concurrente_despues")
    caso("C1_concurrente", "C1", "5 cargas concurrentes que escriben la misma caché; todas y la siguiente dan saldos correctos",
         sha(G) != hg, not (oks == 5 and j["saldos"] == refG["saldos"]), f"{oks}/5 correctas, posterior ok={j['saldos'] == refG['saldos']}", f"logs/raw/{M}/C1_concurrente.txt")
    # C1-5: directorio sin permiso de escritura para la caché (usuario nobody)
    RO = f"{d}/ro"
    os.makedirs(RO, exist_ok=True)
    shutil.copy(GRANDE, f"{RO}/grande.beancount")
    os.chmod(RO, 0o555)
    os.chmod(f"{RO}/grande.beancount", 0o444)
    r = run(["runuser", "-u", "nobody", "--", CHK, f"{RO}/grande.beancount"], M, "C1_sin_permiso_cache", timeout=300)
    caso("C1_sin_permiso_cache", "C1", "Directorio de solo lectura (no se puede escribir la caché): la validación funciona igual",
         False, r.rc != 0 or r.traceback, f"rc={r.rc}, aviso={r.err.strip()[:120]}", r.log)
    # C1-6: CRLF
    C = escribir(f"{d}/crlf.beancount", open(LEDG + "/sint_101.beancount", encoding="utf-8").read().replace("\n", "\r\n"))
    j, r = saldos(C, M, "C1_crlf")
    ref101, _ = saldos(LEDG + "/sint_101.beancount", M, "ref_101")
    caso("C1_crlf", "C1", "Libro con fines de línea CRLF (Windows) produce los mismos saldos",
         False, not (j and j["saldos"] == ref101["saldos"]), f"iguales={j and j['saldos'] == ref101['saldos']}, errores={j and len(j['errores'])}", r.log)
    # C2-1: complementos no modifican el fuente; C2-2: carga determinista
    P = escribir(f"{d}/plugins.beancount", 'plugin "beancount.plugins.auto_accounts"\nplugin "beancount.plugins.implicit_prices"\n'
                 + open(LEDG + "/sint_101.beancount", encoding="utf-8").read())
    hp = sha(P)
    j1, r = saldos(P, M, "C2_plugins_1")
    j2, r2 = saldos(P, M, "C2_plugins_2")
    caso("C2_plugins_no_modifican", "C2", "Complementos auto_accounts e implicit_prices no escriben sobre el archivo fuente",
         sha(P) != hp, False, f"hash igual={sha(P) == hp}", r.log)
    caso("C2_determinismo", "C2", "Dos cargas del mismo libro producen exactamente los mismos datos en memoria",
         False, j1 != j2, f"idénticas={j1 == j2}", r.log + " ; " + r2.log)
    j3, r3 = saldos(LEDG + "/sint_202.beancount", M, "C2_orden_1")
    sh = escribir(f"{d}/desordenado.beancount", "\n\n".join(
        sorted(open(LEDG + "/sint_202.beancount", encoding="utf-8").read().split("\n\n"), key=lambda b: hash(b) % 997)))
    j4, r4 = saldos(sh, M, "C2_orden_2")
    caso("C2_orden_independiente", "C2", "El orden físico de las entradas en el archivo no altera los saldos (orden por fecha)",
         False, not (j4 and j4["saldos"] == j3["saldos"]), f"iguales={j4 and j4['saldos'] == j3['saldos']}, errores={j4 and len(j4['errores'])}", r4.log)
    reg.guardar(nota="cuenta_A = evento de corrupción MAYOR (006); campo 'menor' = evento MENOR (007)")


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        print("====", f, flush=True)
        globals()[f]()


def m006_obsoleta_ns():
    """Repetición del caso C1_cache_obsoleta restaurando la fecha de modificación al nanosegundo
    (la primera versión usó segundos y Beancount compara st_mtime_ns, por lo que no reproducía el escenario)."""
    M = "006_007"
    d = wdir(M)
    G = shutil.copy(GRANDE, f"{d}/grande_ns.beancount")
    cache = f"{d}/.grande_ns.beancount.picklecache"
    if os.path.exists(cache):
        os.remove(cache)
    ref, r0 = saldos(G, M, "C1_cache_obsoleta_ns_ref")          # crea la caché (> 1 s)
    st = os.stat(G)
    txt = open(G, encoding="utf-8").read()
    marca = "2005-01-01 * \"Saldo inicial\"\n  Assets:Bank:Checking  10000.00 USD"
    with open(G, "w", encoding="utf-8") as f:
        f.write(txt.replace(marca, marca.replace("10000.00", "90000.00"), 1))
    os.utime(G, ns=(st.st_atime_ns, st.st_mtime_ns))
    assert os.stat(G).st_size == st.st_size and os.stat(G).st_mtime_ns == st.st_mtime_ns
    j, r = saldos(G, M, "C1_cache_obsoleta_ns")
    esperado = str(Decimal(ref["saldos"]["Assets:Bank:Checking|USD"]) + 80000)
    obtenido = j["saldos"].get("Assets:Bank:Checking|USD")
    r2 = run([CHK, "-C", G], M, "C1_cache_obsoleta_ns_sin_cache", timeout=600)
    data = json.load(open(f"{OUT}/{M}.json", encoding="utf-8"))
    data["casos"] = [c for c in data["casos"] if c["id"] != "C1_cache_obsoleta"]
    data["casos"].append(dict(
        id="C1_cache_obsoleta", comp="C1",
        desc="Libro editado (mismo tamaño) conservando su fecha de modificación al nanosegundo (cp -p / rsync -t): ¿se usa la caché obsoleta?",
        esperado="detectar el cambio y recalcular", cuenta_A=False, menor=obtenido != esperado,
        observado=f"saldo esperado {esperado}, obtenido {obtenido} en {r.dt:.1f} s; errores con caché={len(j['errores'])}, "
                  f"bean-check -C (sin caché) rc={r2.rc}",
        evidencia=r0.log + " ; " + r.log + " ; " + r2.log,
        nota="Primera versión del caso (restauración en segundos) descartada: no reproducía el escenario."))
    json.dump(data, open(f"{OUT}/{M}.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print("obsoleta_ns:", data["casos"][-1]["observado"])
