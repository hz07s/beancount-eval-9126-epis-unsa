# -*- coding: utf-8 -*-
"""Genera el informe .docx siguiendo la estructura de la plantilla
'Informe_Evaluación_Calidad_Software_EPIS_CS_v1.0' con los datos medidos de Beancount.
Uso: python build_docx.py salida.docx [paginas.json]"""
import json
import os
import statistics
import sys

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

sys.path.insert(0, os.path.dirname(__file__))
from catalogo import (CLARRUS_ATRIBUTOS, INCLUIDOS, ORDEN_BASE, EXCEPCIONES, JUSTIF_ORDEN, MAPEO, JUSTIF_MAPEO,
                      ISO_ARBOL, MOTIVO_N, COMPONENTES, RNF, METRICAS, PRODUCTO, UMBRAL_PRINCIPAL, UMBRAL_SUB, gana)

DST = sys.argv[1]
PAGS = json.load(open(sys.argv[2])) if len(sys.argv) > 2 and os.path.exists(sys.argv[2]) else {}
OUT = "/home/claude/eval/out"
R = json.load(open(f"{OUT}/resultados.json", encoding="utf-8"))
RM = {m["n"]: m for m in R["metricas"]}
SUBS = R["subs"]
CAT = {m["n"]: m for m in METRICAS}
J = lambda m: json.load(open(f"{OUT}/{m}.json", encoding="utf-8"))
COMPN = {k: v[0] for k, v in COMPONENTES.items()}

GRUPO = "[COMPLETAR: nombre del grupo]"
INTEG = "[COMPLETAR: integrantes]"
FECHA = "[COMPLETAR: fecha]"

COL = {"verde": "C6EFCE", "rojo": "FFC7CE", "amarillo": "FFEB9C", "gris": "D9D9D9", "hdr": "1F3864", "sub": "D9E1F2"}

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Arial"
st.font.size = Pt(10)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
for lvl, size in ((1, 14), (2, 12), (3, 11)):
    h = doc.styles[f"Heading {lvl}"]
    h.font.name = "Arial"; h.font.size = Pt(size); h.font.bold = True; h.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
    h.element.rPr.rFonts.set(qn("w:ascii"), "Arial"); h.element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.left_margin = sec.right_margin = Cm(2.2)
sec.top_margin, sec.bottom_margin = Cm(2.5), Cm(2.2)


# ------------------------------------------------------------------ utilidades
def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    s = OxmlElement("w:shd"); s.set(qn("w:val"), "clear"); s.set(qn("w:color"), "auto"); s.set(qn("w:fill"), color)
    tcPr.append(s)


def grid(table, widths):
    """Fija anchos en tblGrid (LibreOffice/Word los usan) y desactiva el autoajuste."""
    table.autofit = False
    g = table._tbl.tblGrid
    for i, gc in enumerate(g.findall(qn("w:gridCol"))):
        if i < len(widths):
            gc.set(qn("w:w"), str(int(widths[i] * 567)))
    tblPr = table._tbl.tblPr
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    for row in table.rows:
        for i, w in enumerate(widths):
            row.cells[i].width = Cm(w)


def borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for e in ("top", "left", "bottom", "right", "insideH", "insideV"):
        x = OxmlElement(f"w:{e}"); x.set(qn("w:val"), "single"); x.set(qn("w:sz"), "4"); x.set(qn("w:color"), "808080")
        b.append(x)
    tblPr.append(b)


def P(text="", bold=False, italic=False, size=None, align=None, color=None, style=None, space_after=4):
    p = doc.add_paragraph(style=style)
    if text:
        add_runs(p, text, bold, italic, size, color)
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_runs(p, text, bold=False, italic=False, size=None, color=None):
    """Admite **negrita** en línea."""
    parts = text.split("**")
    for i, t in enumerate(parts):
        if not t:
            continue
        r = p.add_run(t)
        r.bold = bold or (i % 2 == 1)
        r.italic = italic
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
    return p


def B(text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    add_runs(p, text)
    p.paragraph_format.space_after = Pt(2)
    return p


def H(text, level):
    return doc.add_heading(text, level=level)


def T(headers, rows, widths, fills=None, size=8.5, hdr_fill=COL["hdr"], bold_first=False):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    borders(t)
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        c.text = ""
        add_runs(c.paragraphs[0], h, bold=True, size=size, color="FFFFFF" if hdr_fill == COL["hdr"] else None)
        shade(c, hdr_fill)
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            add_runs(cells[i].paragraphs[0], str(v), bold=bold_first and i == 0, size=size)
            if fills and fills[ri]:
                f = fills[ri]
                if isinstance(f, dict):
                    if i in f:
                        shade(cells[i], f[i])
                else:
                    shade(cells[i], f)
    grid(t, widths)
    # repetir cabecera
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader"); th.set(qn("w:val"), "true"); trPr.append(th)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def ficha(rows):
    t = doc.add_table(rows=0, cols=2)
    borders(t)
    for k, v in rows:
        c = t.add_row().cells
        c[0].text = ""; c[1].text = ""
        add_runs(c[0].paragraphs[0], k, bold=True, size=8.5)
        shade(c[0], COL["sub"])
        add_runs(c[1].paragraphs[0], str(v), size=8.5)
    grid(t, [4.6, 12])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def field(run, instr):
    for kind, text in (("begin", None), (None, instr), ("separate", None), (None, "1"), ("end", None)):
        if kind:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), kind); run._r.append(e)
        elif text == instr:
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = instr; run._r.append(e)
        else:
            e = OxmlElement("w:t"); e.text = text; run._r.append(e)


def f4(x):
    return f"{x:.4f}"


def pct(x):
    return f"{100 * x:.2f} %"


def pb():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


# ------------------------------------------------------------------ encabezado y pie (como la plantilla)
hdr = sec.header
ht = hdr.add_table(rows=2, cols=2, width=Cm(16.6))
borders(ht)
for (r, c), txt in {(0, 0): "Evaluación de calidad de producto: Beancount 3.2.3", (0, 1): "Versión 1.0",
                    (1, 0): "Informe de evaluación de Calidad de Software", (1, 1): FECHA}.items():
    cell = ht.cell(r, c); cell.text = ""
    add_runs(cell.paragraphs[0], txt, bold=(r == 0), size=8.5)
grid(ht, [12.6, 4])
ftr = sec.footer.paragraphs[0]
ftr.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = ftr.add_run("Confidencial    |    Calidad de Software – EPIS UNSA    |    Página "); r.font.size = Pt(8)
r = ftr.add_run(); r.font.size = Pt(8); field(r, "PAGE")
r = ftr.add_run(" de "); r.font.size = Pt(8)
r = ftr.add_run(); r.font.size = Pt(8); field(r, "NUMPAGES")

# ------------------------------------------------------------------ portada
for _ in range(5):
    P()
P(GRUPO, bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER)
P()
P("Proyecto Beancount", bold=True, size=20, align=WD_ALIGN_PARAGRAPH.CENTER)
P("Informe de evaluación de Calidad de Producto de Software", size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
P("Versión 1.0", size=12, align=WD_ALIGN_PARAGRAPH.CENTER)
P()
P(f"Producto evaluado: Beancount {PRODUCTO['version']} (commit {PRODUCTO['commit'][:12]}), https://github.com/beancount/beancount",
  size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
P("Modelo: NTP-ISO/IEC 9126-1:2004 · Métricas externas: NTP-ISO/IEC TR 9126-2 · Priorización: técnica de Brosseau (Clarrus)",
  size=9, italic=True, align=WD_ALIGN_PARAGRAPH.CENTER)
for _ in range(4):
    P()
P("ELABORADO POR:", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
P(INTEG, align=WD_ALIGN_PARAGRAPH.CENTER)
P()
P("Docente: Prof. M.Sc. Ing. Robert Arisaca M.", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
P("Curso: Calidad de Software – Escuela Profesional de Ingeniería de Sistemas, UNSA", align=WD_ALIGN_PARAGRAPH.CENTER)
P(f"Fecha: {FECHA}", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
pb()

# ------------------------------------------------------------------ índice (estático, páginas tomadas del render)
P("Tabla de Contenido", bold=True, size=14)
INDICE = [("PARTE II – EVALUACIÓN DE CALIDAD DE PRODUCTO", 0), ("1. Introducción", 0), ("2. Modelo de Calidad de Producto", 0),
          ("2.1 Priorización de atributos (técnica de Brosseau)", 1), ("2.2 Sub-características seleccionadas y pesos", 1),
          ("2.3 Justificación técnica de la selección", 1), ("2.4 Requerimientos no funcionales y métricas", 1),
          ("3. Catálogo de métricas", 0)]
for m in METRICAS:
    INDICE.append((f"3.{int(m['n'])} Sub-característica: {m['sub'].upper()} / MÉTRICA: {m['n']} – {m['nombre']}", 1))
INDICE += [("3.26 Métricas de la norma descartadas", 1), ("4. Resultados de la evaluación", 0), ("4.1 Componentes evaluados", 1),
           ("4.2 Resultados por métrica y componente", 1), ("4.3 Resumen por sub-característica y puntaje global", 1),
           ("4.4 Hallazgos principales", 1), ("5. Conclusiones", 0), ("6. Recomendaciones", 0),
           ("ANEXO A – MATRIZ DE BROUSSEAU", 0), ("ANEXO B – EVIDENCIAS DE RESULTADOS DE EVALUACIÓN", 0)]
for txt, lvl in INDICE:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.8 * lvl)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.tab_stops.add_tab_stop(Cm(16.4), alignment=2, leader=1)  # derecha, puntos
    run = p.add_run(f"{txt}\t{PAGS.get(txt, '')}")
    run.font.size = Pt(8.5 if lvl else 9.5)
    run.bold = lvl == 0
pb()

# ------------------------------------------------------------------ PARTE II
H("PARTE II – EVALUACIÓN DE CALIDAD DE PRODUCTO", 1)
H("1. Introducción", 1)
ntot = len(METRICAS)
P(f"Este informe presenta la evaluación de la calidad de producto de **Beancount**, un sistema de contabilidad de partida doble "
  f"en texto plano escrito en Python con un analizador léxico/sintáctico en C. El usuario registra sus transacciones en "
  f"archivos .beancount; las herramientas de línea de comandos leen el libro, aplican las reglas contables (balanceo de cada "
  f"transacción, cuentas abiertas, monedas permitidas, aserciones de saldo, lotes con costo) y producen validaciones y "
  f"reportes. Al ser la fuente de verdad financiera del usuario, la exactitud de los cálculos y la integridad del libro "
  f"son requisitos de primer orden.")
P("**Alcance.** Se evaluó la calidad externa (comportamiento del software en ejecución) de la última versión estable. "
  "No se usaron métricas internas (complejidad ciclomática, líneas de código, etc.) como métricas de evaluación. Se "
  "definieron tres componentes (sección 4.1): C1 Analizador y cargador, C2 Núcleo contable y C3 Herramientas de línea de "
  "comandos. Quedan fuera Fava (interfaz web, proyecto aparte), beangulp y beanprice (paquetes separados). bean-query "
  "se incluye porque en la versión 3 se distribuye como paquete beanquery y es la herramienta de consulta oficial.")
ent = open("/home/claude/eval/logs/entorno.txt").read().splitlines()
T(["Elemento", "Valor"], [
    ["Producto / versión", f"Beancount {PRODUCTO['version']} (tag {PRODUCTO['tag']}, commit {PRODUCTO['commit']}, {PRODUCTO['fecha_commit']})"],
    ["Distribución usada", f"{PRODUCTO['wheel']}; beanquery {PRODUCTO['beanquery']}"],
    ["Versión de comparación", PRODUCTO["version_anterior"]],
    ["Sistema operativo", "Ubuntu 24.04.5 LTS, kernel Linux 6.18 x86_64 (máquina virtual de 2 vCPU y 7 GiB de RAM)"],
    ["Python", "3.13.18 (evaluación); 3.11 y 3.12 adicionalmente en la métrica de reinstalación"],
    ["Repositorio", "https://github.com/beancount/beancount (clonado; HEAD master 97472138, tag 3.2.3 en worktree)"],
], [4.5, 12.1])
P("**Estándar y metodología.** El modelo de calidad es la NTP-ISO/IEC 9126-1:2004 (cap. 6: seis características y 26 "
  "sub-características; Anexo A: métricas externas y criterios de selección y comparación). Las métricas y sus fórmulas "
  "provienen de la NTP-ISO/IEC TR 9126-2. El trabajo siguió las fases: (0) reconocimiento del repositorio, la "
  "documentación, la suite de pruebas y las herramientas; (1) pasos 1 y 2 de Clarrus/Brosseau: descarte de atributos y "
  "comparación por pares con score; (2) mapeo de atributos a sub-características ISO 9126-1, pesos y RNF; (3) selección de "
  f"{ntot} métricas externas de la 9126-2 con umbrales fijados **antes** de medir (registro con sello de tiempo en el Anexo B); "
  "(4) medición real automatizada sobre los tres componentes, con evidencia cruda de cada ejecución; (5) cálculo de "
  "resultados, normalización, puntaje por sub-característica y puntaje global ponderado.")
P("**Integridad de los datos.** Todos los valores del informe provienen de ejecuciones documentadas (comando, entrada, "
  "salida). No hay valores estimados ni métricas marcadas como NO MEDIDO. Donde interviene el juicio del evaluador "
  "(orden de importancia de los atributos, criterio de mensaje autoexplicativo, definición de umbrales) se indica "
  "expresamente para que el grupo lo valide.")

# ------------------------------------------------------------------ 2
H("2. Modelo de Calidad de Producto", 1)
P("Considerando los componentes identificados del producto, se define el modelo de calidad de producto basado en el "
  "estándar ISO/IEC 9126-1. La priorización por la técnica de Brosseau (Anexo A) determinó como sub-características "
  "**principales** Precisión, Madurez, Seguridad, Tolerancia a fallos, Testeabilidad y Operabilidad, y como **secundarias** "
  "Comportamiento en el tiempo, Reemplazabilidad, Instalabilidad, Cambiabilidad e Interoperabilidad.")
H("2.1 Priorización de atributos (técnica de Brosseau)", 2)
sc = R["scores"]
P(f"Paso 1: de los 16 atributos de la taxonomía de Clarrus (Wiegers) se incluyeron {len(INCLUIDOS)} y se excluyeron 6 "
  "(availability, safety, security, efficiency, reusability y scalability); el razonamiento de cada decisión está en la hoja "
  "'1 Attribute In or Out' y en el Anexo A. Paso 2: se compararon por pares los 10 restantes (45 comparaciones). El score de "
  "cada atributo es el número de comparaciones que gana. Se consideran principales los atributos con score ≥ "
  f"{UMBRAL_PRINCIPAL}.")
T(["Atributo", "Score", "Peso (score/45)", "Rol", "Razón de su posición"],
  [[a, sc[a], pct(R["pesos_atributo"][a]), "Principal" if sc[a] >= UMBRAL_PRINCIPAL else "Secundario", JUSTIF_ORDEN[a]]
   for a in sorted(INCLUIDOS, key=lambda a: -sc[a])],
  [2.6, 1.2, 2.0, 1.9, 8.9], fills=[COL["sub"] if sc[a] >= UMBRAL_PRINCIPAL else None for a in sorted(INCLUIDOS, key=lambda a: -sc[a])])

H("2.2 Sub-características seleccionadas y pesos", 2)
P("**Regla de pesos (reproducible):** (1) peso del atributo = score / 45; (2) peso de la sub-característica = Σ (peso del "
  "atributo × fracción del mapeo); reliability se reparte 50/50 entre Precisión y Madurez y los demás atributos se "
  "mapean 1:1; (3) peso absoluto de cada métrica = peso de su sub-característica / número de métricas de esa "
  "sub-característica. Los pesos suman 100 % y son los mismos en esta tabla, en las fichas, en el Anexo A y en el Excel "
  "(hojas 5 y 6).")
rows, fills = [], []
for car, ab, subs in ISO_ARBOL:
    for i, s in enumerate(subs):
        v = SUBS[s]
        rows.append([car if i == 0 else "", s, v["considerar"], f"{100 * v['peso']:.2f} %",
                     {"verde": "Principal – pasa", "rojo": "Principal – no pasa", "amarillo": "Secundaria (menor interés)",
                      "gris": "No considerada"}[v["color"]] + (f" ({v['puntaje']:.4f})" if v["puntaje"] is not None else "")])
        fills.append({1: COL[v["color"]], 2: COL[v["color"]], 3: COL[v["color"]], 4: COL[v["color"]]})
T(["Características", "Sub Característica", "Considerar", "Peso de la sub-característica", "Estado (puntaje medido)"], rows,
  [3.0, 4.6, 1.8, 3.0, 4.2], fills=fills)
P(f"Total de pesos: {100 * sum(v['peso'] for v in SUBS.values()):.2f} %.", italic=True)
p = P("Leyenda: ", bold=True, size=8.5)
for k, txt in (("verde", " Verde: sub-característica principal cuyo puntaje medido ≥ 0,80 (pasa). "),
               ("rojo", " Rojo: principal con puntaje < 0,80 (no pasa). "),
               ("amarillo", " Amarillo: atributo de menor interés (secundario; se mide y pondera, pero no define la aprobación). "),
               ("gris", " Gris: no considerada (N), peso 0.")):
    r = p.add_run("■"); r.font.color.rgb = RGBColor.from_string({"verde": "2E7D32", "rojo": "C62828", "amarillo": "C9A400", "gris": "808080"}[k]); r.font.size = Pt(11)
    r = p.add_run(txt); r.font.size = Pt(8.5)

H("2.3 Justificación técnica de la selección", 2)
P("Las sub-características consideradas (S) responden a lo que importa en un sistema de contabilidad de partida doble en texto plano:")
for a in sorted(INCLUIDOS, key=lambda a: -sc[a]):
    subs = ", ".join(s for s, _ in MAPEO[a])
    B(f"**{subs}** ← {a} (score {sc[a]}): {JUSTIF_MAPEO[a]}")
P("Coincidencias con la plantilla. Seguridad, Operabilidad, Testeabilidad y Reemplazabilidad coinciden con el ejemplo de la "
  "plantilla, pero por razones propias de Beancount: Seguridad se usa en su sentido de **protección de la información frente "
  "a modificaciones indebidas** (integridad del libro y rechazo de operaciones contables ilegales), no de control de usuarios, "
  "porque Beancount no tiene usuarios ni inicio de sesión; Operabilidad, porque la única interfaz es la línea de comandos y "
  "sus mensajes; Testeabilidad, porque verificar el libro es el uso principal; Reemplazabilidad, por la migración de libros de "
  "la versión 2 a la 3. Se excluyó Conformidad de fiabilidad del ejemplo por no existir normas declaradas.")
P("Sub-características no consideradas (N):")
for s, mot in MOTIVO_N.items():
    B(f"**{s}**: {mot}")

H("2.4 Requerimientos no funcionales y métricas", 2)
P("Cada sub-característica considerada se relaciona con requerimientos no funcionales (RNF) medibles de Beancount, derivados "
  "de su documentación (opciones, mensajes, herramientas) y del uso esperado. Son los mismos de la hoja '4 Measures' del Excel.")
T(["RNF", "Requerimiento no funcional medible", "Sub-característica", "Métricas"],
  [[rid, f"**{nom}.** {txt}", sub, ", ".join(ms)] for rid, nom, txt, sub, ms in RNF], [1.4, 10.0, 3.2, 2.0])

# ------------------------------------------------------------------ 3
pb()
H("3. Catálogo de métricas", 1)
P("La lista priorizada de sub-características se obtuvo de la aplicación (adaptación) de la técnica de Brosseau para la "
  "derivación sistemática de un modelo de calidad basado en sub-características de la ISO/IEC 9126. Para cada "
  "sub-característica principal se eligieron tres métricas externas de la NTP-ISO/IEC TR 9126-2 medibles en Beancount; para "
  "las secundarias, una o dos. Las métricas se numeran 001–025 siguiendo el orden de las tablas de la 9126-2 y se indica la "
  "tabla de origen. Fórmula, rango e interpretación se mantienen como en la norma. 'Valor' es el umbral esperado, fijado "
  "antes de medir; cuando la métrica no está en el rango 0–1 se define una normalización S ∈ [0,1] para el puntaje.")
P("**Contradicción documentada (métrica 016).** En la Tabla 8.3.3 e) 'Recuperabilidad de error operacional en uso' la fórmula es "
  "X = 1 − A/B (A = situaciones de recuperación insatisfactoria sin aviso), pero la interpretación dice 'el valor más cercano a "
  "0,0 es lo mejor'. Con esa fórmula X = 1 significa cero situaciones insatisfactorias, así que se resuelve por la lógica de la "
  "fórmula: **más cercano a 1,0 es lo mejor**.", size=9)
P("**Reinterpretación (métrica 005).** 'Control de acceso' presupone usuarios y permisos; Beancount es una herramienta local sin "
  "ellos. La nota 3 de la tabla 8.1.4 sugiere incluir 'tipos de operaciones ilegales' que modifiquen información indebidamente; "
  "en Beancount esas operaciones son las prohibidas por las reglas del lenguaje contable, por lo que se mide su detección.", size=9)
for m in METRICAS:
    rm = RM[m["n"]]
    car = rm["car"]
    peso_car = sum(SUBS[s]["peso"] for c, a, ss in ISO_ARBOL if c == car for s in ss)
    H(f"3.{int(m['n'])} Sub-característica: {m['sub'].upper()} / MÉTRICA: {m['n']} – {m['nombre']}", 2)
    filas = [("Código", rm["codigo"]), ("Abreviatura Característica", rm["abrev_car"]), ("Característica", car),
             ("Peso Característica", pct(peso_car)), ("Sub Característica", m["sub"]), ("Abreviatura Sub Caract.", rm["abrev_sub"]),
             ("Peso Sub Caract.", pct(SUBS[m["sub"]]["peso"])), ("Atributo/Métrica", m["nombre"]), ("Nro. Atributo", m["n"]),
             ("Tabla de origen (9126-2)", m["tabla"]), ("Propósito", m["proposito"]), ("Método de aplicación", m["metodo"]),
             ("Fórmula", m["formula"])]
    for i, (k, v) in enumerate(m["vars"].items()):
        etiqueta = ["Primer valor", "Segundo Valor", "Tercer valor", "Cuarto valor"][i]
        filas.append((f"{etiqueta} ({k})", f"{k} = {v}"))
    norm = {"tasa_cero": "S = 1 − A/N", "densidad": "S = 1 − X", "ratio_tiempo": "S = 1 si X ≤ 1; si no, S = 1/X",
            "tiempo": f"S = mín(1; {m['umbral']}/X)", "abs_alto": "S = X (ya está en 0–1)"}[m["tipo"]]
    filas += [("Peso Absoluto", pct(rm["peso_abs"])),
              ("Valor (umbral esperado)", f"X {m['op'].replace('<=', '≤').replace('>=', '≥')} {m['umbral']}. {m['just_umbral']}"),
              ("Rango", m["rango"]), ("Interpretación", m["interp"]), ("Normalización para el puntaje", norm),
              ("Componentes medidos", ", ".join(f"{c} ({COMPN[c]})" for c in ("C1", "C2", "C3") if c in rm["filas"]))]
    ficha(filas)

H("3.26 Métricas de la norma descartadas", 2)
P("Para cada sub-característica considerada se revisaron todas las métricas externas de su tabla en la 9126-2. Se descartaron las "
  "siguientes por no ser medibles con datos reales en Beancount (se prefiere descartar a inventar valores):")
DESC = [
    ("8.1.3", "Intercambiabilidad de datos (basado en el intento exitoso del usuario)", "Requiere registrar intentos de usuarios reales en operación; se usó la variante basada en formato."),
    ("8.1.4", "Auditoría de acceso", "Beancount no tiene usuarios, sesiones ni bitácora de accesos; no existe 'base de datos de historia de accesos' que contar. El control lo da el sistema operativo."),
    ("8.1.4", "Prevención de corrupción c) Z = A/T", "Redundante con a) y b) (mismos eventos divididos por tiempo); se informan a) y b)."),
    ("8.2.1", "Densidad estimada del error latente; Densidad de falla", "Requieren el tamaño del producto (medida interna, p. ej. LOC) o un modelo de crecimiento de fiabilidad con historial de fallas."),
    ("8.2.1", "Resolución de fallas; Eliminación de fallas; TMEF", "Requieren historial de fallas en operación (reportes de problemas) y tiempo de operación continuo; Beancount se ejecuta bajo demanda."),
    ("8.3.3", "Corrección de error (en uso), Disponibilidad del valor por defecto, Entendibilidad del mensaje en uso, Tiempo entre errores humanos", "Necesitan observar a usuarios reales con cronómetro (TUO); no hubo sesiones con usuarios. Se eligieron métricas objetivas de la misma tabla."),
    ("8.3.3", "Capacidad de deshacer, Personalización, Reducción de procedimientos, Accesibilidad física", "Beancount no tiene interfaz interactiva propia: la edición se hace en el editor del usuario y la accesibilidad depende del terminal."),
    ("8.4.1", "Tiempo de respuesta (simple), Rendimiento, Throughput, Tiempo de retorno y de espera", "No hay tareas concurrentes ni colas; el tiempo medio y el peor caso ya cubren el comportamiento observable."),
    ("8.5.2", "Eficiencia del ciclo de cambio, Tiempo de implementación, Complejidad de modificación, Control del cambio", "Requieren reportes de mantenimiento del proveedor o el tamaño del cambio (medida interna)."),
    ("8.5.4", "—", "Las tres métricas de testeabilidad fueron seleccionadas."),
    ("8.6.2", "Facilidad de instalación", "Mide cambios de la instalación 'a conveniencia del usuario', que en un paquete pip se reducen a la reinstalación ya medida."),
    ("8.6.4", "Consistencia funcional de soporte al usuario", "Requiere preguntar la opinión de usuarios que migraron de 2.x a 3.x."),
]
T(["Tabla", "Métrica", "Motivo del descarte"], [list(x) for x in DESC], [1.4, 6.2, 9.0])

# ------------------------------------------------------------------ 4
pb()
H("4. Resultados de la evaluación", 1)
P("A continuación se muestran los resultados de las pruebas realizadas al conjunto de métricas seleccionadas. Cada valor "
  "proviene del arnés de medición (scripts m_func.py, m_fiab.py, m_resto.py) y está respaldado por los registros crudos "
  "del Anexo B y del archivo Evidencias_Beancount.zip.")
H("4.1 Componentes evaluados", 2)
P("Componentes analizados y medidos:")
for k, (n, d) in COMPONENTES.items():
    B(f"**Componente {k[-1]} – {k}: {n}.** {d}")
H("4.2 Resultados por métrica y componente", 2)


def valores(vals):
    return " ".join(f"{k}={v}" for k, v in vals.items())


rows, fills = [], []
for m in METRICAS:
    rm = RM[m["n"]]
    for comp in ("C1", "C2", "C3", "Total"):
        if comp not in rm["filas"]:
            continue
        f = rm["filas"][comp]
        if comp == "Total":
            interp = f"{'PASA' if rm['pasa'] else 'NO PASA'} (umbral X {m['op'].replace('<=', '≤').replace('>=', '≥')} {m['umbral']}; S={f4(rm['S'])})"
        else:
            interp = m["interp"]
        primera = comp == [c for c in ("C1", "C2", "C3", "Total") if c in rm["filas"]][0]
        rows.append([m["sub"] if primera else "", f"{m['n']} {m['nombre']}" if primera else "",
                     comp, valores(f["vals"]), f4(f["X"]), interp])
        fills.append({2: COL["sub"], 4: COL["verde"] if rm["pasa"] else COL["rojo"], 5: COL["verde"] if rm["pasa"] else COL["rojo"]} if comp == "Total" else None)
T(["Sub-característica", "Métrica aplicada", "Componente medido", "Valores medidos", "Resultado obtenido", "Interpretación del valor medido"],
  rows, [2.4, 3.6, 1.6, 3.6, 1.6, 3.8], fills=fills, size=7.5)
P("En las métricas 001–003 la norma define X = A/T (casos por hora de operación de la campaña). T es la duración real de la "
  "campaña automatizada (segundos convertidos a horas), por lo que cualquier A > 0 produce X grande; para el puntaje se usa "
  "S = 1 − A/N.", size=8.5, italic=True)

H("4.3 Resumen por sub-característica y puntaje global", 2)
rows, fills = [], []
for s, v in SUBS.items():
    if v["considerar"] != "S":
        continue
    rows.append([s, v["tipo"], pct(v["peso"]), f4(v["puntaje"]), f"{v['metricas_pasan']} de {len(v['metricas'])}",
                 {"verde": "VERDE – pasa", "rojo": "ROJO – no pasa", "amarillo": "AMARILLO – menor interés"}[v["color"]]])
    fills.append({5: COL[v["color"]], 3: COL[v["color"]]})
T(["Sub-característica", "Tipo", "Peso", "Puntaje (Σ S·peso / peso)", "Métricas que pasan su umbral", "Estado"], rows,
  [4.0, 2.2, 1.8, 3.0, 2.8, 2.8], fills=fills)
g = R["global_"]
P(f"**Puntaje global ponderado = Σ (S × peso absoluto) = {pct(g)} → {R['clasificacion']}** "
  "(escala: MUY BUENO ≥ 95 %, ACEPTABLE ≥ 80 % y < 95 %, NO ACEPTABLE < 80 %).", size=11)

H("4.4 Hallazgos principales", 2)
for h in json.load(open(f"{OUT}/hallazgos.json", encoding="utf-8")):
    B(h)

# ------------------------------------------------------------------ 5
H("5. Conclusiones", 1)
for c in json.load(open(f"{OUT}/conclusiones.json", encoding="utf-8")):
    B(c)
H("6. Recomendaciones", 1)
for c in json.load(open(f"{OUT}/recomendaciones.json", encoding="utf-8")):
    B(c)

# ------------------------------------------------------------------ Anexo A
pb()
H("ANEXO A – MATRIZ DE BROUSSEAU", 1)
P("A.1 Paso 1 – Atributos incluidos y excluidos (hoja '1 Attribute In or Out')", bold=True)
T(["Atributo", "Vista", "Razonamiento para Beancount", "Include"], [[a, v, rz, inc] for a, v, rz, inc in CLARRUS_ATRIBUTOS],
  [2.4, 1.6, 11.2, 1.4], fills=[None if inc == "Yes" else COL["gris"] for *_, inc in CLARRUS_ATRIBUTOS], size=7.5)
P("A.2 Paso 2 – Comparación por pares (hoja '2 Attribute Prioritization'). '<' = gana el atributo de la fila; '^' = gana el de la "
  "columna. El score cuenta las victorias. Excepción documentada a la transitividad: " +
  "; ".join(f"{a} > {b}: {t}" for (a, b), t in EXCEPCIONES.items()), bold=False, size=9)
inc = [a for a, *_ in CLARRUS_ATRIBUTOS if a in INCLUIDOS]
rows = []
for i, a in enumerate(inc):
    row = [a, sc[a]]
    for j, b in enumerate(inc):
        row.append("" if j <= i else ("<" if gana(a, b) else "^"))
    rows.append(row)
ab = {"installability": "inst", "integrity": "integ", "interoperability": "interop", "performance": "perf", "reliability": "relia",
      "robustness": "robust", "usability": "usab", "modifiability": "modif", "portability": "port", "verifiability": "verif"}
T(["Atributo", "Score"] + [ab[a] for a in inc], rows, [2.6, 1.1] + [1.29] * len(inc), size=7.5,
  fills=[{1: COL["sub"]} for _ in inc])
P("A.3 Mapeo atributo → sub-característica ISO 9126-1 y cálculo de pesos (hoja '5 Mapeo ISO 9126')", bold=True)
rows = []
for a in sorted(INCLUIDOS, key=lambda a: -sc[a]):
    for s, fr in MAPEO[a]:
        rows.append([a, sc[a], f"{sc[a]}/45 = {pct(R['pesos_atributo'][a])}", s, f"{float(fr):.0%}", pct(R["pesos_atributo"][a] * float(fr))])
rows.append(["Total", "45", "100.00 %", "", "", pct(sum(R["pesos_atributo"][a] for a in INCLUIDOS))])
T(["Atributo", "Score", "Peso atributo", "Sub-característica", "Fracción", "Peso sub-caract."], rows, [2.6, 1.2, 3.0, 4.6, 1.6, 2.6])
P("A.4 Peso absoluto por métrica = peso de la sub-característica / n.º de métricas", bold=True)
rows = [[m["n"], m["sub"], pct(SUBS[m["sub"]]["peso"]), len(SUBS[m["sub"]]["metricas"]), pct(RM[m["n"]]["peso_abs"])] for m in METRICAS]
rows.append(["Σ", "", "", "", pct(sum(RM[n]["peso_abs"] for n in RM))])
T(["Métrica", "Sub-característica", "Peso sub-caract.", "N.º métricas", "Peso absoluto"], rows, [1.6, 5.0, 3.2, 2.4, 3.2], size=8)

# ------------------------------------------------------------------ Anexo B
pb()
H("ANEXO B – EVIDENCIAS DE RESULTADOS DE EVALUACIÓN", 1)
P("Todas las evidencias están en Evidencias_Beancount.zip (carpeta eval/): scripts/, ledgers/ (libros de prueba y oráculos), "
  "work/ (entradas generadas por caso), logs/raw/<métrica>/<caso>.txt (comando, código de salida, duración, stdout y stderr de "
  "cada ejecución) y out/<métrica>.json (lista de casos con esperado, observado y conteo). El archivo LEEME_reproducibilidad.md "
  "indica cómo reproducir cada métrica.")
P("B.1 Protocolo registrado antes de medir", bold=True)
P("logs/00_protocolo_registrado.txt (sello 2026-10-29T03:09:44-05:00) contiene los 25 umbrales y sus justificaciones; "
  "su hash SHA-256 y el del catálogo quedan registrados en el mismo archivo. Los umbrales no se modificaron después de medir.", size=9)
P("B.2 Trazabilidad métrica → comando → salida", bold=True)
TRAZ = {"001": "m_func.m001", "002": "m_func.m002", "003": "m_func.m003", "004": "m_func.m004", "005": "m_func.m005",
        "006": "m_func.m006_007 (+ m006_obsoleta_ns)", "007": "m_func.m006_007 (+ m006_obsoleta_ns)", "008": "m_fiab.m008",
        "009": "pytest + m_fiab.m009_010", "010": "pytest + m_fiab.m009_010", "011": "m_fiab.m011", "012": "m_fiab.m012", "013": "m_fiab.m013",
        "014": "m_resto.m014", "015": "m_resto.m015", "016": "m_resto.m016", "017": "m_resto.m017", "018": "m_resto.m018",
        "019": "m_resto.m019", "020": "m_resto.m020", "021": "m_resto.m021", "022": "m_resto.m022", "023": "m_resto.m023",
        "024": "m_resto.m024", "025": "m_resto.m025"}
CMD = {"001": "bean-query, bean-format, bean-check, loader.load_file", "002": "loader.load_file vs oráculo; bean-query -f csv",
       "003": "loader.load_file; bean-query (texto, csv, -m)", "004": "printer, Beancount 2.3.6, bean-query -f csv/beancount, bean-check --json, bean-format",
       "005": "loader.load_file y bean-check -C (15 tipos)", "006": "bean-check/query/doctor/format; SIGKILL; caché; runuser nobody",
       "007": "ídem 006", "008": "bean-example ×20 + 3 sintéticos; parse/load/check/query/format", "009": "python -m pytest beancount (árbol del tag)",
       "010": "ídem 009", "011": "bean-check/query/format/doctor con 28 entradas defectuosas", "012": "bean-check, loader, bean-query con 10 errores insertados",
       "013": "21 operaciones incorrectas en la CLI", "014": "--help, --version, opción inválida, formato de mensajes",
       "015": "mensajes de 005 y 013", "016": "-o sobre libros, Ctrl-C, caché obsoleta", "017": "parse_file, bean-check -C, bean-query ×10",
       "018": "ídem 017 sobre 100 000 tx ×5", "019": "option, plugin, flags de la CLI", "020": "bean-doctor, bean-check, plugins, pytest",
       "021": "mutaciones + pytest; bean-check tras corregir", "022": "bean-doctor region/context, CLOSE ON, pytest -k/--lf/-x",
       "023": "pip/uv en venvs 3.11–3.13", "024": "Beancount 2.3.6 vs 3.2.3 (8 libros)", "025": "herramientas, API y 28 plugins de 2.3.6"}
rows = []
for m in METRICAS:
    rm = RM[m["n"]]
    rows.append([m["n"], TRAZ[m["n"]], CMD[m["n"]], f"logs/raw/{m['n'] if m['n'] not in ('006', '007', '009', '010') else {'006': '006_007', '007': '006_007', '009': '009_010', '010': '009_010'}[m['n']]}/",
                 f"X={f4(rm['X'])} ({'pasa' if rm['pasa'] else 'no pasa'})"])
T(["Métrica", "Script.función", "Comandos / API ejercitados", "Evidencia cruda", "Salida"], rows, [1.3, 3.6, 6.0, 3.2, 2.6], size=7.5)
P("B.3 Extractos de evidencia de los hallazgos", bold=True)
for titulo, contenido in json.load(open(f"{OUT}/extractos.json", encoding="utf-8")):
    P(titulo, bold=True, size=8.5, space_after=1)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.left_indent = Cm(0.4)
    for k, line in enumerate(contenido.splitlines()):
        r = p.add_run(line)
        r.font.name = "Courier New"; r.font.size = Pt(7)
        if k < len(contenido.splitlines()) - 1:
            r.add_break()

doc.save(DST)
print("ok", DST)
