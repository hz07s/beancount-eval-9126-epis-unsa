# -*- coding: utf-8 -*-
"""Mediciones de Fiabilidad: 008 (densidad de fallas), 009-010 (suite oficial),
011 (prevención de caídas), 012 (prevención de fallas), 013 (prevención de operación incorrecta)."""
import json
import os
import re
import shutil
import xml.etree.ElementTree as ET

from comun import *

CHK, QRY, FMT, DOC, EXA = (BC3 + x for x in ("/bean-check", "/bean-query", "/bean-format", "/bean-doctor", "/bean-example"))
CAB = 'option "operating_currency" "USD"\n'
Q_SALDOS = "SELECT account, sum(position) GROUP BY account ORDER BY account"


# ------------------------------------------------------------------ 008
def m008():
    M = "008"
    reg = Registro(M)
    d = wdir(M)
    libros = []
    for s in range(1, 21):
        out = f"{d}/ejemplo_s{s:02d}.beancount"
        r = run([EXA, "--seed", str(s), "--date-begin", "2022-01-01", "--date-end", "2026-01-01", "-o", out], M, f"gen_s{s:02d}")
        libros.append((f"s{s:02d}", out))
    for s in (101, 202, 303):
        libros.append((f"sint{s}", f"{LEDG}/sint_{s}.beancount"))
    for nom, L in libros:
        r = py("import sys\nfrom beancount.parser import parser\ne, err, o = parser.parse_file(sys.argv[1])\n"
               "print(len(e), len(err)); [print(x.message) for x in err[:5]]", M, f"C1_{nom}_parse", args=[L])
        n_err = int(r.out.split()[1]) if r.rc == 0 and r.out.split() else -1
        reg.add(f"C1_{nom}_parse", "C1", f"parse_file de libro válido {nom}", "0 errores, sin traza",
                f"rc={r.rc} errores={n_err}", r.caida or n_err != 0, r.log)
        j, r = saldos(L, M, f"C2_{nom}_load")
        reg.add(f"C2_{nom}_load", "C2", f"load_file (booking, interpolación, validación) de {nom}", "0 errores",
                f"errores={j and j['errores'][:2]}", (j is None) or bool(j["errores"]) or r.caida, r.log)
        r = run([CHK, "-C", L], M, f"C3_{nom}_check")
        reg.add(f"C3_{nom}_check", "C3", f"bean-check {nom}", "rc=0", f"rc={r.rc} {r.err.strip()[:100]}", r.rc != 0 or r.caida, r.log)
        r = run([QRY, "-q", L, Q_SALDOS], M, f"C3_{nom}_query")
        reg.add(f"C3_{nom}_query", "C3", f"bean-query saldos de {nom}", "rc=0 y filas", f"rc={r.rc} lineas={len(r.out.splitlines())}",
                r.rc != 0 or r.caida or len(r.out.splitlines()) < 3, r.log)
        F = f"{d}/{nom}_fmt.beancount"
        r = run([FMT, "-o", F, L], M, f"C3_{nom}_format")
        r2 = run([CHK, "-C", F], M, f"C3_{nom}_format_check")
        reg.add(f"C3_{nom}_format", "C3", f"bean-format de {nom} y validación del resultado", "rc=0 y 0 errores",
                f"rc={r.rc}/{r2.rc}", r.rc != 0 or r2.rc != 0 or r.caida, r.log + " ; " + r2.log)
    reg.guardar(nota="cuenta_A = falla detectada (A1); casos = A2")


# ------------------------------------------------------------------ 009 / 010
def m009_010():
    M = "009_010"
    reg = Registro(M)
    comp_de = lambda path: ("C1" if re.search(r"(^|[./])(parser|loader_test|utils)[./]", path) else
                            "C2" if re.search(r"(^|[./])(core|ops|plugins)[./]", path) else "C3")
    for fuente in ("fuente", "instalado"):
        x = f"{RAW}/{M}/pytest_{fuente}.xml"
        res = {"C1": dict(def_=0, ejec=0, pas=0, skip=0, xfail=0, fail=0),
               "C2": dict(def_=0, ejec=0, pas=0, skip=0, xfail=0, fail=0),
               "C3": dict(def_=0, ejec=0, pas=0, skip=0, xfail=0, fail=0)}
        fallidos = []
        for tc in ET.parse(x).getroot().iter("testcase"):
            c = comp_de(tc.get("classname", "") + "/" + tc.get("file", ""))
            r = res[c]
            r["def_"] += 1
            sk = tc.find("skipped")
            if sk is not None and "xfail" in (sk.get("type", "") + sk.get("message", "")).lower():
                r["ejec"] += 1; r["xfail"] += 1
            elif sk is not None:
                r["skip"] += 1
            elif tc.find("failure") is not None or tc.find("error") is not None:
                r["ejec"] += 1; r["fail"] += 1
                fallidos.append(tc.get("classname") + "::" + tc.get("name"))
            else:
                r["ejec"] += 1; r["pas"] += 1
        reg.extra[fuente] = {"por_componente": res, "fallidos": fallidos}
    reg.guardar(nota="Se usa la ejecución 'fuente' (árbol del tag 3.2.3 con la extensión C del wheel) como oficial; "
                     "'instalado' se informa como evidencia complementaria.")


# ------------------------------------------------------------------ 011
def m011():
    M = "011"
    reg = Registro(M)
    d = wdir(M)
    ej = open(EJEMPLO, encoding="utf-8").read()
    W = lambda n, t, enc="utf-8": escribir(f"{d}/{n}", t, enc)

    def wb(n, data):
        p = f"{d}/{n}"
        with open(p, "wb") as f:
            f.write(data)
        return p

    cut = ej.index('* "', len(ej) // 2) + 5
    entradas = [
        ("C1", "truncado", "archivo truncado a mitad de una transacción", [CHK, W("truncado.beancount", ej[:cut])]),
        ("C1", "binario", "64 KiB de bytes aleatorios", [CHK, wb("binario.beancount", os.urandom(65536))]),
        ("C1", "utf8_invalido", "bytes UTF-8 inválidos en la narración", [CHK, wb("utf8.beancount", (CAB + '2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n2020-01-02 * "caf').encode() + b"\xc3\x28\xff" + b'"\n  Assets:A 1 USD\n  Equity:E\n')]),
        ("C1", "latin1", "archivo codificado en Latin-1 con acentos", [CHK, W("latin1.beancount", CAB + '2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n2020-01-02 * "Panadería Ñandú"\n  Assets:A 1 USD\n  Equity:E\n', "latin-1")]),
        ("C1", "nul", "bytes NUL dentro del archivo", [CHK, wb("nul.beancount", (CAB + "2020-01-01 open Assets:A USD\n").encode() + b"\x00\x00\x00" + b"2020-01-02 open Equity:E USD\n")]),
        ("C1", "linea_10MB", "una línea de comentario de 10 MB", [CHK, W("linea.beancount", CAB + ";" + "x" * 10_000_000 + "\n2020-01-01 open Assets:A USD\n")]),
        ("C1", "include_ciclico", "include cíclico (a incluye b, b incluye a)", [CHK, W("a.beancount", CAB + 'include "b.beancount"\n2020-01-01 open Assets:A USD\n')]),
        ("C1", "include_inexistente", "include de un archivo que no existe", [CHK, W("incnoex.beancount", CAB + 'include "no_existe.beancount"\n')]),
        ("C1", "cadena_sin_cerrar", "cadena entre comillas sin cerrar", [CHK, W("cadena.beancount", CAB + '2020-01-01 open Assets:A USD\n2020-01-02 * "sin cierre\n  Assets:A 1 USD\n')]),
        ("C1", "fecha_0000", "fecha 0000-01-01", [CHK, W("f0000.beancount", CAB + '0000-01-01 open Assets:A USD\n')]),
        ("C1", "numero_500_digitos", "monto de 500 dígitos", [CHK, W("n500.beancount", CAB + '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A ' + "9" * 500 + ' USD\n  Equity:E\n')]),
        ("C1", "vacio", "archivo vacío", [CHK, W("vacio.beancount", "")]),
        ("C1", "solo_bom", "archivo con solo BOM UTF-8", [CHK, wb("bom.beancount", b"\xef\xbb\xbf")]),
        ("C1", "division_por_cero", "expresión aritmética 1/0 en un monto", [CHK, W("div0.beancount", CAB + '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A 1/0 USD\n  Equity:E\n')]),
        ("C2", "plugin_inexistente", "plugin con módulo inexistente", [CHK, W("plugnoex.beancount", CAB + 'plugin "no.existe.plugin"\n2020-01-01 open Assets:A USD\n')]),
        ("C2", "plugin_excepcion", "plugin que lanza una excepción", [CHK, W("plugexc.beancount", CAB + 'plugin "plug_roto"\n2020-01-01 open Assets:A USD\n')]),
        ("C2", "booking_invalido", "método de booking inexistente en open", [CHK, W("bookinv.beancount", CAB + '2020-01-01 open Assets:A ACME "INVENTADO"\n')]),
        ("C2", "costo_cero_negativo", "lote con costo negativo {-5 USD}", [CHK, W("costneg.beancount", CAB + '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A 1 ACME {-5 USD}\n  Equity:E\n')]),
        ("C2", "10000_postings", "una transacción con 10 000 postings", [CHK, W("muchos.beancount", CAB + '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n' + "  Assets:A 1 USD\n" * 10000 + "  Equity:E\n")]),
        ("C2", "precio_cero", "directiva price con valor 0", [CHK, W("precio0.beancount", CAB + '2020-01-01 price ACME 0 USD\n')]),
        ("C3", "query_sintaxis", "consulta BQL con error de sintaxis", [QRY, "-q", EJEMPLO, "SELEC account FROM"]),
        ("C3", "query_columna", "consulta con columna inexistente", [QRY, "-q", EJEMPLO, "SELECT columna_que_no_existe"]),
        ("C3", "query_beancount_select", "salida -f beancount con una consulta SELECT", [QRY, "-q", "-f", "beancount", EJEMPLO, "SELECT date, narration"]),
        ("C3", "query_libro_truncado", "bean-query sobre el libro truncado", [QRY, "-q", f"{d}/truncado.beancount", Q_SALDOS]),
        ("C3", "format_binario", "bean-format sobre un archivo binario", [FMT, f"{d}/binario.beancount"]),
        ("C3", "doctor_context_fuera", "bean-doctor context con línea fuera del archivo", [DOC, "context", EJEMPLO, "999999"]),
        ("C3", "doctor_region_invalida", "bean-doctor region con región mal formada", [DOC, "region", EJEMPLO, "abc:xyz"]),
        ("C3", "query_tipo_incompatible", "consulta que suma texto (tipo incompatible)", [QRY, "-q", EJEMPLO, "SELECT sum(narration)"]),
    ]
    W("b.beancount", 'include "a.beancount"\n')
    W("plug_roto.py", "__plugins__ = ['roto']\ndef roto(entries, options_map):\n    raise RuntimeError('fallo deliberado')\n")
    for comp, cid, desc, cmd in entradas:
        r = run(cmd, M, f"{comp}_{cid}", cwd=d, timeout=60, env={**os.environ, "PYTHONPATH": d})
        reg.add(f"{comp}_{cid}", comp, f"Entrada defectuosa: {desc}", "sin caída (sin traza, sin señal, < 60 s)",
                f"rc={r.rc} traza={r.traceback} t={r.dt:.1f}s {r.err.strip().splitlines()[-1][:110] if r.err.strip() else ''}",
                r.caida, r.log)
    reg.guardar(nota="cuenta_A = caída")


# ------------------------------------------------------------------ 012
def m012():
    M = "012"
    reg = Registro(M)
    d = wdir(M)
    ej = open(EJEMPLO, encoding="utf-8").read()
    ref, _ = saldos(EJEMPLO, M, "ref")
    mid = ej.index("\n\n", len(ej) // 2) + 2
    tipos = [
        ("C1", "linea_basura", "línea de sintaxis inválida", "@@@ esto no es beancount @@@\n\n"),
        ("C1", "fecha_invalida", "fecha inexistente", '2023-02-30 * "x"\n  Assets:US:BofA:Checking  1 USD\n  Equity:Opening-Balances\n\n'),
        ("C1", "cadena_sin_cerrar", "comillas sin cerrar en la narración", '2023-03-01 * "sin cierre\n  Assets:US:BofA:Checking  1 USD\n  Equity:Opening-Balances\n\n'),
        ("C1", "include_inexistente", "include de archivo inexistente", 'include "falta.beancount"\n\n'),
        ("C2", "desbalanceada", "transacción desbalanceada", '2023-03-01 * "x"\n  Assets:US:BofA:Checking  1 USD\n  Equity:Opening-Balances  -2 USD\n\n'),
        ("C2", "cuenta_no_abierta", "cuenta no abierta", '2023-03-01 * "x"\n  Assets:Inexistente  1 USD\n  Equity:Opening-Balances\n\n'),
        ("C2", "balance_falso", "aserción balance falsa", '2023-03-01 balance Assets:US:BofA:Checking  123456789.00 USD\n\n'),
        ("C2", "moneda_no_permitida", "moneda no permitida", '2023-03-01 * "x"\n  Assets:US:BofA:Checking  1 EUR\n  Equity:Opening-Balances\n\n'),
        ("C2", "plugin_falla", "plugin que lanza excepción", 'plugin "plug_roto"\n\n'),
        ("C2", "doble_open", "open duplicado", '2023-03-01 open Assets:US:BofA:Checking USD\n\n'),
    ]
    escribir(f"{d}/plug_roto.py", "__plugins__ = ['roto']\ndef roto(entries, options_map):\n    raise RuntimeError('fallo deliberado')\n")
    for comp, cid, desc, txt in tipos:
        L = escribir(f"{d}/{cid}.beancount", ej[:mid] + txt + ej[mid:])
        env = {**os.environ, "PYTHONPATH": d}
        r1 = run([CHK, "-C", L], M, f"{cid}_check", cwd=d, env=env)
        j = py(f"import sys; sys.path.insert(0, {d!r})\n" + API_SALDOS, M, f"{cid}_load", args=[L], cwd=d)
        try:
            jj = json.loads(j.out.strip().splitlines()[-1])
        except Exception:
            jj = None
        r3 = run([QRY, "-q", L, Q_SALDOS], M, f"{cid}_query", cwd=d, env=env)
        frac = (jj["n_tx"] / ref["n_tx"]) if jj else 0
        evitada = (r1.rc == 1 and not r1.caida and jj is not None and frac >= 0.95 and r3.rc == 0 and len(r3.out.splitlines()) > 10)
        reg.add(f"{comp}_{cid}", comp, f"Error '{desc}' insertado a mitad del libro de ejemplo",
                "error reportado y el resto del libro sigue utilizable (>= 95 % de transacciones, bean-query responde)",
                f"check rc={r1.rc}; tx cargadas {jj and jj['n_tx']}/{ref['n_tx']} ({frac:.1%}); query rc={r3.rc}",
                evitada, r1.log + " ; " + j.log + " ; " + r3.log)
    # C3: comportamiento de las herramientas ante un libro con errores
    L = f"{d}/desbalanceada.beancount"
    r = run([QRY, L, Q_SALDOS], M, "C3_query_sin_q")
    reg.add("C3_query_con_errores", "C3", "bean-query (sin -q) sobre libro con errores: informa y aun así responde",
            "errores en stderr + resultado", f"rc={r.rc} errores_informados={'balance' in r.err.lower()} filas={len(r.out.splitlines())}",
            r.rc == 0 and len(r.out.splitlines()) > 10 and not r.caida, r.log)
    r = run([CHK, "--json", L], M, "C3_json_con_errores")
    try:
        ok = len(json.loads(r.out)["errors"]) >= 1
    except Exception:
        ok = False
    reg.add("C3_json_con_errores", "C3", "bean-check --json sobre libro con errores entrega JSON válido", "JSON con errores",
            f"rc={r.rc} json_valido={ok}", ok and not r.caida, r.log)
    r = run([FMT, f"{d}/linea_basura.beancount"], M, "C3_format_con_basura")
    reg.add("C3_format_con_errores", "C3", "bean-format sobre libro con una línea inválida formatea el resto",
            "rc=0 y salida completa", f"rc={r.rc} lineas={len(r.out.splitlines())}", r.rc == 0 and len(r.out.splitlines()) > 1000 and not r.caida, r.log)
    reg.guardar(nota="cuenta_A = falla crítica/seria evitada")


# ------------------------------------------------------------------ 013
def m013():
    M = "013"
    reg = Registro(M)
    d = wdir(M)
    os.chmod(d, 0o755)
    sinperm = escribir(f"{d}/sin_permiso.beancount", CAB)
    os.chmod(sinperm, 0o600)
    nob = ["runuser", "-u", "nobody", "--"]
    casos = [
        ("C3", "check_inexistente", "bean-check de archivo inexistente", [CHK, f"{d}/no_existe.beancount"]),
        ("C3", "check_directorio", "bean-check de un directorio", [CHK, d]),
        ("C3", "check_sin_permiso", "bean-check de archivo sin permiso de lectura (usuario nobody)", nob + [CHK, sinperm]),
        ("C3", "check_sin_argumentos", "bean-check sin argumentos", [CHK]),
        ("C3", "check_opcion_invalida", "bean-check con opción inexistente", [CHK, "--opcion-falsa", EJEMPLO]),
        ("C3", "query_formato_invalido", "bean-query -f xml (formato no soportado)", [QRY, "-f", "xml", EJEMPLO, "SELECT 1"]),
        ("C3", "query_inexistente", "bean-query de archivo inexistente", [QRY, f"{d}/no_existe.beancount", "SELECT 1"]),
        ("C3", "query_salida_dir_inexistente", "bean-query -o a un directorio inexistente", [QRY, "-q", "-o", "/no/existe/x.csv", EJEMPLO, "SELECT 1"]),
        ("C3", "format_inexistente", "bean-format de archivo inexistente", [FMT, f"{d}/no_existe.beancount"]),
        ("C3", "format_directorio", "bean-format de un directorio", [FMT, d]),
        ("C3", "doctor_comando_invalido", "bean-doctor con subcomando inexistente", [DOC, "subcomando-falso", EJEMPLO]),
        ("C3", "doctor_context_texto", "bean-doctor context con ubicación no numérica", [DOC, "context", EJEMPLO, "abc"]),
        ("C3", "example_fecha_invalida", "bean-example con fecha inválida", [EXA, "--date-begin", "2023-13-45"]),
        ("C3", "example_fin_antes_inicio", "bean-example con fecha fin anterior a inicio", [EXA, "--date-begin", "2025-01-01", "--date-end", "2020-01-01", "-o", f"{d}/x.beancount"]),
        ("C1", "option_desconocida", "option con nombre desconocido", [CHK, escribir(f"{d}/optdesc.beancount", 'option "monedaoperativa" "USD"\n')]),
        ("C1", "option_valor_invalido", "option con valor inválido (booking_method)", [CHK, escribir(f"{d}/optval.beancount", 'option "booking_method" "MAGICO"\n')]),
        ("C1", "include_glob_vacio", "include con patrón que no coincide con nada", [CHK, escribir(f"{d}/glob.beancount", 'include "nada/*.beancount"\n')]),
        ("C1", "directiva_desconocida", "directiva inexistente 'abrir'", [CHK, escribir(f"{d}/dirdesc.beancount", '2020-01-01 abrir Assets:A USD\n')]),
        ("C2", "plugin_inexistente", "plugin inexistente", [CHK, escribir(f"{d}/plug.beancount", 'plugin "beancount.plugins.no_existe"\n')]),
        ("C2", "plugin_config_invalida", "configuración inválida para el plugin check_closing/ coherent_cost", [CHK, escribir(f"{d}/plugcfg.beancount", 'plugin "beancount.plugins.check_average_cost" "esto no es un número"\n2020-01-01 open Assets:A\n')]),
        ("C2", "booking_open_invalido", "open con método de booking inválido", [CHK, escribir(f"{d}/bookinv.beancount", '2020-01-01 open Assets:A ACME "MAGICO"\n')]),
    ]
    for comp, cid, desc, cmd in casos:
        r = run(cmd, M, f"{comp}_{cid}", cwd=d, timeout=60)
        msg = (r.err.strip() or r.out.strip()).splitlines()
        prev = (r.rc not in (0, None)) and not r.caida and bool(msg)
        reg.add(f"{comp}_{cid}", comp, f"Operación incorrecta: {desc}", "rc != 0, mensaje claro, sin traza",
                f"rc={r.rc} traza={r.traceback} msg={msg[-1][:110] if msg else ''}", prev, r.log)
    reg.guardar(nota="cuenta_A = operación incorrecta prevenida")


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        print("====", f, flush=True)
        globals()[f]()
