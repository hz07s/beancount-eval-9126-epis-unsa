# -*- coding: utf-8 -*-
"""Mediciones de Usabilidad (014-016), Eficiencia (017-018), Mantenibilidad (019-022)
y Portabilidad (023-025)."""
import json
import os
import re
import shutil
import signal
import statistics
import subprocess
import time

from comun import *

CHK, QRY, FMT, DOC, EXA = (BC3 + x for x in ("/bean-check", "/bean-query", "/bean-format", "/bean-doctor", "/bean-example"))
CAB = 'option "operating_currency" "USD"\n'
Q_SALDOS = "SELECT account, sum(position) GROUP BY account ORDER BY account"
SRC = "/home/claude/run-src"


def _sin_bytecode():
    """Evita .pyc obsoletos: una mutación de igual tamaño escrita en el mismo segundo
    sería ignorada por el intérprete. Se borran los __pycache__ y no se generan nuevos."""
    for root, dirs, files in os.walk(SRC):
        for x in dirs:
            if x == "__pycache__":
                shutil.rmtree(os.path.join(root, x), ignore_errors=True)
    return {**os.environ, "PYTHONPATH": SRC, "PYTHONDONTWRITEBYTECODE": "1"}


def load_out(m):
    return json.load(open(f"{OUT}/{m}.json", encoding="utf-8"))


# ------------------------------------------------------------------ 014
def m014():
    M = "014"
    reg = Registro(M)
    tools = {"bean-check": CHK, "bean-doctor": DOC, "bean-format": FMT, "bean-example": EXA, "bean-query": QRY}
    for n, t in tools.items():
        r = run([t, "--help"], M, f"{n}_help")
        reg.add(f"C3_{n}_help", "C3", f"{n} --help muestra el uso y termina con 0", "rc=0, 'Usage:' en stdout",
                f"rc={r.rc} usage={'Usage:' in r.out}", not (r.rc == 0 and "Usage:" in r.out), r.log)
        r = run([t, "--version"], M, f"{n}_version")
        reg.add(f"C3_{n}_version", "C3", f"{n} --version informa la versión", "rc=0 y '3.2.3'",
                f"rc={r.rc} {r.out.strip()[:60]}", not (r.rc == 0 and "3.2.3" in r.out), r.log)
        r = run([t, "--opcion-falsa"], M, f"{n}_opcion_invalida")
        reg.add(f"C3_{n}_opcion_invalida", "C3", f"{n} ante opción inválida: rc=2 y 'No such option' en stderr",
                "rc=2, stderr", f"rc={r.rc} {r.err.strip().splitlines()[-1][:70] if r.err.strip() else ''}",
                not (r.rc == 2 and "No such option" in r.err), r.log)
    # Formato 'archivo:línea: mensaje' de los errores del libro (mensajes de bean-check en 005)
    msgs = json.load(open(f"{WORK}/005/mensajes_bean_check.json", encoding="utf-8"))
    for k, m in msgs.items():
        first = m.strip().splitlines()[0] if m.strip() else ""
        ok = re.match(r"^\S+\.beancount:[1-9]\d*: \S", first) is not None
        comp = "C1" if k in ("cuenta_raiz_invalida", "fecha_invalida", "moneda_con_sintaxis_invalida") else "C2"
        reg.add(f"{comp}_formato_msg_{k}", comp, f"Mensaje de error '{k}' sigue el patrón archivo:línea: descripción",
                "archivo.beancount:N: texto", first[:120], not ok, f"logs/raw/005/CLI_{k}.txt")
    for k, f, kind in (("include_inexistente", f"{WORK}/011/incnoex.beancount", "C1"), ("plugin_inexistente", f"{WORK}/011/plugnoex.beancount", "C2")):
        r = run([CHK, f], M, f"formato_msg_{k}", cwd=os.path.dirname(f))
        first = r.err.strip().splitlines()[0] if r.err.strip() else ""
        ok = re.match(r"^\S+\.beancount:[1-9]\d*: \S", first) is not None
        reg.add(f"{kind}_formato_msg_{k}", kind, f"Mensaje de error '{k}' sigue el patrón archivo:línea", "archivo.beancount:N: texto",
                first[:120], not ok, r.log)
    # Separación stdout/stderr y códigos de salida
    E = f"{WORK}/005/desbalanceada.beancount"
    r = run([CHK, E], M, "check_stderr")
    reg.add("C3_check_errores_en_stderr", "C3", "bean-check escribe errores en stderr y nada en stdout", "stdout vacío, rc=1",
            f"stdout={len(r.out)} bytes rc={r.rc}", not (r.out.strip() == "" and r.err.strip() and r.rc == 1), r.log)
    r = run([QRY, E, Q_SALDOS], M, "query_errores_rc")
    reg.add("C3_query_rc_con_errores", "C3", "bean-query sobre libro con errores: errores en stderr y código coherente con bean-check (≠0)",
            "rc≠0 como bean-check", f"rc={r.rc} errores_en_stderr={'balance' in r.err}", r.rc == 0, r.log)
    r = run([QRY, f"{WORK}/013/no_existe.beancount", "SELECT 1"], M, "query_inexistente_rc")
    reg.add("C3_query_rc_archivo_inexistente", "C3", "bean-query con archivo inexistente termina con código ≠0 como bean-check",
            "rc≠0", f"rc={r.rc}", r.rc == 0, r.log)
    r = run([FMT, f"{WORK}/011/binario.beancount"], M, "format_error")
    reg.add("C3_format_error_controlado", "C3", "bean-format informa errores con mensaje 'Error:' como las demás herramientas (sin traza)",
            "mensaje sin traza", f"traza={r.traceback}", r.traceback, r.log)
    r = run([QRY, "-q", EJEMPLO, "SELECT account, sum(position) GROUP BY account LIMIT 3"], M, "query_cabecera_texto")
    hdr = r.out.splitlines()[0] if r.out else ""
    reg.add("C3_query_cabecera_texto", "C3", "Cabeceras de la tabla de texto de bean-query legibles (nombre de columna completo)",
            "'sum(position)' completo", hdr.strip(), "sum(position)" not in hdr, r.log)
    r = run([QRY, "-q", "-f", "csv", EJEMPLO, "SELECT account, sum(position) GROUP BY account LIMIT 3"], M, "query_cabecera_csv")
    hdr = r.out.splitlines()[0] if r.out else ""
    reg.add("C3_query_cabecera_csv", "C3", "Cabecera CSV de bean-query con nombres de columna", "account,sum(position)",
            hdr.strip(), hdr.strip() != "account,sum(position)", r.log)
    reg.guardar(nota="cuenta_A = elemento con inconsistencia inaceptable")


# ------------------------------------------------------------------ 015
CAUSAS_005 = {
    "desbalanceada": ["does not balance"], "cuenta_no_abierta": ["unknown account"], "cuenta_cerrada": ["inactive account"],
    "moneda_no_permitida": ["Invalid currency"], "asercion_falsa": ["Balance failed", "expected"],
    "reducir_lote_inexistente": ["No position matches"], "vender_mas_de_lo_tenido": ["Not enough lots"],
    "doble_open": ["Duplicate open"], "close_sin_open": ["Unopened account"], "dos_montos_omitidos": ["auto-posting"],
    "pad_sin_uso": ["Unused Pad"], "documento_inexistente": ["does not exist"], "cuenta_raiz_invalida": ["Invalid account name"],
    "fecha_invalida": ["day is out of range"], "moneda_con_sintaxis_invalida": ["Invalid token"]}
# (caso 013, elementos de ubicación aceptados, palabras de causa)
CAUSAS_013 = {
    "C3_check_inexistente": (["no_existe.beancount"], ["does not exist", "No such file"]),
    "C3_check_directorio": (["013"], ["directory"]),
    "C3_check_sin_permiso": (["sin_permiso.beancount", "FILENAME"], ["not readable", "ermission"]),
    "C3_check_sin_argumentos": (["FILENAME"], ["Missing argument"]),
    "C3_check_opcion_invalida": (["--opcion-falsa"], ["No such option"]),
    "C3_query_formato_invalido": (["--format"], ["not one of"]),
    "C3_query_inexistente": (["no_existe.beancount"], ["does not exist", "No such file"]),
    "C3_query_salida_dir_inexistente": (["/no/existe/x.csv"], ["No such file"]),
    "C3_format_inexistente": (["no_existe.beancount"], ["does not exist", "No such file"]),
    "C3_format_directorio": (["013"], ["directory"]),
    "C3_doctor_comando_invalido": (["subcomando-falso"], ["No such command"]),
    "C3_doctor_context_texto": (["LOCATION", "abc"], ["not a valid location"]),
    "C3_example_fecha_invalida": (["--date-begin"], ["not a valid"]),
    "C3_example_fin_antes_inicio": (["--date-end", "--date-begin"], ["before", "after", "earlier", "later"]),
    "C1_option_desconocida": (["optdesc.beancount:1"], ["Invalid option"]),
    "C1_option_valor_invalido": (["optval.beancount:1"], ["booking_method"]),
    "C1_include_glob_vacio": (["nada/*.beancount"], ["does not match"]),
    "C1_directiva_desconocida": (["dirdesc.beancount:1"], ["Invalid token"]),
    "C2_plugin_inexistente": (["beancount.plugins.no_existe"], ["No module named"]),
    "C2_plugin_config_invalida": (["check_average_cost"], ["config", "onfiguration", "invalid"]),
    "C2_booking_open_invalido": (["bookinv.beancount:1"], ["booking", "MAGICO"]),
}


def _mensaje(log):
    t = open(os.path.join(BASE, log), encoding="utf-8", errors="replace").read()
    rc = re.search(r"^rc=(\S+)", t, re.M).group(1)
    out = t.split("----- stdout -----\n", 1)[1].split("----- stderr -----\n")[0]
    err = t.split("----- stderr -----\n", 1)[1]
    return rc, out, err


def m015():
    M = "015"
    reg = Registro(M)
    for k, causas in CAUSAS_005.items():
        log = f"logs/raw/005/CLI_{k}.txt"
        rc, out, err = _mensaje(log)
        first = err.strip().splitlines()[0] if err.strip() else ""
        loc = re.search(r"\.beancount:[1-9]\d*:", first) is not None
        cau = any(c.lower() in first.lower() for c in causas)
        comp = "C1" if k in ("cuenta_raiz_invalida", "fecha_invalida", "moneda_con_sintaxis_invalida") else "C2"
        reg.add(f"{comp}_{k}", comp, f"Error contable '{k}': ¿el mensaje permite proponer la corrección?",
                f"ubicación archivo:línea + causa {causas}", f"ubicación={loc} causa={cau} | {first[:110]}", loc and cau, log)
    for cid, (elems, causas) in CAUSAS_013.items():
        log = f"logs/raw/013/{cid}.txt"
        rc, out, err = _mensaje(log)
        r = R(None if rc == "None" else int(rc), out, err, 0, False, log)
        msg = (err.strip() or out.strip())
        loc = any(e in msg for e in elems)
        cau = any(c.lower() in msg.lower() for c in causas)
        ok = loc and cau and not r.traceback
        comp = cid[:2]
        reg.add(f"{cid}", comp, f"Error de uso '{cid[3:]}': ¿el mensaje permite proponer la corrección?",
                f"sin traza; ubicación {elems}; causa {causas}", f"traza={r.traceback} ubicación={loc} causa={cau} | {msg.splitlines()[-1][:100] if msg else ''}",
                ok, log)
    reg.guardar(nota="cuenta_A = condición de error para la que se propone la acción correcta. "
                     "Criterio objetivo del evaluador (ubicación + causa en términos del dominio, sin traza). VALIDAR POR EL GRUPO.")


# ------------------------------------------------------------------ 016
def m016():
    M = "016"
    reg = Registro(M)
    d = wdir(M)
    # 1 bean-format -o sobre el mismo archivo
    L = shutil.copy(EJEMPLO, f"{d}/libro1.beancount")
    ref, _ = saldos(L, M, "ref")
    r = run([FMT, "-o", L, L], M, "C3_format_sobrescribe")
    j, _ = saldos(L, M, "C3_format_sobrescribe_saldos")
    mal = not (j and j["saldos"] == ref["saldos"] and j["n_entries"] == ref["n_entries"])
    reg.add("C3_format_sobre_mismo_archivo", "C3", "bean-format -o sobre el propio libro (sobrescritura)",
            "contenido contable intacto o advertencia", f"contenido intacto={not mal}, aviso={bool(r.err.strip())}", mal and not r.err.strip(), r.log)
    # 2 bean-query -o apuntando por error al libro
    L = shutil.copy(EJEMPLO, f"{d}/libro2.beancount")
    h = sha(L)
    r = run([QRY, "-q", "-o", L, L, "SELECT account LIMIT 2"], M, "C3_query_o_sobre_libro")
    perdido = sha(L) != h
    reg.add("C3_query_o_sobre_libro", "C3", "bean-query -o con el nombre del propio libro (error de tipeo)",
            "advertir/rechazar antes de destruir el libro", f"libro destruido={perdido}, tamaño ahora={os.path.getsize(L)} B, aviso={bool(r.err.strip())}",
            perdido and not r.err.strip(), r.log)
    # 3 bean-example -o sobre un archivo existente
    L = shutil.copy(EJEMPLO, f"{d}/libro3.beancount")
    h = sha(L)
    r = run([EXA, "--seed", "9", "-o", L], M, "C3_example_sobrescribe")
    perdido = sha(L) != h
    reg.add("C3_example_o_existente", "C3", "bean-example -o sobre un libro existente del usuario",
            "advertir/rechazar", f"libro reemplazado={perdido}, aviso={bool(r.err.strip())}", perdido and not r.err.strip(), r.log)
    # 4 bean-format sobre un archivo que no es un libro (CSV) con -o
    C = escribir(f"{d}/extracto.csv", "fecha,descripcion,monto\n2024-01-02,Supermercado,  -45.20\n2024-01-03,Sueldo,3000.00\n")
    h = sha(C)
    r = run([FMT, "-o", C, C], M, "C3_format_csv")
    reg.add("C3_format_sobre_csv", "C3", "bean-format -o sobre un archivo que no es beancount (extracto CSV)",
            "rechazar o no alterar", f"modificado={sha(C) != h}, aviso={bool(r.err.strip())}", sha(C) != h and not r.err.strip(), r.log)
    # 5 SIGINT (Ctrl-C) durante bean-check de un libro grande
    G = shutil.copy(GRANDE, f"{d}/grande.beancount")
    hg = sha(G)
    p = subprocess.Popen([CHK, "-C", G], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(5)
    p.send_signal(signal.SIGINT)
    o, e = p.communicate()
    escribir(f"{RAW}/{M}/C3_ctrl_c.txt", f"$ bean-check -C grande.beancount  (SIGINT a los 5 s)\nrc={p.returncode}\n----- stderr -----\n{e.decode()[-3000:]}")
    reg.add("C3_ctrl_c", "C3", "Interrupción con Ctrl-C (SIGINT) durante bean-check de 100 000 transacciones",
            "termina sin dañar el libro", f"rc={p.returncode} libro intacto={sha(G) == hg} traza_KeyboardInterrupt={'KeyboardInterrupt' in e.decode()}",
            sha(G) != hg, f"logs/raw/{M}/C3_ctrl_c.txt")
    # 6 caché obsoleta (resultado de 006_007, mismo experimento)
    try:
        c = [x for x in load_out("006_007")["casos"] if x["id"] == "C1_cache_obsoleta"][0]
        reg.add("C1_cache_obsoleta", "C1", "Editar el libro conservando su fecha (rsync -t / cp -p) con caché vigente",
                "detectar el cambio o advertir", c["observado"], c["menor"], c["evidencia"], fuente="006_007")
    except Exception as ex:
        print("006_007 aún no disponible", ex)
    # 7 libro con errores: bean-query sin -q sigue entregando resultados (riesgo de usar cifras con errores)
    r = run([QRY, f"{WORK}/012/balance_falso.beancount", Q_SALDOS], M, "C3_query_con_errores")
    reg.add("C3_query_resultados_con_errores", "C3", "Consultar un libro con errores contables",
            "informar del riesgo (errores) junto con el resultado", f"rc={r.rc}, errores informados en stderr={'Balance failed' in r.err}",
            "Balance failed" not in r.err, r.log)
    reg.guardar(nota="cuenta_A = situación de recuperación insatisfactoria sin aviso del riesgo")


# ------------------------------------------------------------------ 017 / 018
def _tiempos(M, prefijo, L, n):
    res = {"C1": [], "C2": [], "C3": []}
    cache = os.path.join(os.path.dirname(L), "." + os.path.basename(L) + ".picklecache")
    parse = f"{WORK}/snippets/parse_only.py"
    escribir(parse, "import sys\nfrom beancount.parser import parser\ne, err, o = parser.parse_file(sys.argv[1])\nprint(len(e), len(err))\n")
    for i in range(n):
        for comp, cmd in (("C1", [PY3, "-I", parse, L]), ("C2", [CHK, "-C", L]), ("C3", [QRY, "-q", L, Q_SALDOS])):
            if os.path.exists(cache):
                os.remove(cache)
            r = run(cmd, M, f"{prefijo}_{comp}_{i + 1:02d}", timeout=900)
            res[comp].append(round(r.dt, 4))
            print(f"  [{M}] {comp} #{i + 1} {r.dt:.3f}s rc={r.rc}", flush=True)
    if os.path.exists(cache):
        os.remove(cache)
    return res


def m017():
    M = "017"
    L = shutil.copy(EJEMPLO, f"{wdir(M)}/ejemplo.beancount")
    res = _tiempos(M, "t", L, 10)
    json.dump({"metrica": M, "libro": "example.beancount (bean-example 2022-2026, 1552 tx)", "tiempos_s": res,
               "TXmedio_s": 1.0, "nota": "C1: parse_file; C2: bean-check -C; C3: bean-query -q saldos. Sin caché."},
              open(f"{OUT}/{M}.json", "w"), indent=1)


def m018():
    M = "018"
    L = shutil.copy(GRANDE, f"{wdir(M)}/grande.beancount")
    res = _tiempos(M, "t", L, 5)
    json.dump({"metrica": M, "libro": "grande_100k.beancount (100 000 tx sintéticas)", "tiempos_s": res,
               "Rmax_s": 10.0, "nota": "Peor caso: sin caché (se borra .picklecache antes de cada ejecución)."},
              open(f"{OUT}/{M}.json", "w"), indent=1)


# ------------------------------------------------------------------ 019
API_ERR = r'''
import sys, json
from beancount import loader
from beancount.core import data
e, err, o = loader.load_file(sys.argv[1])
print(json.dumps({"errores": [str(x.message).splitlines()[0] for x in err],
                  "precios": sum(isinstance(x, data.Price) for x in e),
                  "tx": sum(isinstance(x, data.Transaction) for x in e)}))
'''


def m019():
    M = "019"
    reg = Registro(M)
    d = wdir(M)

    def carga(name, body):
        L = escribir(f"{d}/{name}.beancount", body)
        r = py(API_ERR, M, name, args=[L])
        try:
            return json.loads(r.out.strip().splitlines()[-1]), r
        except Exception:
            return {"errores": ["FALLO " + r.todo[-200:]], "precios": -1, "tx": -1}, r

    base = '2020-01-01 open Activos:Caja USD\n2020-01-01 open Gastos:Comida USD\n2020-01-02 * "x"\n  Gastos:Comida 1 USD\n  Activos:Caja\n'
    j0, _ = carga("sin_name_assets", base)
    j, r = carga("name_assets", 'option "name_assets" "Activos"\noption "name_expenses" "Gastos"\n' + base)
    reg.add("C1_name_assets", "C1", "option name_assets/name_expenses permite cuentas raíz en español",
            "con option: 0 errores (sin option: errores)", f"sin={len(j0['errores'])} con={len(j['errores'])}", not (j0["errores"] and not j["errores"]), r.log)
    b = '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A 10.004 USD\n  Equity:E -10.00 USD\n'
    # La option se aplica a montos sin decimales (tolerancia no inferible): 100 vs -99 USD.
    b = b.replace("10.004 USD", "100 USD").replace("-10.00 USD", "-99 USD")
    j0, _ = carga("tol_sin", b)
    j, r = carga("tol_con", 'option "inferred_tolerance_default" "USD:2"\n' + b)
    reg.add("C1_inferred_tolerance_default", "C1", "option inferred_tolerance_default cambia la tolerancia de balanceo (mismo libro)",
            "sin option: error de balanceo; con option: 0 errores", f"sin={j0['errores'][:1]} con={j['errores'][:1]}", not (j0["errores"] and not j["errores"]), r.log)
    lots = ('2020-01-01 open Assets:Acc ACME\n2020-01-01 open Assets:Cash USD\n2020-01-01 open Income:G USD\n'
            '2020-01-02 * "a"\n  Assets:Acc 10 ACME {100 USD}\n  Assets:Cash\n2020-01-03 * "b"\n  Assets:Acc 10 ACME {120 USD}\n  Assets:Cash\n'
            '2020-02-01 * "v"\n  Assets:Acc -5 ACME {} @ 150 USD\n  Assets:Cash 750 USD\n  Income:G\n')
    L = escribir(f"{d}/lifo.beancount", 'option "booking_method" "LIFO"\n' + lots)
    r = run([QRY, "-q", "-f", "csv", L, "SELECT sum(number) AS g WHERE account = 'Income:G'"], M, "C1_booking_method_LIFO")
    g = r.out.strip().splitlines()[-1] if r.out.strip() else ""
    reg.add("C1_booking_method_global", "C1", "option booking_method LIFO cambia el lote reducido (ganancia -150)", "-150", g, g.strip() != "-150", r.log)
    L = escribir(f"{d}/commas.beancount", 'option "render_commas" "TRUE"\n' + '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A 1234567.89 USD\n  Equity:E\n')
    r = run([QRY, "-q", L, "SELECT sum(position) WHERE account = 'Assets:A'"], M, "C1_render_commas")
    reg.add("C1_render_commas", "C1", "option render_commas TRUE muestra separadores de miles en bean-query", "1,234,567.89",
            r.out.strip().splitlines()[-1] if r.out.strip() else "", "1,234,567.89" not in r.out, r.log)
    # C2 complementos
    j0, _ = carga("auto_sin", '2020-01-02 * "x"\n  Assets:A 1 USD\n  Equity:E\n')
    j, r = carga("auto_con", 'plugin "beancount.plugins.auto_accounts"\n2020-01-02 * "x"\n  Assets:A 1 USD\n  Equity:E\n')
    reg.add("C2_auto_accounts", "C2", "plugin auto_accounts abre automáticamente las cuentas usadas", "0 errores con plugin",
            f"sin={len(j0['errores'])} con={len(j['errores'])}", not (j0["errores"] and not j["errores"]), r.log)
    j, r = carga("implicit", 'plugin "beancount.plugins.implicit_prices"\n2020-01-01 open Assets:P\n2020-01-01 open Assets:U\n2020-01-02 * "x"\n  Assets:P 100 PEN @ 0.27 USD\n  Assets:U\n')
    reg.add("C2_implicit_prices", "C2", "plugin implicit_prices crea directivas price desde los @", ">= 1 price", j["precios"], j["precios"] < 1, r.log)
    j, r = carga("check_commodity", 'plugin "beancount.plugins.check_commodity"\n2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n2020-01-02 * "x"\n  Assets:A 1 XYZ\n  Equity:E\n')
    reg.add("C2_check_commodity", "C2", "plugin check_commodity señala monedas sin directiva commodity", "error sobre XYZ",
            j["errores"][:1], not any("XYZ" in e for e in j["errores"]), r.log)
    dup = '2020-01-01 open Assets:A\n2020-01-01 open Equity:E\n' + '2020-01-02 * "x"\n  Assets:A 1 USD\n  Equity:E -1 USD\n' * 2
    j, r = carga("noduplicates", 'plugin "beancount.plugins.noduplicates"\n' + dup)
    reg.add("C2_noduplicates", "C2", "plugin noduplicates señala transacciones duplicadas", "error de duplicado",
            j["errores"][:1], not any("uplicate" in e for e in j["errores"]), r.log)
    j, r = carga("leafonly", 'plugin "beancount.plugins.leafonly"\n2020-01-01 open Assets:A\n2020-01-01 open Assets:A:B\n2020-01-01 open Equity:E\n'
                 '2020-01-02 * "x"\n  Assets:A 1 USD\n  Equity:E\n2020-01-03 * "y"\n  Assets:A:B 1 USD\n  Equity:E\n')
    reg.add("C2_leafonly", "C2", "plugin leafonly señala postings en cuentas no hoja", "error en Assets:A",
            j["errores"][:1], not any("Assets:A" in e for e in j["errores"]), r.log)
    j, r = carga("unique_prices", 'plugin "beancount.plugins.unique_prices"\n2020-01-01 price ACME 10 USD\n2020-01-01 price ACME 11 USD\n')
    reg.add("C2_unique_prices", "C2", "plugin unique_prices señala precios contradictorios del mismo día", "error de precio",
            j["errores"][:1], not j["errores"], r.log)
    # C3 parámetros de la CLI
    F = f"{d}/fmt.beancount"
    r = run([FMT, "-c", "70", "-o", F, f"{LEDG}/sint_101.beancount"], M, "C3_format_currency_column")
    cols = {m.start(1) - m.start(0) for m in re.finditer(r"^  \S+\s+-?[\d.]+ (USD|PEN|ACME)", open(F).read(), re.M)}
    reg.add("C3_format_currency_column", "C3", "bean-format -c 70 alinea la moneda en la columna 70 (índice 69)", "{69}", sorted(cols)[:5], cols != {69}, r.log)
    r1 = run([EXA, "--seed", "5", "--date-begin", "2024-01-01", "--date-end", "2024-06-01"], M, "C3_example_seed5_a")
    r2 = run([EXA, "--seed", "5", "--date-begin", "2024-01-01", "--date-end", "2024-06-01"], M, "C3_example_seed5_b")
    r3 = run([EXA, "--seed", "6", "--date-begin", "2024-01-01", "--date-end", "2024-06-01"], M, "C3_example_seed6")
    reg.add("C3_example_seed", "C3", "bean-example --seed: misma semilla misma salida, otra semilla otra salida", "igual / distinta",
            f"{r1.out == r2.out} / {r1.out != r3.out}", not (r1.out == r2.out and r1.out != r3.out and r1.out), r1.log)
    L = escribir(f"{d}/auto_cli.beancount", '2020-01-02 * "x"\n  Assets:A 1 USD\n  Equity:E\n')
    r0 = run([CHK, L], M, "C3_check_sin_auto")
    r = run([CHK, "--auto", L], M, "C3_check_auto")
    reg.add("C3_check_auto", "C3", "bean-check --auto habilita los complementos automáticos (cuentas sin open aceptadas)",
            "rc 1 sin --auto, 0 con --auto", f"{r0.rc} / {r.rc}", not (r0.rc == 1 and r.rc == 0), r.log)
    r = run([QRY, "-q", "-f", "csv", "-o", f"{d}/salida.csv", EJEMPLO, "SELECT account LIMIT 3"], M, "C3_query_output_file")
    ok = os.path.exists(f"{d}/salida.csv") and open(f"{d}/salida.csv").read().startswith("account")
    reg.add("C3_query_o_y_f", "C3", "bean-query -o archivo.csv -f csv escribe el archivo en el formato pedido", "archivo CSV", ok, not ok, r.log)
    reg.guardar(nota="cuenta_A = falla al cambiar el comportamiento por parámetros")


# ------------------------------------------------------------------ 020
def m020():
    M = "020"
    reg = Registro(M)
    d = wdir(M)
    E = EJEMPLO
    inval = f"{WORK}/005/desbalanceada.beancount"
    sin_open = escribir(f"{d}/sin_open.beancount", '2020-01-02 * "x"\n  Assets:Nueva 1 USD\n  Equity:E\n')
    line = [i for i, l in enumerate(open(E), 1) if l.startswith("20") and ' * "' in l][100]
    ops = [
        ("C1", "solo_sintaxis", "Verificar solo la sintaxis tras editar", [DOC, "parse", E], lambda r: r.rc == 0),
        ("C1", "roundtrip", "Prueba de ida y vuelta (parse→print→parse) del libro", [DOC, "roundtrip", E], lambda r: r.rc == 0 and "Round-trip" in r.todo or r.rc == 0),
        ("C1", "lexer", "Inspeccionar los tokens de una línea problemática", [DOC, "lex", inval], lambda r: r.rc == 0 and "DATE" in r.out),
        ("C1", "suite_parser", "Re-ejecutar las pruebas del analizador incluidas en el paquete", [BC3 + "/pytest", "-q", "-p", "no:cacheprovider", "--pyargs", "beancount.parser.lexer_test"], lambda r: r.rc == 0),
        ("C2", "balance_fecha", "Afirmar el saldo de una cuenta a una fecha (directiva balance)", [CHK, "-C", escribir(f"{d}/bal.beancount", CAB + '2020-01-01 open Assets:A USD\n2020-01-01 open Equity:E USD\n2020-01-02 * "x"\n  Assets:A 5 USD\n  Equity:E\n2020-01-03 balance Assets:A 5 USD\n')], lambda r: r.rc == 0),
        ("C2", "display_context", "Revisar la precisión inferida por moneda", [DOC, "display-context", E], lambda r: r.rc == 0 and "USD" in r.out),
        ("C2", "suite_core", "Re-ejecutar las pruebas del núcleo incluidas en el paquete", [BC3 + "/pytest", "-q", "-p", "no:cacheprovider", "--pyargs", "beancount.core.inventory_test"], lambda r: r.rc == 0),
        ("C2", "commodities", "Comprobar que toda moneda está declarada (plugin check_commodity)", [CHK, "-C", escribir(f"{d}/cc.beancount", 'plugin "beancount.plugins.check_commodity"\n' + open(E).read())], lambda r: r.rc in (0, 1) and not r.traceback),
        ("C2", "duplicados", "Detectar transacciones duplicadas (plugin noduplicates)", [CHK, "-C", escribir(f"{d}/nd.beancount", 'plugin "beancount.plugins.noduplicates"\n' + open(E).read())], lambda r: r.rc == 0),
        ("C3", "validacion_completa", "Validación completa del libro", [CHK, E], lambda r: r.rc == 0),
        ("C3", "json_ci", "Errores en JSON para integración continua", [CHK, "--json", inval], lambda r: r.out.strip().startswith("{")),
        ("C3", "missing_open", "Generar las directivas open que faltan", [DOC, "missing-open", sin_open], lambda r: "open Assets:Nueva" in r.out),
        ("C3", "contexto", "Ver saldos antes/después de una transacción", [DOC, "context", E, str(line)], lambda r: r.rc == 0 and "Balances before" in r.out),
        ("C3", "linked", "Listar transacciones vinculadas", [DOC, "linked", E, str(line)], lambda r: r.rc in (0, 1) and not r.traceback),
        ("C3", "directorios", "Validar la jerarquía de directorios de documentos", [DOC, "directories", E, d], lambda r: not r.traceback),
        ("C3", "conciliar_extracto", "Conciliar el libro contra un extracto bancario CSV", None, None),
        ("C3", "diff_contable", "Comparar contablemente dos versiones del libro", None, None),
    ]
    for comp, cid, desc, cmd, okf in ops:
        if cmd is None:
            reg.add(f"{comp}_{cid}", comp, f"Oportunidad de prueba: {desc}", "función incorporada en Beancount 3.2.3",
                    "No existe función incorporada (requiere beangulp u otra herramienta externa)", False,
                    "logs/raw/020/" + cid + ".txt")
            escribir(f"{RAW}/{M}/{cid}.txt", f"Revisión: bean-doctor --help (comandos disponibles) y entry points de beancount 3.2.3.\n"
                     f"Ninguna herramienta incorporada cubre: {desc}.\n" + run([DOC, "--help"], M, f"{cid}_doctor_help").out)
            continue
        r = run(cmd, M, f"{comp}_{cid}", timeout=300)
        ok = bool(okf(r))
        reg.add(f"{comp}_{cid}", comp, f"Oportunidad de prueba: {desc}", "se resuelve con una función incorporada",
                f"rc={r.rc} traza={r.traceback}", ok, r.log)
    reg.guardar(nota="cuenta_A = la función de prueba incorporada se puede usar adecuadamente")


# ------------------------------------------------------------------ 021
MUTACIONES = [
    ("C1", "printer_fecha", "beancount/parser/printer.py", "beancount.parser.printer_test", None),
    ("C1", "options_defecto", "beancount/parser/options.py", "beancount.parser.options_test", None),
    ("C1", "loader_include", "beancount/loader.py", "beancount.loader_test", None),
    ("C2", "amount_suma", "beancount/core/amount.py", "beancount.core.amount_test", None),
    ("C2", "inventory_vacio", "beancount/core/inventory.py", "beancount.core.inventory_test", None),
    ("C2", "balance_tolerancia", "beancount/ops/balance.py", "beancount.ops.balance_test", None),
]
CAMBIOS = {
    "printer_fecha": ('"{e.date} {flag} {}\\n".format(', '"{e.date}  {flag} {}\\n".format('),
    "options_defecto": ('data.Booking.STRICT,\n                "STRICT",', 'data.Booking.FIFO,\n                "STRICT",'),
    "loader_include": ("os.path.join(cwd, include_filename)", "os.path.join(cwd, 'x' + include_filename)"),
    "amount_suma": ("amount1.number + amount2.number", "amount1.number - amount2.number"),
    "inventory_vacio": ("return len(self) == 0", "return len(self) != 0"),
    "balance_tolerancia": ('options_map["tolerance_multiplier"] * 2', 'options_map["tolerance_multiplier"] * 20'),
}


def m021():
    M = "021"
    reg = Registro(M)
    env = _sin_bytecode()
    for comp, cid, f, mod, _ in MUTACIONES:
        p = os.path.join(SRC, f)
        orig = open(p, encoding="utf-8").read()
        a, b = CAMBIOS[cid]
        if a not in orig:
            reg.add(f"{comp}_{cid}", comp, f"Mutación en {f}", "aplicable", "patrón no encontrado", False, "-", tiempo_s=None)
            continue
        open(p, "w", encoding="utf-8").write(orig.replace(a, b, 1))
        r1 = run([PY3, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--pyargs", mod], M, f"{comp}_{cid}_con_falla", cwd=SRC, env=env, timeout=600)
        open(p, "w", encoding="utf-8").write(orig)
        r2 = run([PY3, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--pyargs", mod], M, f"{comp}_{cid}_corregido", cwd=SRC, env=env, timeout=600)
        detect = r1.rc != 0
        reg.add(f"{comp}_{cid}", comp, f"Falla inyectada en {f}; re-prueba con {mod}", "la prueba detecta la falla y confirma la corrección",
                f"detectada={detect} confirmada={r2.rc == 0} T={r2.dt:.3f}s", False, r1.log + " ; " + r2.log,
                tiempo_s=round(r2.dt, 4) if (detect and r2.rc == 0) else None)
    d = wdir(M)
    ej = open(EJEMPLO, encoding="utf-8").read()
    mid = ej.index("\n\n", len(ej) // 2) + 2
    for cid, txt in (("desbalanceada", '2023-03-01 * "x"\n  Assets:US:BofA:Checking  1 USD\n  Equity:Opening-Balances  -2 USD\n\n'),
                     ("cuenta_no_abierta", '2023-03-01 * "x"\n  Assets:Inexistente  1 USD\n  Equity:Opening-Balances\n\n'),
                     ("balance_falso", '2023-03-01 balance Assets:US:BofA:Checking  123456789.00 USD\n\n'),
                     ("sintaxis", "@@@ basura @@@\n\n"),
                     ("moneda", '2023-03-01 * "x"\n  Assets:US:BofA:Checking  1 EUR\n  Equity:Opening-Balances\n\n')):
        L = escribir(f"{d}/{cid}.beancount", ej[:mid] + txt + ej[mid:])
        r1 = run([CHK, L], M, f"C3_{cid}_con_falla")
        escribir(L, ej)          # corrección
        r2 = run([CHK, L], M, f"C3_{cid}_corregido")
        reg.add(f"C3_{cid}", "C3", f"Falla '{cid}' en el libro; re-verificación con bean-check tras corregir",
                "detecta y confirma", f"detectada={r1.rc == 1} confirmada={r2.rc == 0} T={r2.dt:.3f}s", False, r1.log + " ; " + r2.log,
                tiempo_s=round(r2.dt, 4) if (r1.rc == 1 and r2.rc == 0) else None)
    reg.guardar(nota="X = Sum(T)/N por componente; T = tiempo de la prueba que confirma la corrección")


# ------------------------------------------------------------------ 022
def m022():
    M = "022"
    reg = Registro(M)
    d = wdir(M)
    env = _sin_bytecode()
    E = EJEMPLO
    n = sum(1 for _ in open(E))
    r = run([DOC, "region", E, f"{n // 2}:{n // 2 + 200}"], M, "C3_region")
    reg.add("C3_region", "C3", "Verificar solo una región de líneas del libro (bean-doctor region)", "saldos de la región",
            f"rc={r.rc} lineas={len(r.out.splitlines())}", r.rc == 0 and len(r.out.splitlines()) > 3, r.log)
    line = [i for i, l in enumerate(open(E), 1) if l.startswith("20") and ' * "' in l][200]
    r = run([DOC, "context", E, str(line)], M, "C3_context")
    reg.add("C3_context_linea", "C3", "Detenerse en una transacción concreta y ver su estado (bean-doctor context)",
            "saldos antes/después", f"rc={r.rc}", r.rc == 0 and "Balances before" in r.out, r.log)
    r = run([QRY, "-q", E, "SELECT account, sum(position) FROM CLOSE ON 2023-07-01 GROUP BY account"], M, "C3_corte_fecha")
    reg.add("C3_corte_fecha", "C3", "Evaluar el libro hasta una fecha de corte (FROM CLOSE ON)", "saldos al corte",
            f"rc={r.rc} filas={len(r.out.splitlines())}", r.rc == 0 and len(r.out.splitlines()) > 5, r.log)
    L = escribir(f"{d}/checkpoint.beancount", open(E).read() + "\n2023-07-01 balance Assets:US:BofA:Checking 0 USD\n")
    r = run([CHK, "-C", L], M, "C2_balance_punto_control")
    reg.add("C2_balance_punto_control", "C2", "Insertar una aserción balance como punto de control intermedio", "error localizado en el punto",
            f"rc={r.rc} msg={r.err.strip().splitlines()[0][:100] if r.err.strip() else ''}", r.rc == 1 and "Balance failed" in r.err, r.log)
    r = run([PY3, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--pyargs", "beancount.parser", "-k", "lexer and not unicode"], M, "C1_pytest_k", cwd=SRC, env=env, timeout=600)
    reg.add("C1_pytest_k", "C1", "Ejecutar solo un subconjunto de pruebas (-k)", "subconjunto ejecutado", r.out.strip().splitlines()[-1][:100] if r.out.strip() else "",
            r.rc == 0 and "deselected" in r.out, r.log)
    # --lf: primera ejecución con una falla inyectada, luego solo los fallidos
    p = os.path.join(SRC, "beancount/core/amount.py")
    orig = open(p).read()
    open(p, "w").write(orig.replace("amount1.number + amount2.number", "amount1.number - amount2.number", 1))
    cdir = f"{d}/pytest_cache"
    r1 = run([PY3, "-m", "pytest", "-q", "-o", f"cache_dir={cdir}", "--pyargs", "beancount.core"], M, "C2_pytest_lf_1", cwd=SRC, env=env, timeout=600)
    open(p, "w").write(orig)
    r2 = run([PY3, "-m", "pytest", "-q", "-o", f"cache_dir={cdir}", "--lf", "--pyargs", "beancount.core"], M, "C2_pytest_lf_2", cwd=SRC, env=env, timeout=600)
    reg.add("C2_pytest_lf", "C2", "Reanudar re-ejecutando solo las pruebas que fallaron (--lf)", "solo fallidas, ahora pasan",
            r2.out.strip().splitlines()[-1][:100] if r2.out.strip() else "", r1.rc != 0 and r2.rc == 0 and "deselected" in r2.out, r1.log + " ; " + r2.log)
    open(p, "w").write(orig.replace("amount1.number + amount2.number", "amount1.number - amount2.number", 1))
    r = run([PY3, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", "--pyargs", "beancount.core"], M, "C2_pytest_x", cwd=SRC, env=env, timeout=600)
    open(p, "w").write(orig)
    reg.add("C2_pytest_x", "C2", "Detenerse en la primera falla (-x)", "se detiene en la primera", r.out.strip().splitlines()[-1][:100] if r.out.strip() else "",
            r.rc != 0 and "stopping after 1 failures" in r.out, r.log)
    r = run([PY3, "-m", "pytest", "-q", "-p", "no:cacheprovider", "beancount/core/amount_test.py::TestAmount::test_add"], M, "C1_pytest_id", cwd=SRC, env=env, timeout=600)
    reg.add("C1_pytest_id", "C1", "Ejecutar un caso de prueba concreto por su identificador", "1 passed",
            r.out.strip().splitlines()[-1][:100] if r.out.strip() else "", r.rc == 0 and "1 passed" in r.out, r.log)
    escribir(f"{RAW}/{M}/C3_reanudar_validacion.txt",
             "bean-check no ofrece validación incremental: no hay opción para reanudar desde una línea o fecha ya verificada;\n"
             "la caché .picklecache se invalida completa ante cualquier cambio (loader.pickle_cache_function).\n" + run([CHK, "--help"], M, "C3_check_help").out)
    reg.add("C3_reanudar_validacion", "C3", "Reanudar la validación del libro desde el último punto verificado (incremental)",
            "opción de reanudación", "No soportado: bean-check revalida el libro completo", False, f"logs/raw/{M}/C3_reanudar_validacion.txt")
    reg.guardar(nota="cuenta_A = se puede pausar/acotar y reanudar en el punto deseado")


# ------------------------------------------------------------------ 023
def m023():
    M = "023"
    reg = Registro(M)
    d = wdir(M)
    humo = escribir(f"{d}/humo.sh", f"""set -e
V=$1
$V/bin/python -I -c "from beancount.parser import _parser, parser; e,err,o=parser.parse_string('2020-01-01 open Assets:A'); assert len(e)==1 and not err; print('C1 ok')" && echo C1_OK || echo C1_FAIL
$V/bin/python -I -c "from beancount import loader; e,err,o=loader.load_file('{EJEMPLO}'); assert not err; print('C2 ok', len(e))" && echo C2_OK || echo C2_FAIL
($V/bin/bean-check {EJEMPLO} && $V/bin/bean-query -q {EJEMPLO} 'SELECT count(*)') && echo C3_OK || echo C3_FAIL
""")

    def evaluar(cid, pasos, venv):
        log_all = []
        ok_inst = True
        for i, cmd in enumerate(pasos):
            r = run(cmd if isinstance(cmd, list) else ["bash", "-c", cmd], M, f"{cid}_paso{i + 1}", timeout=900)
            log_all.append(r.log)
            ok_inst &= r.rc == 0
        r = run(["bash", humo, venv], M, f"{cid}_humo", timeout=300)
        log_all.append(r.log)
        for c in ("C1", "C2", "C3"):
            ok = ok_inst and f"{c}_OK" in r.out
            reg.add(f"{c}_{cid}", c, f"Reinstalación '{cid}' + prueba de humo del componente", "instala y funciona",
                    f"instalación={'ok' if ok_inst else 'falló'} humo={'ok' if f'{c}_OK' in r.out else 'falló'}", not ok, " ; ".join(log_all))

    pkgs = "beancount==3.2.3 beanquery==0.2.0"
    for pyv in ("3.13", "3.12", "3.11"):
        v = f"{d}/venv{pyv}"
        shutil.rmtree(v, ignore_errors=True)
        evaluar(f"limpio_py{pyv}", [f"/usr/bin/python{pyv} -m venv {v}", f"{v}/bin/pip install -q {pkgs}"], v)
    v = f"{d}/venv3.13"
    evaluar("force_reinstall", [f"{v}/bin/pip install -q --force-reinstall --no-deps beancount==3.2.3"], v)
    evaluar("desinstalar_instalar", [f"{v}/bin/pip uninstall -y -q beancount", f"{v}/bin/pip install -q beancount==3.2.3"], v)
    evaluar("bajar_y_subir_version", [f"{v}/bin/pip install -q beancount==3.2.2", f"{v}/bin/pip install -q beancount==3.2.3",
                                      f"{v}/bin/python -c \"import beancount; assert beancount.__version__=='3.2.3', beancount.__version__\""], v)
    vu = f"{d}/venv_uv"
    shutil.rmtree(vu, ignore_errors=True)
    evaluar("uv_py3.13", [f"/root/.local/bin/uv venv -q -p /usr/bin/python3.13 {vu}", f"/root/.local/bin/uv pip install -q -p {vu}/bin/python {pkgs}"], vu)
    reg.guardar(nota="cuenta_A = falla de reinstalación (instalación o prueba de humo del componente)")


# ------------------------------------------------------------------ 024
def m024():
    M = "024"
    reg = Registro(M)
    d = wdir(M)
    libros = []
    for s in range(1, 6):
        out = f"{d}/v2_ejemplo_s{s}.beancount"
        run([BC2 + "/bean-example", "--seed", str(s), "--date-begin", "2024-01-01", "--date-end", "2026-10-29", "-o", out], M, f"gen_v2_s{s}")
        libros.append((f"v2ej_s{s}", out))
    for s in (101, 202, 303):
        libros.append((f"sint{s}", f"{LEDG}/sint_{s}.beancount"))
    for nom, L in libros:
        j2, r2 = saldos(L, M, f"{nom}_v2", v2=True)
        valido_v2 = j2 is not None and not j2["errores"]
        r = py("import sys\nfrom beancount.parser import parser\ne, err, o = parser.parse_file(sys.argv[1])\nprint(len(err)); [print(x.message) for x in err[:5]]",
               M, f"C1_{nom}_parse_v3", args=[L])
        n = int(r.out.split()[0]) if r.rc == 0 and r.out.split() else -1
        reg.add(f"C1_{nom}", "C1", f"Libro {nom} (válido en 2.3.6={valido_v2}) se lee en 3.2.3 sin errores de sintaxis", "0 errores",
                f"errores={n}", valido_v2 and n == 0, r.log + " ; " + r2.log)
        j3, r3 = saldos(L, M, f"{nom}_v3")
        iguales = j3 is not None and j2 is not None and j3["saldos"] == j2["saldos"] and not j3["errores"]
        reg.add(f"C2_{nom}", "C2", f"Libro {nom}: mismos saldos y 0 errores en 3.2.3 que en 2.3.6", "saldos idénticos",
                f"iguales={j3 and j2 and j3['saldos'] == j2['saldos']} errores_v3={j3 and j3['errores'][:2]}", valido_v2 and iguales, r3.log)
        r = run([CHK, L], M, f"C3_{nom}_check_v3")
        reg.add(f"C3_{nom}", "C3", f"bean-check 3.2.3 acepta el libro {nom} de 2.3.6", "rc=0",
                f"rc={r.rc} {r.err.strip().splitlines()[0][:100] if r.err.strip() else ''}", valido_v2 and r.rc == 0, r.log)
    reg.guardar(nota="cuenta_A = dato (libro) confirmado como utilizable tras el reemplazo")


# ------------------------------------------------------------------ 025
def m025():
    M = "025"
    reg = Registro(M)
    v2bin = sorted(x for x in os.listdir(BC2) if x.startswith("bean-"))
    for t in v2bin:
        existe = os.path.exists(f"{BC3}/{t}")
        if existe and t in ("bean-check", "bean-doctor", "bean-format", "bean-query", "bean-example"):
            args = {"bean-check": [EJEMPLO], "bean-doctor": ["display-context", EJEMPLO], "bean-format": [f"{LEDG}/sint_101.beancount"],
                    "bean-query": ["-q", "-f", "csv", EJEMPLO, "SELECT sum(number) AS s WHERE currency = 'USD' AND account ~ '^Assets'"], "bean-example": ["--seed", "3", "--date-begin", "2024-01-01", "--date-end", "2024-03-01"]}[t]
            r2 = run([f"{BC2}/{t}", *args], M, f"C3_{t}_v2")
            r3 = run([f"{BC3}/{t}", *args], M, f"C3_{t}_v3")
            similar = r2.rc == r3.rc == 0 and (t != "bean-query" or r2.out.split()[-1] == r3.out.split()[-1])
            obs, ev = f"existe; rc v2={r2.rc} v3={r3.rc}; resultado similar={similar}", r2.log + " ; " + r3.log
        else:
            similar, obs, ev = False, "no existe en 3.2.3 (retirada o movida a otro paquete)", "-"
            escribir(f"{RAW}/{M}/C3_{t}.txt", f"ls {BC3}/{t}: {'existe' if existe else 'No such file'}\n")
            ev = f"logs/raw/{M}/C3_{t}.txt"
        reg.add(f"C3_{t}", "C3", f"Herramienta {t} de 2.3.6", "existe y da resultados similares sin cambios", obs, similar, ev)
    code = r'''
import importlib, json, sys
mods = sys.argv[1].split(",")
res = {}
for m in mods:
    mod, _, attr = m.partition(":")
    try:
        x = importlib.import_module(mod)
        if attr:
            for a in attr.split("."):
                x = getattr(x, a)
        res[m] = True
    except Exception as e:
        res[m] = repr(e)[:120]
print(json.dumps(res))
'''
    api = ["beancount.loader:load_file", "beancount.loader:load_string", "beancount.parser.parser:parse_file",
           "beancount.parser.parser:parse_string", "beancount.parser.printer:print_entries", "beancount.parser.booking:book",
           "beancount.core.realization:realize", "beancount.core.inventory:Inventory", "beancount.core.getters:get_accounts",
           "beancount.ops.summarize:clamp_opt", "beancount.core.prices:build_price_map", "beancount.query.query:run_query",
           "beancount.ingest.importer:ImporterProtocol", "beancount.reports.report:get_all_reports"]
    r3 = py(code, M, "api_v3", args=[",".join(api)])
    r2 = py(code, M, "api_v2", args=[",".join(api)], v2=True)
    j3, j2 = json.loads(r3.out.strip().splitlines()[-1]), json.loads(r2.out.strip().splitlines()[-1])
    for a in api:
        comp = "C1" if (".parser" in a or ".loader" in a) else "C2"
        reg.add(f"{comp}_api_{a.split(':')[-1]}_{a.split(':')[0].split('.')[-1]}", comp, f"API {a}", "disponible en 3.2.3",
                f"v2={j2[a] is True} v3={j3[a] if j3[a] is not True else True}", j2[a] is True and j3[a] is True, r3.log + " ; " + r2.log)
    pl2 = sorted(x[:-3] for x in os.listdir(f"{BC2.replace('/bin', '')}/lib/python3.11/site-packages/beancount/plugins")
                 if x.endswith(".py") and not x.endswith("_test.py") and x != "__init__.py")
    escribir(f"{WORK}/025_plugins.beancount", "")
    for p in pl2:
        L = escribir(f"{wdir(M)}/plug_{p}.beancount", f'plugin "beancount.plugins.{p}"\n' + open(f"{LEDG}/sint_101.beancount").read())
        r2 = run([f"{BC2}/bean-check", L], M, f"C2_plugin_{p}_v2")
        r = run([CHK, L], M, f"C2_plugin_{p}_v3")
        fallo3 = r.traceback or "Error importing" in r.err or ("Error applying plugin" in r.err and "Error applying plugin" not in r2.err)
        ok = (not fallo3) and r.rc == r2.rc
        reg.add(f"C2_plugin_{p}", "C2", f"Complemento beancount.plugins.{p} de 2.3.6", "existe y se comporta igual que en 2.3.6 (mismo rc)",
                f"rc v2={r2.rc} v3={r.rc} {r.err.strip().splitlines()[0][:90] if r.err.strip() else ''}", ok, r2.log + " ; " + r.log)
    reg.guardar(nota="cuenta_A = función que produce resultados similares sin requerir cambios")


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        print("====", f, flush=True)
        globals()[f]()
